﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Leadshine.SMC.IDE.Motion;
using System.Threading;
using System.Drawing.Drawing2D;
using MathNet.Numerics.LinearAlgebra;
using System.IO;
using System.Runtime.InteropServices;

namespace My_control
{
    public partial class main : Form
    {        

        Inverse Inverse = new Inverse();
        forward_instantaneous forward_instantaneous = new forward_instantaneous();
        public static double e_tool; //刀具长度
        public static double r_tool; //刀具半径
        double e0_tool=97.84;
        public static ushort CardNum = 0; //运动卡卡号
        public static ushort[] axis_all = { 0, 1, 2, 3, 4, 5 };
        ushort[] axis_PM = { 0, 1, 2, 3};
        ushort[] axis_SM = { 4, 5 };
        double[] pos = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
        public static double[] pos0 = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
        double[] vel = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
        double[] workpiece_pos0 = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
        double PKM_motor_pos0 = 166.8140357;            //待核实，初始姿态，并联动力头4支链位置一致，动静平台互相平行
        int datecount, pnum;
        double[] PKM_G;  //刀尖起始点，工件原点
        double[] PKM_Pstar;
        double[] PKM_Pstar_motor;
        public static uint[] ALM = new uint[] { 0, 0, 0, 0, 0, 0 };// 驱动器报警信号
        public static double lp_PKM = 4;     //并联动力头丝杠导程
        public static double lp_XY = 5;     //移动平台丝杠导程
        public static double fp = 10003;   //控制器分辨率
        int ct;         //电机报警标准，报警轴号
        int SF = 0;
        public main()
        {
            InitializeComponent();              
        }
        //连接控制器
        public static  int wether_link = 0;
        private void link_button_Click(object sender, EventArgs e)
        {                               
            if (wether_link == 0)
            {                 
                short res = LTSMC.smc_board_init (CardNum, 2, "192.168.5.11", 115200);//    1：串口连接类型；2： 网口连接类型
                if (res != 0)
                {
                    MessageBox.Show(string.Format("连接控制器失败，错误代码：{0}", res), "错误");                                          
                }
                else {
                       wether_link = 1;
                       link_button.Text = "关闭设备";
                       timer1.Start();
                       timer2.Start();
                       timer3.Start();
                    for (int i = 0; i < 4; i = i + 1)
                    {
                        LTSMC.smc_set_pulse_outmode(CardNum, axis_all[i], 0);//设置脉冲模式
                        LTSMC.smc_set_counter_inmode(CardNum, axis_all[i], 3);//设置编码器计数方式
                        LTSMC.smc_set_counter_reverse(CardNum, axis_all[i], 1);//设置编码器计数反向0/1
                        LTSMC.smc_set_alm_mode(CardNum, axis_all[i], 0, 0, 0);//设置报警使能，关闭报警
                    }
                    for (int i = 4; i < axis_all.Length; i = i + 1)
                    {
                        LTSMC.smc_set_pulse_outmode(CardNum, axis_all[i], 2);//设置脉冲模式
                        LTSMC.smc_set_counter_inmode(CardNum, axis_all[i], 3);//设置编码器计数方式
                        LTSMC.smc_set_counter_reverse(CardNum, axis_all[i], 1);//设置编码器计数反向0/1
                        LTSMC.smc_set_alm_mode(CardNum, axis_all[i], 0, 0, 0);//设置报警使能，关闭报警
                    }
                    for (int i = 0; i < 6; i++)         //检查电机是否处于异常情况
                    {
                        ALM[i] = LTSMC.smc_axis_io_status(CardNum, axis_all[i]);
                        ALM[i] = ALM[i] % 2;
                        if (ALM[i] == 1)
                        {
                            ct = i + 1;
                            MessageBox.Show(ct + "号电机报警，请先解决!");
                            wether_link = 0;
                            link_button.Text = "打开设备";
                            LTSMC.smc_board_close(CardNum);
                        }
                    } 
                }            
            }else 
            {
                wether_link = 0;
                link_button.Text = "打开设备";
                LTSMC.smc_handwheel_set_mode(CardNum, 0, 0);//设置手轮运动模式，硬件或软件模式
                LTSMC.smc_handwheel_stop(CardNum);//手轮关闭
                handwheel = 0;
                LTSMC.smc_conti_stop_list(CardNum, 0, 0);//停止模式， 0： 减速停止， 1： 立即停止
                spindle_run = 0;
                LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
                LTSMC.smc_board_close(CardNum);                                                      
            }
        }
        //机床尺度
        public static double a1, a2, a3, a4;  //静平台半径
        public static double b1, b2, b3, b4;  //动平台半径
        public static double d1min; public static double d1max;
        public static double d2min; public static double d2max;
        public static double d3min; public static double d3max;
        public static double d4min; public static double d4max;
        public static double R1_min; public static double R1_max;
        public static double R2_min; public static double R2_max;
        public static double R3_min; public static double R3_max;
        public static double R4_min; public static double R4_max;
        public static double U1_min; public static double U1_max;
        public static double U12_min; public static double U12_max;
        public static double U2_min; public static double U2_max;
        public static double U22_min; public static double U22_max;
        public static double S3_min; public static double S3_max;
        public static double S32_min; public static double S32_max;
        public static double U4_min; public static double U4_max;
        public static double U42_min; public static double U42_max;
        //暂存上一时刻尺度
        double q_a1, q_a2, q_a3, q_a4;  //静平台半径
        double q_b1, q_b2, q_b3, q_b4;  //动平台半径
        double q_d1min;   double q_d1max;
        double q_d2min;   double q_d2max;
        double q_d3min;   double q_d3max;
        double q_d4min;   double q_d4max;
        double q_R1_min;  double q_R1_max;
        double q_R2_min;  double q_R2_max;
        double q_R3_min;  double q_R3_max;
        double q_R4_min;  double q_R4_max;
        double q_U1_min;  double q_U1_max;
        double q_U12_min; double q_U12_max;
        double q_U2_min;  double q_U2_max;
        double q_U22_min; double q_U22_max;
        double q_S3_min;  double q_S3_max;
        double q_S32_min; double q_S32_max;
        double q_U4_min;  double q_U4_max;
        double q_U42_min; double q_U42_max;
        //读取当前尺度尺度
        public void read_dimention()
        {
            a1 = Convert.ToDouble(value_a1.Text);       //修改后的机床尺度参数
            a2 = Convert.ToDouble(value_a2.Text);
            a3 = Convert.ToDouble(value_a3.Text);
            a4 = Convert.ToDouble(value_a4.Text);
            b1 = Convert.ToDouble(value_b1.Text);
            b2 = Convert.ToDouble(value_b2.Text);
            b3 = Convert.ToDouble(value_b3.Text);
            b4 = Convert.ToDouble(value_b4.Text);          //动、静平台尺度
            d1min = Convert.ToDouble(value_d1min.Text);
            d1max = Convert.ToDouble(value_d1max.Text);
            d2min = Convert.ToDouble(value_d2min.Text);
            d2max = Convert.ToDouble(value_d2max.Text);
            d3min = Convert.ToDouble(value_d3min.Text);
            d3max = Convert.ToDouble(value_d3max.Text);
            d4min = Convert.ToDouble(value_d4min.Text);
            d4max = Convert.ToDouble(value_d4max.Text);    //主动关节极限位置
            R1_min = Convert.ToDouble(value_R1min.Text);   //被动关节极限角
            R1_max = Convert.ToDouble(value_R1max.Text);
            R2_min = Convert.ToDouble(value_R2min.Text);
            R2_max = Convert.ToDouble(value_R2max.Text);
            R3_min = Convert.ToDouble(value_R3min.Text);
            R3_max = Convert.ToDouble(value_R3max.Text);
            R4_min = Convert.ToDouble(value_R4min.Text);
            R4_max = Convert.ToDouble(value_R4max.Text);
            R4_min = Convert.ToDouble(value_R4min.Text);
            R4_max = Convert.ToDouble(value_R4max.Text);
            U1_min = Convert.ToDouble(value_U1min.Text);
            U1_max = Convert.ToDouble(value_U1max.Text);
            U12_min = Convert.ToDouble(value_U12min.Text);
            U12_max = Convert.ToDouble(value_U12max.Text);
            U2_min = Convert.ToDouble(value_U2min.Text);
            U2_max = Convert.ToDouble(value_U2max.Text);
            U22_min = Convert.ToDouble(value_U22min.Text);
            U22_max = Convert.ToDouble(value_U22max.Text);
            S3_min = Convert.ToDouble(value_S3min.Text);
            S3_max = Convert.ToDouble(value_S3max.Text);
            S32_min = Convert.ToDouble(value_S32min.Text);
            S32_max = Convert.ToDouble(value_S32max.Text);
            U4_min = Convert.ToDouble(value_U4min.Text);
            U4_max = Convert.ToDouble(value_U4max.Text);
            U42_min = Convert.ToDouble(value_U42min.Text);
            U42_max = Convert.ToDouble(value_U42max.Text);
        }
        //暂存上一时刻尺度
        public void save_dimention()
        {
            q_a1 = a1; q_a2 = a2; q_a3 = a3; q_a4 = a4;
            q_b1 = b1; q_b2 = b2; q_b3 = b3; q_b4 = b4;
            q_d1min = d1min; q_d1max = d1max;
            q_d2min = d2min; q_d2max = d2max;
            q_d3min = d3min; q_d3max = d3max;
            q_d4min = d4min; q_d4max = d4max;
            q_R1_min = R1_min;   q_R1_max = R1_max;
            q_R2_min = R2_min;   q_R2_max = R2_max;
            q_R3_min = R3_min;   q_R3_max = R3_max;
            q_R4_min = R4_min;   q_R4_max = R4_max;
            q_U1_min = U1_min;   q_U1_max = U1_max;
            q_U12_min = U12_min; q_U12_max = U12_max;
            q_U2_min = U2_min;   q_U2_max = U2_max;
            q_U22_min = U22_min; q_U22_max = U22_max;
            q_S3_min = S3_min;   q_S3_max = S3_max;
            q_S32_min = S32_min; q_S32_max = S32_max;
            q_U4_min = U4_min;   q_U4_max = U4_max;
            q_U42_min = U42_min; q_U42_max = U42_max;
        }
        //确认修改尺度
        private void dimention_change_Click(object sender, EventArgs e)
        {
            read_dimention();
            save_dimention();
            MessageBox.Show("机床尺度已更改!");
        }
        //取消尺度修改
        private void dimention_keep_Click(object sender, EventArgs e)
        {
            value_d1min.Text = q_d1min.ToString();    value_d1max.Text = q_d1max.ToString();
            value_d2min.Text = q_d2min.ToString();    value_d2max.Text = q_d2max.ToString();
            value_d3min.Text = q_d3min.ToString();    value_d3max.Text = q_d3max.ToString();
            value_d4min.Text = q_d4min.ToString();    value_d4max.Text = q_d4max.ToString();
            value_R1min.Text = q_R1_min.ToString();   value_R1max.Text = q_R1_max.ToString();
            value_R2min.Text = q_R2_min.ToString();   value_R2max.Text = q_R2_max.ToString();
            value_R3min.Text = q_R3_min.ToString();   value_R3max.Text = q_R3_max.ToString();
            value_R4min.Text = q_R4_min.ToString();   value_R4max.Text = q_R4_max.ToString();
            value_U1min.Text = q_U1_min.ToString();   value_U1max.Text = q_U1_max.ToString();
            value_U12min.Text = q_U12_min.ToString(); value_U12max.Text = q_U12_max.ToString();
            value_U2min.Text = q_U2_min.ToString();   value_U2max.Text = q_U2_max.ToString();
            value_U22min.Text = q_U22_min.ToString(); value_U22max.Text = q_U22_max.ToString();
            value_S3min.Text = q_S3_min.ToString();   value_S3max.Text = q_S3_max.ToString();
            value_S32min.Text = q_S32_min.ToString(); value_S32max.Text = q_S32_max.ToString();
            value_U4min.Text = q_U4_min.ToString();   value_U4max.Text = q_U4_max.ToString();
            value_U42min.Text = q_U42_min.ToString(); value_U42max.Text = q_U42_max.ToString();
        }
        //界面导入
        private void main_Load(object sender, EventArgs e)//记录当前刀具
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            dimention_Box.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = true;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = false;
            read_dimention();
            save_dimention();

            for (int i = 0; i < 3; i = i + 1)//机床预校零
            {
                LTSMC.smc_set_encoder_unit(CardNum, axis_all[i], PKM_motor_pos0 * (fp / lp_PKM));
                LTSMC.smc_set_position_unit(CardNum, axis_all[i], PKM_motor_pos0 * (fp / lp_PKM));
            }
            for (int i = 3; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_set_encoder_unit(CardNum, axis_all[i], 0);
                LTSMC.smc_set_position_unit(CardNum, axis_all[i], 0);
            }
        }
        //打开伺服使能 
        private void open_SF_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            for (int i = 0; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_write_sevon_pin(CardNum, axis_all[i], 0);//打开伺服使能               
            }
            SF = 1;
        }
        //关闭伺服使能    
        private void close_SF_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            for (int i = 0; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_write_sevon_pin(CardNum, axis_all[i], 1);//关闭伺服使能               
            }
            SF = 0;
        }                
           
        //X+
        private void button5_MouseDown(object sender, MouseEventArgs e)
        {            
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort axis = 4;
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_XY);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_XY);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_XY);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_equiv(CardNum, axis, 1);//设置脉冲当量
            LTSMC.smc_set_alm_mode(CardNum, axis, 0, 0, 0);//设置报警使能，关闭报警
            LTSMC.smc_set_s_profile(CardNum, axis, 0, 0.01);//设置S段时间（0-0.05s)
            LTSMC.smc_set_profile_unit(CardNum, axis, start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
            LTSMC.smc_set_dec_stop_time(CardNum, axis, dec);//设置减速停止时间
            LTSMC.smc_vmove(CardNum, axis, 1);//连续运动，1：正向，0：反向
        }
        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            ushort axis = 4;
            LTSMC.smc_stop(CardNum, axis, 0);//减速停止运动
        }
        //X-
        private void button6_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort axis = 4;
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_XY);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_XY);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_XY);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_equiv(CardNum, axis, 1);//设置脉冲当量
            LTSMC.smc_set_alm_mode(CardNum, axis, 0, 0, 0);//设置报警使能，关闭报警
            LTSMC.smc_set_s_profile(CardNum, axis, 0, 0.01);//设置S段时间（0-0.05s)
            LTSMC.smc_set_profile_unit(CardNum, axis, start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
            LTSMC.smc_set_dec_stop_time(CardNum, axis, dec);//设置减速停止时间
            LTSMC.smc_vmove(CardNum, axis, 0);//连续运动
        }
        private void button6_MouseUp(object sender, MouseEventArgs e)
        {
            ushort axis = 4;
            LTSMC.smc_stop(CardNum, axis, 0);//减速停止运动
        }
        //Y+
        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort axis = 5;
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_XY);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_XY);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_XY);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_equiv(CardNum, axis, 1);//设置脉冲当量
            LTSMC.smc_set_alm_mode(CardNum, axis, 0, 0, 0);//设置报警使能，关闭报警
            LTSMC.smc_set_s_profile(CardNum, axis, 0, 0.01);//设置S段时间（0-0.05s)
            LTSMC.smc_set_profile_unit(CardNum, axis, start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
            LTSMC.smc_set_dec_stop_time(CardNum, axis, dec);//设置减速停止时间
            LTSMC.smc_vmove(CardNum, axis, 1);//连续运动，1：正向，0：反向
        }
        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            ushort axis = 5;
            LTSMC.smc_stop(CardNum, axis, 0);//减速停止运动
        }
        //Y-
        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort axis = 5;
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_XY);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_XY);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_XY);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_equiv(CardNum, axis, 1);//设置脉冲当量
            LTSMC.smc_set_alm_mode(CardNum, axis, 0, 0, 0);//设置报警使能，关闭报警
            LTSMC.smc_set_s_profile(CardNum, axis, 0, 0.01);//设置S段时间（0-0.05s)
            LTSMC.smc_set_profile_unit(CardNum, axis, start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
            LTSMC.smc_set_dec_stop_time(CardNum, axis, dec);//设置减速停止时间
            LTSMC.smc_vmove(CardNum, axis, 0);//连续运动，1：正向，0：反向
        }
        private void button4_MouseUp(object sender, MouseEventArgs e)
        {
            ushort axis = 5;
            LTSMC.smc_stop(CardNum, axis, 0);//减速停止运动
        }
        //Z+
        private void button7_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = {0,1,2,3};
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 1);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[1], 1);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[2], 1);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[3], 1);//连续运动，1：正向，0：反向
        }
        private void button7_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 0, 1, 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
        //Z-
        private void button8_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = { 0, 1, 2, 3 };
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 0);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[1], 0);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[2], 0);//连续运动，1：正向，0：反向
            LTSMC.smc_vmove(CardNum, axis[3], 0);//连续运动，1：正向，0：反向
        }
        private void button8_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 0, 1, 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
        //A+
        private void button9_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = { 0, 1};
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 0);
            LTSMC.smc_vmove(CardNum, axis[1], 1);
        }
        private void button9_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 0, 1};
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
        //A-
        private void button10_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = { 0, 1 };
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 1);
            LTSMC.smc_vmove(CardNum, axis[1], 0);
        }
        private void button10_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 0, 1 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
       //B+
        private void button11_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = { 2, 3 };
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 0);
            LTSMC.smc_vmove(CardNum, axis[1], 1);
        }
        private void button11_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
        //B-
        private void button12_MouseDown(object sender, MouseEventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            ushort[] axis = { 2, 3 };
            double start = decimal.ToDouble(start_speed.Value) * (fp / lp_PKM);
            double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
            double stop = decimal.ToDouble(stop_speed.Value) * (fp / lp_PKM);
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_equiv(CardNum, axis[i], 1);//设置脉冲当量
                LTSMC.smc_set_alm_mode(CardNum, axis[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_set_s_profile(CardNum, axis[i], 0, 0.01);//设置S段时间（0-0.05s)
                LTSMC.smc_set_profile_unit(CardNum, axis[i], start, speed, acc, dec, stop);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTSMC.smc_set_dec_stop_time(CardNum, axis[i], dec);//设置减速停止时间
            }
            LTSMC.smc_vmove(CardNum, axis[0], 1);
            LTSMC.smc_vmove(CardNum, axis[1], 0);
        }
        private void button12_MouseUp(object sender, MouseEventArgs e)
        {
            ushort[] axis = { 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_stop(CardNum, axis[i], 0);//减速停止运动
            }
        }
        int handwheel = 0;
        //打开手轮
        private void open_handwheel_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("请先校准机器原点!");
                return;
            }
            ushort[] AxisList_x = { 4 };
            ushort[] AxisList_y = { 5 };
            ushort[] AxisList_z = { 0, 1, 2, 3 };
            ushort[] AxisList_A = { };
            ushort[] AxisList_B = { };
            ushort InMode = 0; //输入脉冲模式，0：脉冲+方向，1：AB 相脉冲
            ushort IfHardEnable = 1; // 运行模式，0：软件控制，1：硬件控制 
            //手轮运动初始化
            LTSMC.smc_handwheel_set_axislist(CardNum, 0, 1, AxisList_x);//X轴运动
            LTSMC.smc_handwheel_set_ratiolist(CardNum, 0, 0, 3, new double[] { 1, 10, 100 });//设置X轴倍选
            LTSMC.smc_handwheel_set_axislist(CardNum, 1, 1, AxisList_y);//Y轴运动
            LTSMC.smc_handwheel_set_ratiolist(CardNum, 1, 0, 3, new double[] { 1, 10, 100 });//设置Y轴倍选
            LTSMC.smc_handwheel_set_axislist(CardNum, 2, 4, AxisList_z);//Z轴运动
            LTSMC.smc_handwheel_set_ratiolist(CardNum, 2, 0, 3, new double[] { 1, 10, 100 });//设置Z轴倍选
            LTSMC.smc_handwheel_set_axislist(CardNum, 3, 0, AxisList_A);//A轴运动
            LTSMC.smc_handwheel_set_ratiolist(CardNum, 3, 0, 3, new double[] { 1, 10, 100 });//设置A轴倍选
            LTSMC.smc_handwheel_set_axislist(CardNum, 4, 0, AxisList_B);//B轴运动
            LTSMC.smc_handwheel_set_ratiolist(CardNum, 4, 0, 3, new double[] { 1, 10, 100 });//设置B轴倍选
            LTSMC.smc_handwheel_set_mode(CardNum, InMode, IfHardEnable);//设3w置手轮运动模式，硬件或软件模式
            LTSMC.smc_handwheel_move(CardNum, 0);//启动手轮
            handwheel = 1;
        }        
        //关闭手轮
        private void close_handwheel_Click(object sender, EventArgs e)
        {
            LTSMC.smc_handwheel_set_mode(CardNum, 0, 0);//设置手轮运动模式，硬件或软件模式
            LTSMC.smc_handwheel_stop(CardNum);
            handwheel = 0;
        }
        //在线改变速度
        private void button_change_speed_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            for (int i = 0; i < axis_all.Length - 2; i = i + 1)
            {
                double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_PKM);
                LTSMC.smc_change_speed_unit(CardNum, axis_all[i], speed, 0);//在线变速
            }
            for (int i = 4; i < axis_all.Length; i = i + 1)
            {
                double speed = decimal.ToDouble(run_speed.Value) * (fp / lp_XY);
                LTSMC.smc_change_speed_unit(CardNum, axis_all[i], speed, 0);//在线变速
            }
        }
        int machine_origin = 0;
        //原点校准
        private void confirm_zero_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            ushort[] axis = { 0, 1, 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_set_encoder_unit(CardNum, axis_all[i], PKM_motor_pos0 * (fp / lp_PKM));
                LTSMC.smc_set_position_unit(CardNum, axis_all[i], PKM_motor_pos0 * (fp / lp_PKM));
            }
            machine_origin = 1;
            MessageBox.Show("原点已校准");
        }        
        //示教功能
        double[,] teach_point = new double[100, 6];
        double teached_point_num;
        double[] teach_motor_poses = { 0, 0, 0, 0, 0, 0 };
        //教导
        private void teaching_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("原点未校准!");
                return;
            }
            int i;
            i = Convert.ToInt32(teaching_point.SelectedIndex.ToString());
            for (int j = 0; j < axis_all.Length; j = j + 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[j], ref pos0[j]);//当前编码器位置
                teach_point[i, j] = pos0[j];
            }
            this.teaching_point.Items[i] = "P" + (i + 1) + "-已定义";
            this.teached_point.Items[i] = "P" + (i + 1) + "-已定义";
        }
        //前往教导点
        private void moveto_Click(object sender, EventArgs e)
        {
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            int i;
            i = Convert.ToInt32(teached_point.SelectedIndex.ToString());
            //插补运动到指定点
            double start = decimal.ToDouble(start_speed.Value) * (2 * fp / (lp_XY + lp_PKM));
            double speed = decimal.ToDouble(run_speed.Value) * (2 * fp / (lp_XY + lp_PKM));
            double stop  = decimal.ToDouble(stop_speed.Value) * (2 * fp / (lp_XY + lp_PKM));
            double acc   = decimal.ToDouble(t_acc.Value);
            double dec   = decimal.ToDouble(t_dec.Value);
            for (int k = 0; k < axis_all.Length; k = k + 1)
            {
                LTSMC.smc_set_alm_mode(CardNum, axis_all[k], 0, 0, 0);//设置报警使能，关闭报警               
            }
            LTSMC.smc_set_vector_profile_unit(CardNum, 0, start, speed, acc, dec, stop);//设置插补运动速度参数            
            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    LTSMC.smc_conti_set_lookahead_mode(CardNum, 0, 2, 2, 0.1, 1000);
                    LTSMC.smc_conti_open_list(CardNum, 0, 5, axis_all);
                    LTSMC.smc_conti_line_unit(CardNum, 0, 5, axis_all, new double[] { teach_point[i, 0], teach_point[i, 1], 
                        teach_point[i, 2], teach_point[i, 3], teach_point[i, 4] , teach_point[i, 5]}, 1, 0);//绝对坐标模式                    
                    LTSMC.smc_conti_start_list(CardNum, 0);//启动插补
                    LTSMC.smc_conti_close_list(CardNum, 0);//
                }
                );
            teached_point_num = i;
        }
        //停止教导运动
        private void button_stoping_Click(object sender, EventArgs e)
        {
            LTSMC.smc_conti_stop_list(CardNum, 0, 0);//停止模式， 0： 减速停止， 1： 立即停止
        }
        //暂停教导运动
        private void button_stoping0_Click(object sender, EventArgs e)
        {
            LTSMC.smc_conti_pause_list(CardNum, 0);
        }
        //继续教导运动
        private void button_continue_Click(object sender, EventArgs e)
        {
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            LTSMC.smc_conti_start_list(CardNum, 0);
        }
        //用户轨迹编译
        private void button_edit_Click(object sender, EventArgs e)
        {

        }
        //自定义轨迹运行
        private void button_running_Click(object sender, EventArgs e)
        {
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
        }
        int give_tool = 0;
        //确认刀具
        private void tool_change_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("请先校准机器原点!");
                return;
            }
            if (this.value_tool.Text == "")
            {
                MessageBox.Show("刀具参数不能为空!");
                return;
            }
            e_tool = Convert.ToDouble(value_tool.Text) + e0_tool;
            r_tool = Convert.ToDouble(value_rtool.Text);
            give_tool = 1;
        }
        public static double X_position, Y_position;
        public static double[] workpiece_posZ = { 0, 0, 0, 0 };
        //设置工件X坐标
        private void Xbutton_Click_1(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("请先校准机器原点!");
                return;
            }
            if (give_tool == 0)
            {
                MessageBox.Show("请先给定刀具!");
                return;
            }
            double etool_X = r_tool * (fp / lp_XY);
            //while (Math.Abs(LTSMC.smc_get_encoder_unit(CardNum, axis_all[4], ref pos0[4]) / (fp / lp_XY) - r_tool) >= 0.01 && Math.Abs(LTSMC.smc_get_position_unit(CardNum, axis_all[4], ref pos[4]) / (fp / lp_XY) - r_tool) >= 0.01)
            //{
                LTSMC.smc_set_encoder_unit(CardNum, axis_all[4], etool_X);
                LTSMC.smc_set_position_unit(CardNum, axis_all[4], etool_X);
            //}            
            G0X.Text = "0";
        }
        //设置工件Y坐标
        private void Ybutton_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("请先校准机器原点!");
                return;
            }
            if (give_tool == 0)
            {
                MessageBox.Show("请先给定刀具!");
                return;
            }
            double etool_Y = r_tool * (fp / lp_XY);
            //while (Math.Abs(LTSMC.smc_get_encoder_unit(CardNum, axis_all[5], ref pos0[5]) / (fp / lp_XY) - r_tool) >= 0.01 && Math.Abs(LTSMC.smc_get_position_unit(CardNum, axis_all[5], ref pos[5]) / (fp / lp_XY) - r_tool) >= 0.01)
            //{
                LTSMC.smc_set_encoder_unit(CardNum, axis_all[5], etool_Y);
                LTSMC.smc_set_position_unit(CardNum, axis_all[5], etool_Y);
            //}
            G0Y.Text = "0";
        }
        //设置工件Z坐标
        private void Zbutton_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("请先校准机器原点!");
                return;
            }
            if (give_tool == 0)
            {
                MessageBox.Show("请先给定刀具!");
                return;
            }
            PKM_G = new double[3];
            ushort[] axis = { 0, 1, 2, 3 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis[i], ref workpiece_posZ[i]);//当前编码器位置
                workpiece_posZ[i] = workpiece_posZ[i] / (fp / lp_PKM);
            }
            forward_instantaneous.foward_get_posture(workpiece_posZ[0], workpiece_posZ[1], workpiece_posZ[2], workpiece_posZ[3]);
            PKM_G[0] = 0; PKM_G[1] = 0; PKM_G[2] = forward_instantaneous.instantaneous_Gz;
            G0Z.Text = PKM_G[2].ToString();
            //下面是回复坐标图片
            string str1 = System.Windows.Forms.Application.StartupPath;
            for (int c = 0; c < 0; c++)//c代表返回上层几次
            {
                str1 = str1.Substring(0, str1.LastIndexOf('\\'));
            }
            str1 = Path.Combine(str1, "zb.png");
            Image img = Image.FromFile(str1);//双引号里是图片的路径
            pictureBox1.Image = img;
        }
        //对刀图片教程
        private void Xbutton_MouseEnter(object sender, EventArgs e)
        {
            string str1 = System.Windows.Forms.Application.StartupPath;
            for (int c = 0; c < 0; c++)//c代表返回上层几次
            {
                str1 = str1.Substring(0, str1.LastIndexOf('\\'));
            }
            str1 = Path.Combine(str1, "x.png");
            Image img = Image.FromFile(str1);//双引号里是图片的路径
            pictureBox1.Image = img;
        }
        private void Ybutton_MouseEnter(object sender, EventArgs e)
        {
            string str1 = System.Windows.Forms.Application.StartupPath;
            for (int c = 0; c < 0; c++)//c代表返回上层几次
            {
                str1 = str1.Substring(0, str1.LastIndexOf('\\'));
            }
            str1 = Path.Combine(str1, "y.png");
            Image img = Image.FromFile(str1);//双引号里是图片的路径
            pictureBox1.Image = img;
        }
        private void Zbutton_MouseEnter(object sender, EventArgs e)
        {
            string str1 = System.Windows.Forms.Application.StartupPath;
            for (int c = 0; c < 0; c++)//c代表返回上层几次
            {
                str1 = str1.Substring(0, str1.LastIndexOf('\\'));
            }
            str1 = Path.Combine(str1, "z.png");
            Image img = Image.FromFile(str1);//双引号里是图片的路径
            pictureBox1.Image = img;
        }
        //启动主轴
        double fDuty;
        int spindle_run = 0;
        private void button_spindle_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            spindle_run = 1;
        }
        //关闭主轴
        private void button_spindle_stop_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            spindle_run = 0;
            LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
        }
        //导入刀具路径，由CAM导出
        double[,] Date; int Row = -1, Col; int wether_loading_pointa = 0;
        public static double[] G_X; public static double[] G_Y; public static double[] G_Z; public static double[] G_A; public static double[] G_B;
        public static double[] R; public static double[] posi_mode;
        private void button_datainput_Click(object sender, EventArgs e)
        {
            if (machine_origin == 0)
            {
                MessageBox.Show("原点未校准!");
                return;
            }
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Title = "打开数据文件";
            openDlg.Filter = "数据文件 (*.txt)|*.txt|All|*.*";
            bool result = false;
            string FilePath;
            string[] TempData;
            string[] TempArry;
            Row = 0;
            Col = 0;
            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                FilePath = openDlg.FileName;
                TempData = System.IO.File.ReadAllLines(FilePath, System.Text.Encoding.Default);
                Row = TempData.GetLength(0);
                TempArry = TempData[1].Split(',');
                Col = TempArry.GetLength(0);
                Date = new double[Row, Col];
                for (int i = 0; i < Row; i++)
                {
                    string[] Arry = TempData[i].Split(',');
                    for (int j = 0; j < Col; j++)
                    {
                        Date[i, j] = Convert.ToDouble(Arry[j]);
                    }
                }
                result = true;
            }
            if (result)
            {
                G_X = new double[Row]; G_Y = new double[Row]; G_Z = new double[Row];
                G_A = new double[Row]; G_B = new double[Row]; posi_mode = new double[Row]; R = new double[Row];
                for (int j = 0; j < Row; j++)
                {
                    posi_mode[j] = Date[j, 0];//插补模式
                    G_X[j] = Date[j, 1]; G_Y[j] = Date[j, 2]; G_Z[j] = Date[j, 3];
                    G_A[j] = Date[j, 4]; G_B[j] = Date[j, 5]; R[j] = Date[j, 6];
                }

                MessageBox.Show("读取刀具路径完成！");
                wether_loading_pointa = 1;
            }
            else
            {
                MessageBox.Show("读取刀具路径错误！");
                return;
            }
            textBox_pointnum.Text = Convert.ToString(Row);   //显示刀具总点数
            PKM_Pstar = new double[3];
            PKM_Pstar_motor = new double[6];
            for (int i = 0; i < 4; i = i + 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[i], ref PKM_Pstar_motor[i]);//当前编码器位置
                PKM_Pstar_motor[i] = PKM_Pstar_motor[i] / (fp / lp_PKM);
            }
            for (int i = 4; i < 6; i = i + 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[i], ref PKM_Pstar_motor[i]);//当前编码器位置
                PKM_Pstar_motor[i] = PKM_Pstar_motor[i] / (fp / lp_XY);
            }
            forward_instantaneous.foward_get_posture(PKM_Pstar_motor[0], PKM_Pstar_motor[1], PKM_Pstar_motor[2], PKM_Pstar_motor[3]);
            PKM_Pstar[0] = -PKM_Pstar_motor[4] + forward_instantaneous.instantaneous_Gx;
            PKM_Pstar[1] = -PKM_Pstar_motor[5] + forward_instantaneous.instantaneous_Gy;
            PKM_Pstar[2] = forward_instantaneous.instantaneous_Gz;
            pnum = Row;
            Inverse.inverse_run(PKM_Pstar, PKM_G, G_X, G_Y, G_Z, G_A, G_B, R);
            string str1 = System.Windows.Forms.Application.StartupPath;
            for (int c = 0; c < 4; c++)//c代表返回上层几次
            {
                str1 = str1.Substring(0, str1.LastIndexOf('\\'));
            }
            str1 = Path.Combine(str1, "data", "processing.txt");
            FileStream fs = new FileStream(str1, FileMode.Create);//验证
            StreamWriter sw = new StreamWriter(fs);
            for (int i = 0; i < Row + 1; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    if (j == 0)
                    {
                        sw.Write("" + Inverse.A1[i, j]);
                    }
                    else
                    {
                        sw.Write("," + Inverse.A1[i, j]);
                    }
                }
                sw.WriteLine();
            }
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
            MessageBox.Show("各轴运动轨迹已生成");
        }
        //启动加工
        int processing = -1;
        private void button_run_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            if (LTSMC.smc_check_done_multicoor(CardNum, 0) == 0)
            {
                MessageBox.Show("电机运动中,请稍后尝试!", "提示");
                return;
            }
            if (spindle_run == 0)
            {
                MessageBox.Show("主轴未启动!", "提示");
                return;
            }
            if (wether_loading_pointa == 0)
            {
                MessageBox.Show("未导入加工轨迹!", "提示");
                return;
            }
            double start = decimal.ToDouble(start_speed.Value) * (2 * fp / (lp_XY + lp_PKM));
            double speed = 50 * (2 * fp / (lp_XY + lp_PKM));                              //加工最高速度50*（2倍）
            double stop = decimal.ToDouble(stop_speed.Value) * (2 * fp / (lp_XY + lp_PKM));
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            for (int i = 0; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_set_alm_mode(CardNum, axis_all[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_write_sevon_pin(CardNum, axis_all[i], 0);//打开伺服使能               
            }
            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    int start_num;
                    ushort[] AxisList = { 4, 5, 0, 1, 2, 3 };       //确定各轴可完成的插补类型，轴4，5，0为主动轴可进行圆弧或螺旋插补运动，直线插补均可
                    LTSMC.smc_conti_set_lookahead_mode(CardNum, 0, 0, 0, 0, 0);
                    LTSMC.smc_conti_open_list(CardNum, 0, 6, AxisList);
                    LTSMC.smc_set_vector_profile_unit(CardNum, 0, speed, speed, acc / 2, dec / 2, speed);//设置插补运动速度参数
                    LTSMC.smc_set_vector_s_profile(CardNum, 0, 0, acc / 2);//设置s曲线平滑时间
                    LTSMC.smc_conti_change_speed_ratio(CardNum, 0, 0.1);    //设置加工起始速度：50*0.1
                    if (Row < 500)
                    {
                        start_num = 0;
                        loadinging_interpolation(start_num, Row);
                        processing = 1;
                        LTSMC.smc_conti_start_list(CardNum, 0);//启动插补
                        LTSMC.smc_conti_close_list(CardNum, 0);//关闭插补缓冲区
                    }
                    else
                    {
                        start_num = 0;
                        loadinging_interpolation(start_num, 500);
                        int loaded_num = 500; int memory_num; int current_loading_num = 40;
                        processing = 1;
                        LTSMC.smc_conti_start_list(CardNum, 0);//启动插补
                        while (loaded_num < Row)
                        {
                            memory_num = LTSMC.smc_conti_remain_space(CardNum, 0);
                            if (memory_num >= current_loading_num)
                            {
                                if (Row - loaded_num >= current_loading_num)
                                {
                                    start_num = loaded_num;
                                    loadinging_interpolation(start_num, current_loading_num);
                                    loaded_num = loaded_num + current_loading_num;
                                }
                                else
                                {
                                    start_num = loaded_num;
                                    loadinging_interpolation(start_num, Row - loaded_num);
                                    loaded_num = Row;
                                }
                            }
                            else
                            {
                                Thread.Sleep(10);
                            }
                        }
                        LTSMC.smc_conti_close_list(CardNum, 0);//关闭插补缓冲区
                    }
                }
                );
        }
        //导入插补点
        public void loadinging_interpolation(int start_num, int loading_point_num)
        {
            ushort[] AxisList = { 4, 5, 0, 1, 2, 3 };
            for (int i = start_num; i < start_num + loading_point_num; i = i + 1)
            {
                if (posi_mode[i] == 0)//直线插补运动模式
                {
                    LTSMC.smc_conti_line_unit(CardNum, 0, 6, AxisList, new double[] { Inverse.D1[i, 4], Inverse.D1[i, 5],Inverse.D1[i, 0], Inverse.D1[i, 1],
                    Inverse.D1[i, 2], Inverse.D1[i, 3] }, 0, 0);//运动模式，0： 相对坐标模式， 1： 绝对坐标模式
                }
                else if (posi_mode[i] == 1)//圆弧插补运动模式（顺时针）
                {
                    LTSMC.smc_conti_arc_move_radius_unit(CardNum, 0, 6, AxisList, new double[] { Inverse.D1[i, 4], Inverse.D1[i, 5],Inverse.D1[i, 0], Inverse.D1[i, 1],
                    Inverse.D1[i, 2], Inverse.D1[i, 3] }, Inverse.D1[i, 6], 0, 0, 0, 0);//运动模式，0： 相对坐标模式， 1： 绝对坐标模式
                }
                else if (posi_mode[i] == -1)//圆弧插补运动模式（逆时针）
                {
                    LTSMC.smc_conti_arc_move_radius_unit(CardNum, 0, 6, AxisList, new double[] { Inverse.D1[i, 4], Inverse.D1[i, 5],Inverse.D1[i, 0], Inverse.D1[i, 1],
                    Inverse.D1[i, 2], Inverse.D1[i, 3] }, Inverse.D1[i, 6], 1, 0, 0, 0);//运动模式，0： 相对坐标模式， 1： 绝对坐标模式
                }
                else
                {
                    MessageBox.Show("轨迹点格式错误!");
                }
            }
        }
        //暂停加工
        private void button_stop0_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (processing == 1)
            {
                LTSMC.smc_conti_pause_list(CardNum, 0);
                button_stop0.Text = "继续加工";
                processing = 0;
            }
            else
            {
                if (SF == 0)
                {
                    MessageBox.Show("伺服未开启!");
                    return;
                }
                LTSMC.smc_conti_start_list(CardNum, 0);
                button_stop0.Text = "暂停加工";
                processing = 1;
            }
        }
        //停止加工
        private void button_stop1_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            button_stop0.Text = "暂停加工";
            progressBar_processing.Value = 0;
            spindle_run = 0;
            LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
            processing = 0;
            wether_loading_pointa = 0;
            LTSMC.smc_conti_stop_list(CardNum, 0, 0);//停止模式， 0： 减速停止， 1： 立即停止
        }
        //判断是否处于加工状态
        public bool CheckMove()
        {
            if (LTSMC.smc_check_done(CardNum, axis_all[0]) == 0 || LTSMC.smc_check_done(CardNum, axis_all[1]) == 0 || LTSMC.smc_check_done(CardNum, axis_all[2]) == 0
                || LTSMC.smc_check_done(CardNum, axis_all[3]) == 0 || LTSMC.smc_check_done(CardNum, axis_all[4]) == 0 || LTSMC.smc_check_done(CardNum, axis_all[5]) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //调整加工速度
        private void processing_speed_Click(object sender, EventArgs e)
        {
            double processing_speed0 = decimal.ToDouble(processing_speed_change.Value);
            double processing_speed = processing_speed0 / 50;
            LTSMC.smc_conti_change_speed_ratio(CardNum, 0, processing_speed);
        }
        //急停
        private void stop_button_Click(object sender, EventArgs e)
        {
            processing = 0;
            wether_loading_pointa = 0;
            LTSMC.smc_emg_stop(CardNum);
        }
        //报警清除
        private void Alarm_clearance_Click(object sender, EventArgs e)
        {
            ushort[] axis = { 0, 1, 2, 3, 4, 5 };
            for (int i = 0; i < axis.Length; i = i + 1)
            {
                LTSMC.smc_clear_stop_reason(CardNum, axis_all[i]);//清除轴停止原因
                ALM[i] = LTSMC.smc_axis_io_status(CardNum, axis_all[i]);
                ALM[i] = ALM[i] % 2;
                if (ALM[i] == 1)
                {
                    MessageBox.Show("不知原因，无法清除");
                    return;
                }
            }
        }                
        //机器回原点
        private void clear_position_button_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (LTSMC.smc_check_done_multicoor(CardNum, 0) == 0)
            {
                MessageBox.Show("电机运动中,请稍后尝试!", "提示");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            comeback();                      
        }
        //回原点
        private void comeback()
        {
            double start = decimal.ToDouble(start_speed.Value) * (2*fp /( lp_XY+ lp_PKM));
            double speed = 8 * (2*fp /( lp_XY+ lp_PKM));
            double stop = decimal.ToDouble(stop_speed.Value) * (2*fp /( lp_XY+ lp_PKM));
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_vector_profile_unit(CardNum, 0, speed, speed, acc, dec, speed);//设置插补运动速度参数
            LTSMC.smc_conti_change_speed_ratio(CardNum, 0, 1);
            for (int i = 0; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_set_alm_mode(CardNum, axis_all[i], 0, 0, 0);//设置报警使能，关闭报警             
            }
            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    LTSMC.smc_conti_set_lookahead_mode(CardNum, 0, 2, 2, 0.1, 1000);
                    LTSMC.smc_conti_open_list(CardNum, 0, 6, axis_all);
                    LTSMC.smc_conti_line_unit(CardNum, 0, 6, axis_all, new double[] { PKM_motor_pos0 * (fp / lp_PKM), PKM_motor_pos0 * (fp / lp_PKM),
                        PKM_motor_pos0 * (fp / lp_PKM),PKM_motor_pos0 * (fp / lp_PKM), 0, 0 }, 1, 0);//运动模式，0： 相对坐标模式， 1： 绝对坐标模式
                    LTSMC.smc_conti_start_list(CardNum, 0);//启动插补
                    LTSMC.smc_conti_close_list(CardNum, 0);//
                }
                );
        }
        //前往工件零点
        private void button1_Click(object sender, EventArgs e)
        {
            if (wether_link == 0)
            {
                MessageBox.Show("请先打开设备!");
                return;
            }
            if (LTSMC.smc_check_done_multicoor(CardNum, 0) == 0)
            {
                MessageBox.Show("电机运动中,请稍后尝试!", "提示");
                return;
            }
            if (SF == 0)
            {
                MessageBox.Show("伺服未开启!");
                return;
            }
            double start = decimal.ToDouble(start_speed.Value) * (2*fp /( lp_XY+ lp_PKM));
            double speed = 8 * (2*fp /( lp_XY+ lp_PKM));
            double stop = decimal.ToDouble(stop_speed.Value) * (2*fp /( lp_XY+ lp_PKM));
            double acc = decimal.ToDouble(t_acc.Value);
            double dec = decimal.ToDouble(t_dec.Value);
            LTSMC.smc_set_vector_profile_unit(CardNum, 0, speed, speed, acc, dec, speed);//设置插补运动速度参数
            LTSMC.smc_conti_change_speed_ratio(CardNum, 0, 1); 
            for (int i = 0; i < axis_all.Length; i = i + 1)
            {
                LTSMC.smc_set_alm_mode(CardNum, axis_all[i], 0, 0, 0);//设置报警使能，关闭报警
                LTSMC.smc_write_sevon_pin(CardNum, axis_all[i], 0);//打开伺服使能              
            }
            ThreadPool.QueueUserWorkItem(
                delegate
                {
                    LTSMC.smc_conti_set_lookahead_mode(CardNum, 0, 2, 2, 0.1, 1000);
                    LTSMC.smc_conti_open_list(CardNum, 0, 6, axis_all);
                    LTSMC.smc_conti_line_unit(CardNum, 0, 6, axis_all, new double[] { workpiece_posZ[0] * (fp / lp_PKM), workpiece_posZ[1] * (fp / lp_PKM),
                    workpiece_posZ[2] * (fp / lp_PKM), workpiece_posZ[3] * (fp / lp_PKM), 0, 0 }, 1, 0);//运动模式，0： 相对坐标模式， 1： 绝对坐标模式
                    LTSMC.smc_conti_start_list(CardNum, 0);//启动插补
                    LTSMC.smc_conti_close_list(CardNum, 0);//
                }
                );
        }                               
        //实时显示
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (wether_link == 0 || groupBox_running.Visible == false)
             return;
            for (int i = 0; i < 4; i = i + 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[i], ref pos0[i]);//当前编码器位置
                pos0[i] = pos0[i] / (fp / lp_PKM);
            }
            forward_instantaneous.foward_get_posture(pos0[0], pos0[1], pos0[2], pos0[3]);
            GX_position.Text = forward_instantaneous.instantaneous_Gx.ToString("F6");
            GX0_position.Text = forward_instantaneous.instantaneous_Gx.ToString("F6");
            GY_position.Text = forward_instantaneous.instantaneous_Gy.ToString("F6");
            GY0_position.Text = forward_instantaneous.instantaneous_Gy.ToString("F6");
            GZ_position.Text = forward_instantaneous.instantaneous_Gz.ToString("F6");         //刀尖点位置
            GZ0_position.Text = forward_instantaneous.instantaneous_Gz.ToString("F6");         //刀尖点位置
            PKMA_position.Text = forward_instantaneous.instantaneous_psi.ToString("F6");
            PKMA0_position.Text = forward_instantaneous.instantaneous_psi.ToString("F6");

            PKMB_position.Text = forward_instantaneous.instantaneous_theta.ToString();
            PKMB0_position.Text = forward_instantaneous.instantaneous_theta.ToString();
            PKMZ_position.Text = forward_instantaneous.instantaneous_z.ToString();        //动平台姿态      
            //
            if (LTSMC.smc_check_done(CardNum, 0) == 0)
            {
                textBox_1.Text = "运行中";
            }
            else
            { textBox_1.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[0], ref vel[0]);//当前速度
            vel[0] = vel[0] / (fp / lp_PKM);
            textBox1.Text = vel[0].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[0], ref pos[0]);//当前指令位置
            pos[0] = pos[0] / (fp / lp_PKM);
            textBox7.Text = pos[0].ToString();
            textBox_7.Text = pos0[0].ToString();
            //
            if (LTSMC.smc_check_done(CardNum, 1) == 0)
            {
                textBox_2.Text = "运行中";
            }
            else
            { textBox_2.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[1], ref vel[1]);//当前速度
            vel[1] = vel[1] / (fp / lp_PKM);
            textBox2.Text = vel[1].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[1], ref pos[1]);//当前指令位置
            pos[1] = pos[1] / (fp / lp_PKM);
            textBox8.Text = pos[1].ToString();
            textBox_8.Text = pos0[1].ToString();
            //
            if (LTSMC.smc_check_done(CardNum, 2) == 0)
            {
                textBox_3.Text = "运行中";
            }
            else
            { textBox_3.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[2], ref vel[2]);//当前速度
            vel[2] = vel[2] / (fp / lp_PKM);
            textBox3.Text = vel[2].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[2], ref pos[2]);//当前指令位置
            pos[2] = pos[2] / (fp / lp_PKM);
            textBox9.Text = pos[2].ToString();
            textBox_9.Text = pos0[2].ToString();
            //
            if (LTSMC.smc_check_done(CardNum, 3) == 0)
            {
                textBox_4.Text = "运行中";
            }
            else
            { textBox_4.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[3], ref vel[3]);//当前速度
            vel[3] = vel[3] / (fp / lp_PKM);
            textBox4.Text = vel[3].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[3], ref pos[3]);//当前指令位置
            pos[3] = pos[3] / (fp / lp_PKM);
            textBox10.Text = pos[3].ToString();
            textBox_10.Text = pos0[3].ToString();
            //
            if (LTSMC.smc_check_done(CardNum, 4) == 0)
            {
                textBox_5.Text = "运行中";
            }
            else
            { textBox_5.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[4], ref vel[4]);//当前速度
            vel[4] = vel[4] / (fp / lp_XY);
            textBox5.Text = vel[4].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[4], ref pos[4]);//当前指令位置
            pos[4] = pos[4] / (fp / lp_XY);
            textBox11.Text = pos[4].ToString();
            LTSMC.smc_get_encoder_unit(CardNum, axis_all[4], ref pos0[4]);//当前编码器位置
            pos0[4] = pos0[4] / (fp / lp_XY);
            textBox_11.Text = pos0[4].ToString();
            //
            if (LTSMC.smc_check_done(CardNum, 5) == 0)
            {
                textBox_6.Text = "运行中";
            }
            else
            { textBox_6.Text = "无运行"; }
            LTSMC.smc_read_current_speed_unit(CardNum, axis_all[5], ref vel[5]);//当前速度
            vel[5] = vel[5] / (fp / lp_XY);
            textBox6.Text = vel[5].ToString();
            LTSMC.smc_get_position_unit(CardNum, axis_all[5], ref pos[5]);//当前指令位置
            pos[5] = pos[5] / (fp / lp_XY);
            textBox12.Text = pos[5].ToString();
            LTSMC.smc_get_encoder_unit(CardNum, axis_all[5], ref pos0[5]);//当前编码器位置
            pos0[5] = pos0[5] / (fp / lp_XY);
            textBox_12.Text = pos0[5].ToString();
            //                                              
        }
        //实时监测、动作
        private void timer2_Tick(object sender, EventArgs e)
        {            
            if (processing == 1)
            {
                datecount = LTSMC.smc_conti_read_current_mark(CardNum, 0);
                int progress_processing = datecount * 100 / Row;
                progressBar_processing.Value = progress_processing;
            }            
            textBox_pointcount.Text = Convert.ToString(datecount);        //显示数据点数
            textBox18.Text = "P" + Convert.ToString(teached_point_num);   //显示当前示教点位
            if (CheckMove() && processing == 1)
            {
                check_move.Text = "正在加工";
            }
            if (handwheel == 1)
            {
                check_move.Text = "手轮已启动";
            } 
            else
            {
                check_move.Text = "空闲中";
            }
            if (datecount == Row && processing == 1)
            {
                processing = 0;
                wether_loading_pointa = 0;
                spindle_run = 0;
                LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
                MessageBox.Show("加工完成!");
                progressBar_processing.Value = 0;
            }
            if (datecount ==0 && Row!=0 && processing == 1)
            {
                processing = 0;
                wether_loading_pointa = 0;
                spindle_run = 0;
                LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
                MessageBox.Show("加工异常停止!");
            }
            if (spindle_run == 1)                                    //主轴在线变速
            {
                fDuty = decimal.ToDouble(spindle_speed.Value);
                fDuty = fDuty / 12000.0;
                LTSMC.smc_set_pwm_output(CardNum, 0, fDuty, 100);
            }
            for (int i = 0; i < axis_all.Length; i = i + 1)          //设置报警信号
            {
                ALM[i] = LTSMC.smc_axis_io_status(CardNum, axis_all[i]);
                ALM[i] = ALM[i] % 2;
                int ct = i + 1;
                if (ALM[i] == 1)
                {
                    LTSMC.smc_emg_stop(CardNum);
                    spindle_run = 0;
                    LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
                    processing = -1;
                    check_move.Text = "系统异常";
                    MessageBox.Show("驱动器报警!轴号：" + ct);
                    wether_link = 0;
                    link_button.Text = "打开设备";
                    LTSMC.smc_board_close(CardNum);
                    timer2.Stop();                   
                }
            }   
        }
        //程序关闭
        private void main_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult result_zero = MessageBox.Show("机器是否已回零？", "提示：",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result_zero == DialogResult.No)
            {
                DialogResult result_ifzero = MessageBox.Show("机器是否现在回零？", "提示：",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result_ifzero == DialogResult.Yes)
                {
                    comeback();
                }
                main main = new main();
                main.Show();
                return;
            }
            if (result_zero == DialogResult.Yes)
            {
                LTSMC.smc_conti_stop_list(CardNum, 0, 0);//停止模式， 0： 减速停止， 1： 立即停止
                spindle_run = 0;
                LTSMC.smc_set_pwm_output(CardNum, 0, 0, 0);
                LTSMC.smc_handwheel_set_mode(CardNum, 0, 0);//设置手轮运动模式，硬件或软件模式
                LTSMC.smc_handwheel_stop(CardNum);//手轮关闭
                for (int i = 0; i < axis_all.Length; i = i + 1)
                {
                    LTSMC.smc_write_sevon_pin(CardNum, axis_all[i], 1);//关闭伺服使能               
                }
                SF = 0;
                Application.Exit();
            }            
        }
        //机床尺度按钮
        private void button_dimention_Click(object sender, EventArgs e)
        {            
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            dimention_Box.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = true;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = false;
            button_dimention.BackColor = Color.Green;
            calibration.BackColor = Color.Transparent;
            button_single.BackColor = Color.Transparent;
            Running_Status.BackColor = Color.Transparent;
            Workpiece_system.BackColor = Color.Transparent;
            button_processing.BackColor = Color.Transparent;
        }
        //机器校零按钮
        private void calibration_Click(object sender, EventArgs e)
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            calibration_Box.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = false;
            calibration_Box.Visible = true;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = false;
            button_dimention.BackColor = Color.Transparent;
            calibration.BackColor = Color.Green;
            button_single.BackColor = Color.Transparent;
            Running_Status.BackColor = Color.Transparent;
            Workpiece_system.BackColor = Color.Transparent;
            button_processing.BackColor = Color.Transparent;
        }
        //示教功能按钮
        private void button_single_Click(object sender, EventArgs e)
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            groupBox_teach.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = false;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = true;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = false;
            button_dimention.BackColor = Color.Transparent;
            calibration.BackColor = Color.Transparent;
            button_single.BackColor = Color.Green;
            Running_Status.BackColor = Color.Transparent;
            Workpiece_system.BackColor = Color.Transparent;
            button_processing.BackColor = Color.Transparent;
        }
        //运行状态按钮
        private void Running_Status_Click(object sender, EventArgs e)
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            groupBox_running.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = false;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = true;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = false;
            button_dimention.BackColor = Color.Transparent;
            calibration.BackColor = Color.Transparent;
            button_single.BackColor = Color.Transparent;
            Running_Status.BackColor = Color.Green;
            Workpiece_system.BackColor = Color.Transparent;
            button_processing.BackColor = Color.Transparent;
        }
        //对刀按钮
        private void Workpiece_system_Click(object sender, EventArgs e)
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            groupBox_tool.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = false;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = true;
            groupBox_processing.Visible = false;
            button_dimention.BackColor = Color.Transparent;
            calibration.BackColor = Color.Transparent;
            button_single.BackColor = Color.Transparent;
            Running_Status.BackColor = Color.Transparent;
            Workpiece_system.BackColor = Color.Green;
            button_processing.BackColor = Color.Transparent;
        }
        //加工按钮
        private void button_processing_Click(object sender, EventArgs e)
        {
            int x = 385;
            int y = 150;
            Point newPoint = new Point();
            newPoint.X = x;
            newPoint.Y = y;
            groupBox_processing.Location = newPoint;//定义groupbox的位置
            dimention_Box.Visible = false;
            calibration_Box.Visible = false;
            groupBox_teach.Visible = false;
            groupBox_running.Visible = false;
            groupBox_tool.Visible = false;
            groupBox_processing.Visible = true;
            button_dimention.BackColor = Color.Transparent;
            calibration.BackColor = Color.Transparent;
            button_single.BackColor = Color.Transparent;
            Running_Status.BackColor = Color.Transparent;
            Workpiece_system.BackColor = Color.Transparent;
            button_processing.BackColor = Color.Green;
        }

        //正解验证
        int Row0; int Col0; double[,] Date0; double[,] Date1;
        private void forward_correcting_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Title = "打开数据文件";
            openDlg.Filter = "数据文件 (*.txt)|*.txt|All|*.*";
            bool result = false;
            string FilePath;
            string[] TempData;
            string[] TempArry;
            Row0 = 0;
            Col0 = 0;
            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                FilePath = openDlg.FileName;
                TempData = System.IO.File.ReadAllLines(FilePath, System.Text.Encoding.Default);

                Row0 = TempData.GetLength(0);
                TempArry = TempData[1].Split(',');
                Col0 = TempArry.GetLength(0);
                Date0 = new double[Row0, Col0];
                for (int i = 0; i < Row0; i++)
                {
                    string[] Arry = TempData[i].Split(',');
                    for (int j = 0; j < Col0; j++)
                    {
                        Date0[i, j] = Convert.ToDouble(Arry[j]);
                    }
                }

                result = true;
            }
            if (result)
            {
                Date1 = new double[Row0, 9];
                for (int j = 0; j < Row0; j++)
                {
                    forward_instantaneous.foward_get_posture(Date0[j, 0], Date0[j, 1], Date0[j, 2], Date0[j, 3]);
                    Date1[j, 0] = Date0[j, 0]; Date1[j, 1] = Date0[j, 1]; Date1[j, 2] = Date0[j, 2];
                    Date1[j, 3] = forward_instantaneous.instantaneous_psi; Date1[j, 4] = forward_instantaneous.instantaneous_theta; Date1[j, 5] = forward_instantaneous.instantaneous_z;
                    Date1[j, 6] = forward_instantaneous.instantaneous_Gx; Date1[j, 7] = forward_instantaneous.instantaneous_Gy; Date1[j, 8] = forward_instantaneous.instantaneous_Gz;
                }
                MessageBox.Show("正解求解完成完成！");
                //保存                
                string str1 = System.Windows.Forms.Application.StartupPath;
                for (int c = 0; c < 4; c++)//c代表返回上层几次
                {
                    str1 = str1.Substring(0, str1.LastIndexOf('\\'));
                }
                str1 = Path.Combine(str1, "data", "correcring.txt");
                FileStream fs = new FileStream(str1, FileMode.Create);//验证
                StreamWriter sw = new StreamWriter(fs);
                for (int i = 0; i < Row0; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        if (j == 0)
                        {
                            sw.Write("" + Date1[i, j]);
                        }
                        else
                        {
                            sw.Write("," + Date1[i, j]);
                        }
                    }
                    sw.WriteLine();
                }
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();
                MessageBox.Show("各支链电机位置已生成");
            }
            else
            {
                MessageBox.Show("读取支链电机位置错误！");
            }
        }

        int x0, y0;
        //实时显示加工轨迹
        private void timer3_Tick(object sender, EventArgs e)
        {
            if (wether_loading_pointa == 0)
                return;
            int width = picture_processing.Width;
            int height = picture_processing.Height;
            Bitmap bm = new Bitmap(width, height);
            Graphics g = picture_processing.CreateGraphics();
            //Graphics g = Graphics.FromImage(bm);
            Matrix matrix = new Matrix(1, 0, 0, -1, 0, height);
            g.Transform = matrix;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            //网格绘制  X Y  红色
            Pen pen = new Pen(Color.Red);
            g.DrawLine(pen, new Point(0, 20), new Point(width, 20));//X
            g.DrawLine(pen, new Point(20, 0), new Point(20, height));//Y
            //0的位置
            SolidBrush brush = new SolidBrush(Color.Black);
            g.ResetTransform();
            g.DrawString("0", this.Font, brush, 5, height - 15);
            g.Transform = matrix;
            //
            pen = new Pen(Color.Green);
            pen.DashPattern = new float[] { 3f, 5f };
            int n = (int)((width - 20) / 50);
            int b = 15;//第一条线的边距
            //X
            for (int i = 0; i < n; i++)
            {
                int _x = (i + 1) * 50 + b;
                g.DrawLine(pen, new Point(_x, 0), new Point(_x, height));
                g.ResetTransform();
                string txt = ((i + 1) * 100).ToString();
                g.DrawString(txt, this.Font, brush, _x - 20, height - 15);
                g.Transform = matrix;
            }
            //Y
            n = (int)((height - 20) / 50);
            for (int i = 0; i < n; i++)
            {
                int _y = (i + 1) * 50 + b;
                g.DrawLine(pen, new Point(0, _y), new Point(width, _y));
                g.ResetTransform();
                string txt = ((i + 1) * 100).ToString();
                g.DrawString(txt, this.Font, brush, 0, height - _y + 5);//字的坐标
                g.Transform = matrix;
            }
            //是否开始加工
            if (processing == 1)
            {
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[4], ref pos0[4]);//当前编码器位置
                pos0[4] = pos0[4] / (fp / lp_XY);
                LTSMC.smc_get_encoder_unit(CardNum, axis_all[5], ref pos0[5]);//当前编码器位置
                pos0[5] = pos0[5] / (fp / lp_XY);
                int x = Convert.ToInt32(forward_instantaneous.instantaneous_Gy-pos0[5]);//实时绘制
                int y = Convert.ToInt32(forward_instantaneous.instantaneous_Gx-pos0[4]);
                int a = 4; int c = 20;
                x = x * a + c;
                y = y * a + c;
                g.DrawLine(new Pen(Color.Black, 2), x0, y0, x, y);
                x0 = x;
                y0 = y;
                //坐标的变换
                g.ResetTransform();
                g.Transform = matrix;
            }
        }

      


    }
}
