﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Leadshine.SMC.IDE.Motion;
using System.Threading;
using System.Drawing.Drawing2D;
using MathNet.Numerics.LinearAlgebra;
using System.IO;

namespace My_control
{
    class forward_instantaneous
    {
        public forward_instantaneous()
        {

        }
        double con;

        double[] a;                   // 静平台半径;
        double[] b;                   // 动平台半径;
        double e_tool;                //刀身长度，动平台原点到刀尖点距离，待确定

        //瞬时姿态记忆
        public double instantaneous_psi, instantaneous_theta, instantaneous_z;        //并联动力头姿态参数
        public double instantaneous_Gx, instantaneous_Gy, instantaneous_Gz;           //刀尖点相对于静坐标系坐标
        public void foward_get_posture(double d1, double d2, double d3, double d4)
        {
            //机床尺度确定
            con = Math.PI / 180;
            a = new double[4]; b = new double[4];
            a[0] = main.a1; a[1] = main.a2; a[2] = main.a3; a[3] = main.a4;   // 静平台半径;
            b[0] = main.b1; b[1] = main.b2; b[2] = main.b3; b[3] = main.b4;   // 动平台半径;

            e_tool = main.e_tool;                     //刀身长度，动平台原点到刀尖点距离，待确定
            foward_calculate(d1, d2, d3, d4);
        }
        public void foward_calculate(double d1, double d2, double d3, double d4)
        {
            //DateTime beforDT = System.DateTime.Now;
            double k1, k2, k3, k4, k5, k51,k6, k7, k8, k9, k10, k11, k12, k13,k14,k15;
            double k00, g0= 0;
            double g1, g2, g3;
            double rang1 = Math.Cos(Math.PI / 4); double rang2 = 1;

            k1 = d4 * d4 - d3 * d3; k2 = 4 * a[2]; k3 = d3 * d3 + d4 * d4;
            k4 = 2 * Math.Pow((d4 * d4 - d3 * d3) / (4 * a[2]), 2) + 2 * a[2] * a[2] + 2 * b[2] * b[2];
            k5 = -4 * a[2] * b[2]; k51 = -4 * a[2] * b[2]; k6 = k3 - k4; k7 = 2 * Math.Pow(k1 / k2, 2);
            k8 = -(k6 + k7) / k5; k9 = k6 / k5; k10 = -Math.Pow(k8, 2) / 3 - 1;
            k11 = -Math.Pow(k8 / 3, 3) + Math.Pow(k8, 3) / 9 + k8 / 3 + k9;
            if(d3==d4)
            {
                instantaneous_theta = 0;
                instantaneous_z = Math.Sqrt((d4 * d4 + d3 * d3 + 4 * a[2] * b[2] - 2 * a[2] * a[2] - 2 * b[2] * b[2])/2);
                instantaneous_psi = Math.Asin((d2 * d2 - d1 * d1) / (4 * b[0] * instantaneous_z));
            }
            else 
            {
                double n = 0.3333333333333333;
                k00=Math.Pow(k11 / 2, 2) + Math.Pow(k10 / 3, 3);
                if (k00 > 0)
                {
                    k12 = -k11 / 2 - Math.Pow(k00, 0.5);
                    k13 = -k11 / 2 + Math.Pow(k00, 0.5);
                    g1 = Math.Pow(k12, n) + Math.Pow(k13, n);                    
                    if (rang1 < g1 - k8 / 3 && g1 - k8 / 3 < rang2)
                    {
                        g0 = g1 - k8 / 3;
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k001=：" + k00);
                    }
                }
                if(k00==0)
                {
                    k12 = -k11 / 2 - Math.Pow(k00, 0.5);
                    k13 = -k11 / 2 + Math.Pow(k00, 0.5);
                    g1 = -Math.Pow(k11, n) / Math.Pow(2, n+1);
                    g2 = Math.Pow(k11 / 2, n);
                    if (rang1 < g1 - k8 / 3 && g1 - k8 / 3 < rang2)
                    {
                        g0 = g1 - k8 / 3;
                    }
                    else if (rang1 < g2 - k8 / 3 && g2 - k8 / 3 < rang2)
                    {
                        g0 = g2 - k8 / 3;
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k002=：" + k00);
                    }
                }
                if (k00 < 0)
                {
                    k14 = Math.Pow((-k10 )/ 3, 1.5);
                    k15 = Math.Acos((-k11 )/ (2 * k14)) / 3;                   
                    g1 = 2 * Math.Pow(k14, n) * (Math.Cos(k15));//待修正
                    g2 = 2 * Math.Pow(k14, n) * Math.Cos(k15 + 2 * Math.PI / 3);
                    g3 = 2 * Math.Pow(k14, n) * Math.Cos(k15 + 4 * Math.PI / 3);
                    if (rang1 < g1 - k8 / 3 && g1 - k8 / 3 < rang2)
                    {
                        g0 = g1 - k8 / 3;
                    }
                    else if (rang1 < g2 - k8 / 3 && g2 - k8 / 3 < rang2)
                    {
                        g0 = g2 - k8 / 3;
                    }
                    else if (rang1 < g3 - k8 / 3 && g3 - k8 / 3 < rang2)
                    {
                        g0 = g3 - k8 / 3;
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k003=：" + k00);
                    }
                }

                instantaneous_theta = Math.Sign(d4 - d3) * Math.Acos(g0);
                instantaneous_z = Math.Sqrt((d4 * d4 + d3 * d3 + 4 * a[2] * b[2] * Math.Cos(instantaneous_theta) - k4) / 2);
                instantaneous_psi = Math.Asin((d2 * d2 - d1 * d1) * Math.Cos(instantaneous_theta) / (4 * b[0] * instantaneous_z));
            }

            var JZ = Matrix<double>.Build;
            var XL = Vector<double>.Build;
            double instantaneous_phi = 0;
            double instantaneous_x = instantaneous_z * Math.Tan(instantaneous_theta);
            double instantaneous_y = 0;                                    //牵连运动

            double[] RotateA = { 1, 0, 0, 0, Math.Cos(instantaneous_psi), -Math.Sin(instantaneous_psi), 0, Math.Sin(instantaneous_psi), Math.Cos(instantaneous_psi) };
            double[] RotateB = { Math.Cos(instantaneous_theta), 0, Math.Sin(instantaneous_theta), 0, 1, 0, -Math.Sin(instantaneous_theta), 0, Math.Cos(instantaneous_theta) };
            double[] RotateC = { Math.Cos(instantaneous_phi), -Math.Sin(instantaneous_phi), 0, Math.Sin(instantaneous_phi), Math.Cos(instantaneous_phi), 0, 0, 0, 1 };

            var RZ = JZ.Dense(3, 3, RotateC).Transpose();
            var RY = JZ.Dense(3, 3, RotateB).Transpose();
            var RX = JZ.Dense(3, 3, RotateA).Transpose();
            var R = RZ * RY * RX;                         //姿态变换矩阵

            var vp = XL.Dense(3); vp[0] = instantaneous_x; vp[1] = instantaneous_y; vp[2] = instantaneous_z;       //动坐标系原点相对于静坐标系原点的位置向量
            var vz0 = XL.Dense(3); vz0[0] = 0; vz0[1] = 0; vz0[2] = 1;   //刀具方向向量
            var vz = R * vz0;
            var vq0 = vp + e_tool * vz;                                 //刀尖点相对于静坐标系坐标
            instantaneous_Gx = vq0[0]; instantaneous_Gy = vq0[1]; instantaneous_Gz = vq0[2];
            DateTime afterDT = System.DateTime.Now;
            //TimeSpan ts = afterDT.Subtract(beforDT);
            instantaneous_psi = instantaneous_psi / con; instantaneous_theta = instantaneous_theta / con;             //角度转弧度
            //MessageBox.Show("正解花费时间" + ts);
        }




    }
}
