﻿namespace My_control
{
    partial class main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.Xbutton = new System.Windows.Forms.Button();
            this.stop_button = new System.Windows.Forms.Button();
            this.link_button = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_change_speed = new System.Windows.Forms.Button();
            this.t_dec = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.t_acc = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.stop_speed = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.run_speed = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.start_speed = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.clear_position_button = new System.Windows.Forms.Button();
            this.Alarm_clearance = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_12 = new System.Windows.Forms.TextBox();
            this.textBox_11 = new System.Windows.Forms.TextBox();
            this.textBox_10 = new System.Windows.Forms.TextBox();
            this.textBox_9 = new System.Windows.Forms.TextBox();
            this.textBox_8 = new System.Windows.Forms.TextBox();
            this.textBox_7 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox_6 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox_5 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox_4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox_3 = new System.Windows.Forms.TextBox();
            this.textBox_2 = new System.Windows.Forms.TextBox();
            this.textBox_1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.processing_speed = new System.Windows.Forms.Button();
            this.processing_speed_change = new System.Windows.Forms.NumericUpDown();
            this.button_stop0 = new System.Windows.Forms.Button();
            this.button_stop1 = new System.Windows.Forms.Button();
            this.textBox_pointcount = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button_datainput = new System.Windows.Forms.Button();
            this.textBox_pointnum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button_run = new System.Windows.Forms.Button();
            this.spindle_speed = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.button_spindle_run = new System.Windows.Forms.Button();
            this.button_spindle_stop = new System.Windows.Forms.Button();
            this.Ybutton = new System.Windows.Forms.Button();
            this.Zbutton = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button_dimention = new System.Windows.Forms.Button();
            this.value_tool = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button_single = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tool_change = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.value_rtool = new System.Windows.Forms.TextBox();
            this.单轴控制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置工件坐标ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.机床尺度定义ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox_processing = new System.Windows.Forms.GroupBox();
            this.label102 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.picture_processing = new System.Windows.Forms.PictureBox();
            this.label101 = new System.Windows.Forms.Label();
            this.progressBar_processing = new System.Windows.Forms.ProgressBar();
            this.calibration_Box = new System.Windows.Forms.GroupBox();
            this.confirm_zero = new System.Windows.Forms.Button();
            this.label85 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox_running = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.PKMZ_position = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.GX_position = new System.Windows.Forms.TextBox();
            this.PKMB_position = new System.Windows.Forms.TextBox();
            this.GY_position = new System.Windows.Forms.TextBox();
            this.PKMA_position = new System.Windows.Forms.TextBox();
            this.GZ_position = new System.Windows.Forms.TextBox();
            this.groupBox_teach = new System.Windows.Forms.GroupBox();
            this.programming = new System.Windows.Forms.TextBox();
            this.button_continue = new System.Windows.Forms.Button();
            this.button_stoping0 = new System.Windows.Forms.Button();
            this.button_edit = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.GX0_position = new System.Windows.Forms.TextBox();
            this.PKMB0_position = new System.Windows.Forms.TextBox();
            this.GY0_position = new System.Windows.Forms.TextBox();
            this.PKMA0_position = new System.Windows.Forms.TextBox();
            this.GZ0_position = new System.Windows.Forms.TextBox();
            this.button_stoping = new System.Windows.Forms.Button();
            this.button_running = new System.Windows.Forms.Button();
            this.label96 = new System.Windows.Forms.Label();
            this.teached_point = new System.Windows.Forms.ComboBox();
            this.moveto = new System.Windows.Forms.Button();
            this.teaching = new System.Windows.Forms.Button();
            this.label97 = new System.Windows.Forms.Label();
            this.teaching_point = new System.Windows.Forms.ComboBox();
            this.groupBox_tool = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label100 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.G0Y = new System.Windows.Forms.TextBox();
            this.G0Z = new System.Windows.Forms.TextBox();
            this.G0X = new System.Windows.Forms.TextBox();
            this.check_move = new System.Windows.Forms.TextBox();
            this.close_SF = new System.Windows.Forms.Button();
            this.open_SF = new System.Windows.Forms.Button();
            this.Running_Status = new System.Windows.Forms.Button();
            this.Workpiece_system = new System.Windows.Forms.Button();
            this.button_processing = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.close_handwheel = new System.Windows.Forms.Button();
            this.open_handwheel = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dimention_Box = new System.Windows.Forms.GroupBox();
            this.dimention_keep = new System.Windows.Forms.Button();
            this.dimention_change = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.value_d4max = new System.Windows.Forms.TextBox();
            this.value_d4min = new System.Windows.Forms.TextBox();
            this.value_d3max = new System.Windows.Forms.TextBox();
            this.value_d3min = new System.Windows.Forms.TextBox();
            this.value_d2max = new System.Windows.Forms.TextBox();
            this.value_d2min = new System.Windows.Forms.TextBox();
            this.value_d1max = new System.Windows.Forms.TextBox();
            this.value_d1min = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.value_U42max = new System.Windows.Forms.TextBox();
            this.value_U42min = new System.Windows.Forms.TextBox();
            this.value_S32max = new System.Windows.Forms.TextBox();
            this.value_S32min = new System.Windows.Forms.TextBox();
            this.value_U22max = new System.Windows.Forms.TextBox();
            this.value_U22min = new System.Windows.Forms.TextBox();
            this.value_U12max = new System.Windows.Forms.TextBox();
            this.value_U12min = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.value_U4max = new System.Windows.Forms.TextBox();
            this.value_U4min = new System.Windows.Forms.TextBox();
            this.value_S3max = new System.Windows.Forms.TextBox();
            this.value_S3min = new System.Windows.Forms.TextBox();
            this.value_U2max = new System.Windows.Forms.TextBox();
            this.value_U2min = new System.Windows.Forms.TextBox();
            this.value_U1max = new System.Windows.Forms.TextBox();
            this.value_U1min = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.value_R4max = new System.Windows.Forms.TextBox();
            this.value_R4min = new System.Windows.Forms.TextBox();
            this.value_R3max = new System.Windows.Forms.TextBox();
            this.value_R3min = new System.Windows.Forms.TextBox();
            this.value_R2max = new System.Windows.Forms.TextBox();
            this.value_R2min = new System.Windows.Forms.TextBox();
            this.value_R1max = new System.Windows.Forms.TextBox();
            this.value_R1min = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.value_b4 = new System.Windows.Forms.TextBox();
            this.value_b2 = new System.Windows.Forms.TextBox();
            this.value_b3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.value_b1 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.value_a4 = new System.Windows.Forms.TextBox();
            this.value_a2 = new System.Windows.Forms.TextBox();
            this.value_a3 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.value_a1 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.calibration = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.forward_correcting = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.t_dec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_acc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.run_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.processing_speed_change)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spindle_speed)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox_processing.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_processing)).BeginInit();
            this.calibration_Box.SuspendLayout();
            this.groupBox_running.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox_teach.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox_tool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.dimention_Box.SuspendLayout();
            this.SuspendLayout();
            // 
            // Xbutton
            // 
            this.Xbutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Xbutton.Location = new System.Drawing.Point(529, 136);
            this.Xbutton.Name = "Xbutton";
            this.Xbutton.Size = new System.Drawing.Size(144, 39);
            this.Xbutton.TabIndex = 0;
            this.Xbutton.Text = "设置工件X坐标";
            this.Xbutton.UseVisualStyleBackColor = true;
            this.Xbutton.Click += new System.EventHandler(this.Xbutton_Click_1);
            this.Xbutton.MouseEnter += new System.EventHandler(this.Xbutton_MouseEnter);
            // 
            // stop_button
            // 
            this.stop_button.BackColor = System.Drawing.Color.Red;
            this.stop_button.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Bold);
            this.stop_button.ForeColor = System.Drawing.Color.Black;
            this.stop_button.Location = new System.Drawing.Point(842, 11);
            this.stop_button.Name = "stop_button";
            this.stop_button.Size = new System.Drawing.Size(92, 42);
            this.stop_button.TabIndex = 1;
            this.stop_button.Text = "急  停";
            this.stop_button.UseVisualStyleBackColor = false;
            this.stop_button.Click += new System.EventHandler(this.stop_button_Click);
            // 
            // link_button
            // 
            this.link_button.Font = new System.Drawing.Font("宋体", 18F);
            this.link_button.Location = new System.Drawing.Point(12, 12);
            this.link_button.Name = "link_button";
            this.link_button.Size = new System.Drawing.Size(150, 70);
            this.link_button.TabIndex = 2;
            this.link_button.Text = "连接控制器";
            this.link_button.UseVisualStyleBackColor = true;
            this.link_button.Click += new System.EventHandler(this.link_button_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("宋体", 14F);
            this.button12.Location = new System.Drawing.Point(110, 247);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(65, 40);
            this.button12.TabIndex = 31;
            this.button12.Text = "B-";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button12_MouseDown);
            this.button12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button12_MouseUp);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("宋体", 14F);
            this.button11.Location = new System.Drawing.Point(23, 247);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(65, 40);
            this.button11.TabIndex = 30;
            this.button11.Text = "B+";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button11_MouseDown);
            this.button11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button11_MouseUp);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 14F);
            this.button10.Location = new System.Drawing.Point(110, 192);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(65, 40);
            this.button10.TabIndex = 29;
            this.button10.Text = "A-";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button10_MouseDown);
            this.button10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button10_MouseUp);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 14F);
            this.button9.Location = new System.Drawing.Point(23, 192);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(65, 40);
            this.button9.TabIndex = 28;
            this.button9.Text = "A+";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button9_MouseDown);
            this.button9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button9_MouseUp);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("宋体", 14F);
            this.button8.Location = new System.Drawing.Point(110, 141);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(65, 40);
            this.button8.TabIndex = 27;
            this.button8.Text = "Z-";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button8_MouseDown);
            this.button8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button8_MouseUp);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("宋体", 14F);
            this.button7.Location = new System.Drawing.Point(23, 141);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(65, 40);
            this.button7.TabIndex = 26;
            this.button7.Text = "Z+";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button7_MouseDown);
            this.button7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button7_MouseUp);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("宋体", 14F);
            this.button6.Location = new System.Drawing.Point(110, 33);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(65, 40);
            this.button6.TabIndex = 25;
            this.button6.Text = "X-";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button6_MouseDown);
            this.button6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button6_MouseUp);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("宋体", 14F);
            this.button5.Location = new System.Drawing.Point(23, 33);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(65, 40);
            this.button5.TabIndex = 24;
            this.button5.Text = "X+";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button5_MouseDown);
            this.button5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button5_MouseUp);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 14F);
            this.button4.Location = new System.Drawing.Point(110, 88);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(65, 40);
            this.button4.TabIndex = 23;
            this.button4.Text = "Y-";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button4_MouseDown);
            this.button4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button4_MouseUp);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 14F);
            this.button3.Location = new System.Drawing.Point(23, 88);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(65, 40);
            this.button3.TabIndex = 22;
            this.button3.Text = "Y+";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
            this.button3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button3_MouseUp);
            // 
            // button_change_speed
            // 
            this.button_change_speed.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_change_speed.Location = new System.Drawing.Point(510, 13);
            this.button_change_speed.Name = "button_change_speed";
            this.button_change_speed.Size = new System.Drawing.Size(92, 39);
            this.button_change_speed.TabIndex = 39;
            this.button_change_speed.Text = "在线变速";
            this.button_change_speed.UseVisualStyleBackColor = true;
            this.button_change_speed.Click += new System.EventHandler(this.button_change_speed_Click);
            // 
            // t_dec
            // 
            this.t_dec.DecimalPlaces = 3;
            this.t_dec.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.t_dec.Location = new System.Drawing.Point(824, 23);
            this.t_dec.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.t_dec.Name = "t_dec";
            this.t_dec.Size = new System.Drawing.Size(81, 26);
            this.t_dec.TabIndex = 1;
            this.t_dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_dec.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(742, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "减速时间:";
            // 
            // t_acc
            // 
            this.t_acc.DecimalPlaces = 3;
            this.t_acc.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.t_acc.Location = new System.Drawing.Point(640, 22);
            this.t_acc.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.t_acc.Name = "t_acc";
            this.t_acc.Size = new System.Drawing.Size(81, 26);
            this.t_acc.TabIndex = 1;
            this.t_acc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_acc.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(561, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "加速时间:";
            // 
            // stop_speed
            // 
            this.stop_speed.Location = new System.Drawing.Point(458, 23);
            this.stop_speed.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.stop_speed.Name = "stop_speed";
            this.stop_speed.Size = new System.Drawing.Size(81, 26);
            this.stop_speed.TabIndex = 1;
            this.stop_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(378, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "停止速度:";
            // 
            // run_speed
            // 
            this.run_speed.DecimalPlaces = 1;
            this.run_speed.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.run_speed.Location = new System.Drawing.Point(275, 21);
            this.run_speed.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.run_speed.Name = "run_speed";
            this.run_speed.Size = new System.Drawing.Size(81, 26);
            this.run_speed.TabIndex = 1;
            this.run_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.run_speed.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(195, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "运行速度:";
            // 
            // start_speed
            // 
            this.start_speed.Location = new System.Drawing.Point(89, 23);
            this.start_speed.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.start_speed.Name = "start_speed";
            this.start_speed.Size = new System.Drawing.Size(81, 26);
            this.start_speed.TabIndex = 1;
            this.start_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "起始速度:";
            // 
            // timer1
            // 
            this.timer1.Interval = 70;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // clear_position_button
            // 
            this.clear_position_button.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.clear_position_button.Location = new System.Drawing.Point(207, 13);
            this.clear_position_button.Name = "clear_position_button";
            this.clear_position_button.Size = new System.Drawing.Size(91, 39);
            this.clear_position_button.TabIndex = 35;
            this.clear_position_button.Text = "机器回零";
            this.clear_position_button.UseVisualStyleBackColor = true;
            this.clear_position_button.Click += new System.EventHandler(this.clear_position_button_Click);
            // 
            // Alarm_clearance
            // 
            this.Alarm_clearance.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Alarm_clearance.Location = new System.Drawing.Point(608, 12);
            this.Alarm_clearance.Name = "Alarm_clearance";
            this.Alarm_clearance.Size = new System.Drawing.Size(92, 40);
            this.Alarm_clearance.TabIndex = 36;
            this.Alarm_clearance.Text = "报警清除";
            this.Alarm_clearance.UseVisualStyleBackColor = true;
            this.Alarm_clearance.Click += new System.EventHandler(this.Alarm_clearance_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 14F);
            this.button1.Location = new System.Drawing.Point(609, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 44);
            this.button1.TabIndex = 37;
            this.button1.Text = "前往工件原点";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(357, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 16);
            this.label8.TabIndex = 68;
            this.label8.Text = "mm";
            // 
            // textBox_12
            // 
            this.textBox_12.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_12.Location = new System.Drawing.Point(451, 349);
            this.textBox_12.Name = "textBox_12";
            this.textBox_12.ReadOnly = true;
            this.textBox_12.Size = new System.Drawing.Size(88, 29);
            this.textBox_12.TabIndex = 67;
            // 
            // textBox_11
            // 
            this.textBox_11.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_11.Location = new System.Drawing.Point(451, 301);
            this.textBox_11.Name = "textBox_11";
            this.textBox_11.ReadOnly = true;
            this.textBox_11.Size = new System.Drawing.Size(88, 29);
            this.textBox_11.TabIndex = 66;
            // 
            // textBox_10
            // 
            this.textBox_10.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_10.Location = new System.Drawing.Point(451, 249);
            this.textBox_10.Name = "textBox_10";
            this.textBox_10.ReadOnly = true;
            this.textBox_10.Size = new System.Drawing.Size(88, 29);
            this.textBox_10.TabIndex = 65;
            // 
            // textBox_9
            // 
            this.textBox_9.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_9.Location = new System.Drawing.Point(451, 202);
            this.textBox_9.Name = "textBox_9";
            this.textBox_9.ReadOnly = true;
            this.textBox_9.Size = new System.Drawing.Size(88, 29);
            this.textBox_9.TabIndex = 64;
            // 
            // textBox_8
            // 
            this.textBox_8.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_8.Location = new System.Drawing.Point(451, 155);
            this.textBox_8.Name = "textBox_8";
            this.textBox_8.ReadOnly = true;
            this.textBox_8.Size = new System.Drawing.Size(88, 29);
            this.textBox_8.TabIndex = 63;
            // 
            // textBox_7
            // 
            this.textBox_7.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_7.Location = new System.Drawing.Point(451, 109);
            this.textBox_7.Name = "textBox_7";
            this.textBox_7.ReadOnly = true;
            this.textBox_7.Size = new System.Drawing.Size(88, 29);
            this.textBox_7.TabIndex = 62;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 12F);
            this.button15.Location = new System.Drawing.Point(442, 48);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(102, 27);
            this.button15.TabIndex = 61;
            this.button15.Text = "编码器位置";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(481, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 16);
            this.label7.TabIndex = 60;
            this.label7.Text = "mm";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox12.Location = new System.Drawing.Point(323, 349);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(86, 29);
            this.textBox12.TabIndex = 59;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox11.Location = new System.Drawing.Point(323, 301);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(86, 29);
            this.textBox11.TabIndex = 58;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox10.Location = new System.Drawing.Point(323, 249);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(86, 29);
            this.textBox10.TabIndex = 57;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox9.Location = new System.Drawing.Point(323, 202);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(86, 29);
            this.textBox9.TabIndex = 56;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox8.Location = new System.Drawing.Point(323, 155);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(86, 29);
            this.textBox8.TabIndex = 55;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox7.Location = new System.Drawing.Point(323, 109);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(86, 29);
            this.textBox7.TabIndex = 54;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 12F);
            this.button14.Location = new System.Drawing.Point(316, 48);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(102, 27);
            this.button14.TabIndex = 53;
            this.button14.Text = "当前指令位置";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 12F);
            this.button13.Location = new System.Drawing.Point(194, 48);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(101, 28);
            this.button13.TabIndex = 52;
            this.button13.Text = "当前运行速度";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 12F);
            this.button2.Location = new System.Drawing.Point(92, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 29);
            this.button2.TabIndex = 51;
            this.button2.Text = "运行状态";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 14F);
            this.label27.Location = new System.Drawing.Point(41, 351);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 19);
            this.label27.TabIndex = 50;
            this.label27.Text = "轴6:";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox5.Location = new System.Drawing.Point(200, 301);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(90, 29);
            this.textBox5.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 14F);
            this.label26.Location = new System.Drawing.Point(41, 303);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 19);
            this.label26.TabIndex = 49;
            this.label26.Text = "轴5:";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox2.Location = new System.Drawing.Point(200, 155);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(90, 29);
            this.textBox2.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 14F);
            this.label25.Location = new System.Drawing.Point(42, 252);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 19);
            this.label25.TabIndex = 48;
            this.label25.Text = "轴4:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 14F);
            this.label24.Location = new System.Drawing.Point(41, 205);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 19);
            this.label24.TabIndex = 47;
            this.label24.Text = "轴3:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 14F);
            this.label23.Location = new System.Drawing.Point(41, 157);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 19);
            this.label23.TabIndex = 46;
            this.label23.Text = "轴2:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 14F);
            this.label18.Location = new System.Drawing.Point(42, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 19);
            this.label18.TabIndex = 45;
            this.label18.Text = "轴1:";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox4.Location = new System.Drawing.Point(200, 249);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(90, 29);
            this.textBox4.TabIndex = 1;
            // 
            // textBox_6
            // 
            this.textBox_6.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_6.Location = new System.Drawing.Point(98, 349);
            this.textBox_6.Name = "textBox_6";
            this.textBox_6.ReadOnly = true;
            this.textBox_6.Size = new System.Drawing.Size(78, 29);
            this.textBox_6.TabIndex = 44;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox6.Location = new System.Drawing.Point(200, 349);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(90, 29);
            this.textBox6.TabIndex = 1;
            // 
            // textBox_5
            // 
            this.textBox_5.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_5.Location = new System.Drawing.Point(98, 301);
            this.textBox_5.Name = "textBox_5";
            this.textBox_5.ReadOnly = true;
            this.textBox_5.Size = new System.Drawing.Size(78, 29);
            this.textBox_5.TabIndex = 43;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox3.Location = new System.Drawing.Point(200, 202);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(90, 29);
            this.textBox3.TabIndex = 1;
            // 
            // textBox_4
            // 
            this.textBox_4.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_4.Location = new System.Drawing.Point(98, 249);
            this.textBox_4.Name = "textBox_4";
            this.textBox_4.ReadOnly = true;
            this.textBox_4.Size = new System.Drawing.Size(78, 29);
            this.textBox_4.TabIndex = 42;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox1.Location = new System.Drawing.Point(200, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(90, 29);
            this.textBox1.TabIndex = 1;
            // 
            // textBox_3
            // 
            this.textBox_3.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_3.Location = new System.Drawing.Point(98, 201);
            this.textBox_3.Name = "textBox_3";
            this.textBox_3.ReadOnly = true;
            this.textBox_3.Size = new System.Drawing.Size(78, 29);
            this.textBox_3.TabIndex = 41;
            // 
            // textBox_2
            // 
            this.textBox_2.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_2.Location = new System.Drawing.Point(98, 155);
            this.textBox_2.Name = "textBox_2";
            this.textBox_2.ReadOnly = true;
            this.textBox_2.Size = new System.Drawing.Size(78, 29);
            this.textBox_2.TabIndex = 40;
            // 
            // textBox_1
            // 
            this.textBox_1.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_1.Location = new System.Drawing.Point(98, 109);
            this.textBox_1.Name = "textBox_1";
            this.textBox_1.ReadOnly = true;
            this.textBox_1.Size = new System.Drawing.Size(78, 29);
            this.textBox_1.TabIndex = 39;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(225, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "mm/s";
            // 
            // processing_speed
            // 
            this.processing_speed.Font = new System.Drawing.Font("宋体", 14F);
            this.processing_speed.Location = new System.Drawing.Point(550, 333);
            this.processing_speed.Name = "processing_speed";
            this.processing_speed.Size = new System.Drawing.Size(145, 55);
            this.processing_speed.TabIndex = 40;
            this.processing_speed.Text = "加工速度调整";
            this.processing_speed.UseVisualStyleBackColor = true;
            this.processing_speed.Click += new System.EventHandler(this.processing_speed_Click);
            // 
            // processing_speed_change
            // 
            this.processing_speed_change.DecimalPlaces = 1;
            this.processing_speed_change.Font = new System.Drawing.Font("宋体", 14F);
            this.processing_speed_change.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.processing_speed_change.Location = new System.Drawing.Point(728, 344);
            this.processing_speed_change.Name = "processing_speed_change";
            this.processing_speed_change.Size = new System.Drawing.Size(105, 29);
            this.processing_speed_change.TabIndex = 39;
            this.processing_speed_change.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.processing_speed_change.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // button_stop0
            // 
            this.button_stop0.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_stop0.Location = new System.Drawing.Point(550, 261);
            this.button_stop0.Name = "button_stop0";
            this.button_stop0.Size = new System.Drawing.Size(145, 55);
            this.button_stop0.TabIndex = 38;
            this.button_stop0.Text = "暂停加工";
            this.button_stop0.UseVisualStyleBackColor = true;
            this.button_stop0.Click += new System.EventHandler(this.button_stop0_Click);
            // 
            // button_stop1
            // 
            this.button_stop1.Font = new System.Drawing.Font("宋体", 14F);
            this.button_stop1.Location = new System.Drawing.Point(726, 263);
            this.button_stop1.Name = "button_stop1";
            this.button_stop1.Size = new System.Drawing.Size(146, 53);
            this.button_stop1.TabIndex = 37;
            this.button_stop1.Text = "停止加工";
            this.button_stop1.UseVisualStyleBackColor = true;
            this.button_stop1.Click += new System.EventHandler(this.button_stop1_Click);
            // 
            // textBox_pointcount
            // 
            this.textBox_pointcount.Enabled = false;
            this.textBox_pointcount.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_pointcount.Location = new System.Drawing.Point(702, 78);
            this.textBox_pointcount.Name = "textBox_pointcount";
            this.textBox_pointcount.Size = new System.Drawing.Size(130, 29);
            this.textBox_pointcount.TabIndex = 16;
            this.textBox_pointcount.Text = "Not Runing";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 14F);
            this.label11.Location = new System.Drawing.Point(540, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 19);
            this.label11.TabIndex = 15;
            this.label11.Text = "路径总节点数:";
            // 
            // button_datainput
            // 
            this.button_datainput.Font = new System.Drawing.Font("宋体", 14F);
            this.button_datainput.Location = new System.Drawing.Point(550, 186);
            this.button_datainput.Name = "button_datainput";
            this.button_datainput.Size = new System.Drawing.Size(145, 55);
            this.button_datainput.TabIndex = 14;
            this.button_datainput.Text = "导入加工路径";
            this.button_datainput.UseVisualStyleBackColor = true;
            this.button_datainput.Click += new System.EventHandler(this.button_datainput_Click);
            // 
            // textBox_pointnum
            // 
            this.textBox_pointnum.Enabled = false;
            this.textBox_pointnum.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_pointnum.Location = new System.Drawing.Point(702, 121);
            this.textBox_pointnum.Name = "textBox_pointnum";
            this.textBox_pointnum.Size = new System.Drawing.Size(130, 29);
            this.textBox_pointnum.TabIndex = 13;
            this.textBox_pointnum.Text = "Waiting";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 14F);
            this.label9.Location = new System.Drawing.Point(558, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 19);
            this.label9.TabIndex = 11;
            this.label9.Text = "当前节点数:";
            // 
            // button_run
            // 
            this.button_run.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_run.Font = new System.Drawing.Font("宋体", 14F);
            this.button_run.Location = new System.Drawing.Point(727, 186);
            this.button_run.Name = "button_run";
            this.button_run.Size = new System.Drawing.Size(145, 55);
            this.button_run.TabIndex = 10;
            this.button_run.Text = "开始加工";
            this.button_run.UseVisualStyleBackColor = true;
            this.button_run.Click += new System.EventHandler(this.button_run_Click);
            // 
            // spindle_speed
            // 
            this.spindle_speed.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.spindle_speed.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spindle_speed.Location = new System.Drawing.Point(1009, 21);
            this.spindle_speed.Maximum = new decimal(new int[] {
            12000,
            0,
            0,
            0});
            this.spindle_speed.Name = "spindle_speed";
            this.spindle_speed.Size = new System.Drawing.Size(81, 26);
            this.spindle_speed.TabIndex = 40;
            this.spindle_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.spindle_speed.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(927, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 16);
            this.label10.TabIndex = 41;
            this.label10.Text = "主轴转速:";
            // 
            // button_spindle_run
            // 
            this.button_spindle_run.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_spindle_run.Font = new System.Drawing.Font("宋体", 14F);
            this.button_spindle_run.Location = new System.Drawing.Point(43, 302);
            this.button_spindle_run.Name = "button_spindle_run";
            this.button_spindle_run.Size = new System.Drawing.Size(120, 40);
            this.button_spindle_run.TabIndex = 42;
            this.button_spindle_run.Text = "启动主轴";
            this.button_spindle_run.UseVisualStyleBackColor = true;
            this.button_spindle_run.Click += new System.EventHandler(this.button_spindle_Click);
            // 
            // button_spindle_stop
            // 
            this.button_spindle_stop.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_spindle_stop.Font = new System.Drawing.Font("宋体", 14F);
            this.button_spindle_stop.Location = new System.Drawing.Point(43, 353);
            this.button_spindle_stop.Name = "button_spindle_stop";
            this.button_spindle_stop.Size = new System.Drawing.Size(120, 40);
            this.button_spindle_stop.TabIndex = 43;
            this.button_spindle_stop.Text = "关闭主轴";
            this.button_spindle_stop.UseVisualStyleBackColor = true;
            this.button_spindle_stop.Click += new System.EventHandler(this.button_spindle_stop_Click);
            // 
            // Ybutton
            // 
            this.Ybutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Ybutton.Location = new System.Drawing.Point(529, 208);
            this.Ybutton.Name = "Ybutton";
            this.Ybutton.Size = new System.Drawing.Size(144, 39);
            this.Ybutton.TabIndex = 70;
            this.Ybutton.Text = "设置工件Y坐标";
            this.Ybutton.UseVisualStyleBackColor = true;
            this.Ybutton.Click += new System.EventHandler(this.Ybutton_Click);
            this.Ybutton.MouseEnter += new System.EventHandler(this.Ybutton_MouseEnter);
            // 
            // Zbutton
            // 
            this.Zbutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Zbutton.Location = new System.Drawing.Point(529, 280);
            this.Zbutton.Name = "Zbutton";
            this.Zbutton.Size = new System.Drawing.Size(144, 39);
            this.Zbutton.TabIndex = 71;
            this.Zbutton.Text = "设置工件Z坐标";
            this.Zbutton.UseVisualStyleBackColor = true;
            this.Zbutton.Click += new System.EventHandler(this.Zbutton_Click);
            this.Zbutton.MouseEnter += new System.EventHandler(this.Zbutton_MouseEnter);
            // 
            // timer2
            // 
            this.timer2.Interval = 40;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button_dimention
            // 
            this.button_dimention.Font = new System.Drawing.Font("宋体", 18F);
            this.button_dimention.Location = new System.Drawing.Point(12, 90);
            this.button_dimention.Name = "button_dimention";
            this.button_dimention.Size = new System.Drawing.Size(150, 70);
            this.button_dimention.TabIndex = 74;
            this.button_dimention.Text = "机床尺度";
            this.button_dimention.UseVisualStyleBackColor = true;
            this.button_dimention.Click += new System.EventHandler(this.button_dimention_Click);
            // 
            // value_tool
            // 
            this.value_tool.Font = new System.Drawing.Font("宋体", 14F);
            this.value_tool.Location = new System.Drawing.Point(147, 17);
            this.value_tool.Name = "value_tool";
            this.value_tool.Size = new System.Drawing.Size(110, 29);
            this.value_tool.TabIndex = 85;
            this.value_tool.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 14F);
            this.label16.Location = new System.Drawing.Point(32, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 19);
            this.label16.TabIndex = 83;
            this.label16.Text = "刀具长度:";
            // 
            // button_single
            // 
            this.button_single.Font = new System.Drawing.Font("宋体", 18F);
            this.button_single.Location = new System.Drawing.Point(12, 405);
            this.button_single.Name = "button_single";
            this.button_single.Size = new System.Drawing.Size(150, 70);
            this.button_single.TabIndex = 86;
            this.button_single.Text = "示教功能";
            this.button_single.UseVisualStyleBackColor = true;
            this.button_single.Click += new System.EventHandler(this.button_single_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tool_change);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.value_rtool);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.value_tool);
            this.groupBox3.Location = new System.Drawing.Point(492, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(404, 93);
            this.groupBox3.TabIndex = 89;
            this.groupBox3.TabStop = false;
            // 
            // tool_change
            // 
            this.tool_change.Font = new System.Drawing.Font("宋体", 14F);
            this.tool_change.Location = new System.Drawing.Point(318, 30);
            this.tool_change.Name = "tool_change";
            this.tool_change.Size = new System.Drawing.Size(62, 37);
            this.tool_change.TabIndex = 92;
            this.tool_change.Text = "确认";
            this.tool_change.UseVisualStyleBackColor = true;
            this.tool_change.Click += new System.EventHandler(this.tool_change_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(267, 61);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 16);
            this.label19.TabIndex = 89;
            this.label19.Text = "mm";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(267, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 16);
            this.label17.TabIndex = 88;
            this.label17.Text = "mm";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 14F);
            this.label15.Location = new System.Drawing.Point(32, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 19);
            this.label15.TabIndex = 86;
            this.label15.Text = "刀具半径:";
            // 
            // value_rtool
            // 
            this.value_rtool.Font = new System.Drawing.Font("宋体", 14F);
            this.value_rtool.Location = new System.Drawing.Point(147, 55);
            this.value_rtool.Name = "value_rtool";
            this.value_rtool.Size = new System.Drawing.Size(110, 29);
            this.value_rtool.TabIndex = 87;
            this.value_rtool.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // 单轴控制ToolStripMenuItem
            // 
            this.单轴控制ToolStripMenuItem.Name = "单轴控制ToolStripMenuItem";
            this.单轴控制ToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // 设置工件坐标ToolStripMenuItem
            // 
            this.设置工件坐标ToolStripMenuItem.Name = "设置工件坐标ToolStripMenuItem";
            this.设置工件坐标ToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // 机床尺度定义ToolStripMenuItem
            // 
            this.机床尺度定义ToolStripMenuItem.Name = "机床尺度定义ToolStripMenuItem";
            this.机床尺度定义ToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button5);
            this.groupBox6.Controls.Add(this.button_spindle_stop);
            this.groupBox6.Controls.Add(this.button_spindle_run);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Controls.Add(this.button7);
            this.groupBox6.Controls.Add(this.button8);
            this.groupBox6.Controls.Add(this.button9);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox6.Location = new System.Drawing.Point(172, 149);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(198, 405);
            this.groupBox6.TabIndex = 93;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "单轴运动";
            // 
            // groupBox_processing
            // 
            this.groupBox_processing.Controls.Add(this.label102);
            this.groupBox_processing.Controls.Add(this.processing_speed);
            this.groupBox_processing.Controls.Add(this.groupBox15);
            this.groupBox_processing.Controls.Add(this.processing_speed_change);
            this.groupBox_processing.Controls.Add(this.button_stop0);
            this.groupBox_processing.Controls.Add(this.button_stop1);
            this.groupBox_processing.Controls.Add(this.label101);
            this.groupBox_processing.Controls.Add(this.progressBar_processing);
            this.groupBox_processing.Controls.Add(this.label9);
            this.groupBox_processing.Controls.Add(this.button_datainput);
            this.groupBox_processing.Controls.Add(this.label11);
            this.groupBox_processing.Controls.Add(this.textBox_pointcount);
            this.groupBox_processing.Controls.Add(this.textBox_pointnum);
            this.groupBox_processing.Controls.Add(this.button_run);
            this.groupBox_processing.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_processing.Location = new System.Drawing.Point(397, 500);
            this.groupBox_processing.Name = "groupBox_processing";
            this.groupBox_processing.Size = new System.Drawing.Size(927, 405);
            this.groupBox_processing.TabIndex = 154;
            this.groupBox_processing.TabStop = false;
            this.groupBox_processing.Text = "加工";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.Location = new System.Drawing.Point(839, 349);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(40, 16);
            this.label102.TabIndex = 49;
            this.label102.Text = "mm/s";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.picture_processing);
            this.groupBox15.Location = new System.Drawing.Point(20, 25);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(466, 367);
            this.groupBox15.TabIndex = 48;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "加工路径显示(XY)";
            // 
            // picture_processing
            // 
            this.picture_processing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_processing.Location = new System.Drawing.Point(8, 17);
            this.picture_processing.Name = "picture_processing";
            this.picture_processing.Size = new System.Drawing.Size(450, 350);
            this.picture_processing.TabIndex = 0;
            this.picture_processing.TabStop = false;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("宋体", 14F);
            this.label101.Location = new System.Drawing.Point(577, 42);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(95, 19);
            this.label101.TabIndex = 47;
            this.label101.Text = "当前进度:";
            // 
            // progressBar_processing
            // 
            this.progressBar_processing.Location = new System.Drawing.Point(703, 40);
            this.progressBar_processing.Name = "progressBar_processing";
            this.progressBar_processing.Size = new System.Drawing.Size(162, 23);
            this.progressBar_processing.TabIndex = 46;
            // 
            // calibration_Box
            // 
            this.calibration_Box.Controls.Add(this.confirm_zero);
            this.calibration_Box.Controls.Add(this.label85);
            this.calibration_Box.Controls.Add(this.textBox17);
            this.calibration_Box.Controls.Add(this.label83);
            this.calibration_Box.Controls.Add(this.textBox15);
            this.calibration_Box.Controls.Add(this.label84);
            this.calibration_Box.Controls.Add(this.textBox16);
            this.calibration_Box.Controls.Add(this.label81);
            this.calibration_Box.Controls.Add(this.textBox13);
            this.calibration_Box.Controls.Add(this.label82);
            this.calibration_Box.Controls.Add(this.textBox14);
            this.calibration_Box.Controls.Add(this.label80);
            this.calibration_Box.Controls.Add(this.label79);
            this.calibration_Box.Controls.Add(this.label78);
            this.calibration_Box.Controls.Add(this.groupBox2);
            this.calibration_Box.Font = new System.Drawing.Font("宋体", 12F);
            this.calibration_Box.Location = new System.Drawing.Point(35, 572);
            this.calibration_Box.Name = "calibration_Box";
            this.calibration_Box.Size = new System.Drawing.Size(914, 405);
            this.calibration_Box.TabIndex = 153;
            this.calibration_Box.TabStop = false;
            this.calibration_Box.Text = "机床校零";
            // 
            // confirm_zero
            // 
            this.confirm_zero.Font = new System.Drawing.Font("宋体", 14F);
            this.confirm_zero.Location = new System.Drawing.Point(567, 311);
            this.confirm_zero.Name = "confirm_zero";
            this.confirm_zero.Size = new System.Drawing.Size(187, 52);
            this.confirm_zero.TabIndex = 169;
            this.confirm_zero.Text = "确认到达机械原点";
            this.confirm_zero.UseVisualStyleBackColor = true;
            this.confirm_zero.Click += new System.EventHandler(this.confirm_zero_Click);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("宋体", 14F);
            this.label85.Location = new System.Drawing.Point(482, 249);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(29, 19);
            this.label85.TabIndex = 168;
            this.label85.Text = "Z:";
            // 
            // textBox17
            // 
            this.textBox17.Enabled = false;
            this.textBox17.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox17.ForeColor = System.Drawing.Color.Black;
            this.textBox17.Location = new System.Drawing.Point(522, 247);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(85, 29);
            this.textBox17.TabIndex = 167;
            this.textBox17.Text = "155.65";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("宋体", 14F);
            this.label83.Location = new System.Drawing.Point(701, 197);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(29, 19);
            this.label83.TabIndex = 166;
            this.label83.Text = "Y:";
            // 
            // textBox15
            // 
            this.textBox15.Enabled = false;
            this.textBox15.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox15.ForeColor = System.Drawing.Color.Black;
            this.textBox15.Location = new System.Drawing.Point(741, 196);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(85, 29);
            this.textBox15.TabIndex = 165;
            this.textBox15.Text = "0";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("宋体", 14F);
            this.label84.Location = new System.Drawing.Point(701, 145);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(29, 19);
            this.label84.TabIndex = 164;
            this.label84.Text = "X:";
            // 
            // textBox16
            // 
            this.textBox16.Enabled = false;
            this.textBox16.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox16.ForeColor = System.Drawing.Color.Black;
            this.textBox16.Location = new System.Drawing.Point(741, 144);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(85, 29);
            this.textBox16.TabIndex = 163;
            this.textBox16.Text = "0";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("宋体", 14F);
            this.label81.Location = new System.Drawing.Point(482, 195);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(29, 19);
            this.label81.TabIndex = 159;
            this.label81.Text = "B:";
            // 
            // textBox13
            // 
            this.textBox13.Enabled = false;
            this.textBox13.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox13.ForeColor = System.Drawing.Color.Black;
            this.textBox13.Location = new System.Drawing.Point(522, 193);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(85, 29);
            this.textBox13.TabIndex = 158;
            this.textBox13.Text = "0";
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("宋体", 14F);
            this.label82.Location = new System.Drawing.Point(482, 143);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(29, 19);
            this.label82.TabIndex = 157;
            this.label82.Text = "A:";
            // 
            // textBox14
            // 
            this.textBox14.Enabled = false;
            this.textBox14.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox14.ForeColor = System.Drawing.Color.Black;
            this.textBox14.Location = new System.Drawing.Point(522, 141);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(85, 29);
            this.textBox14.TabIndex = 156;
            this.textBox14.Text = "0";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("宋体", 18F);
            this.label80.Location = new System.Drawing.Point(715, 93);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(130, 24);
            this.label80.TabIndex = 3;
            this.label80.Text = "XY平台位置";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("宋体", 18F);
            this.label79.Location = new System.Drawing.Point(501, 89);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(130, 24);
            this.label79.TabIndex = 2;
            this.label79.Text = "动平台姿态";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("宋体", 18F);
            this.label78.Location = new System.Drawing.Point(609, 33);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(106, 24);
            this.label78.TabIndex = 1;
            this.label78.Text = "机械原点";
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.groupBox2.Location = new System.Drawing.Point(20, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(410, 371);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // groupBox_running
            // 
            this.groupBox_running.Controls.Add(this.label8);
            this.groupBox_running.Controls.Add(this.textBox4);
            this.groupBox_running.Controls.Add(this.textBox_12);
            this.groupBox_running.Controls.Add(this.label12);
            this.groupBox_running.Controls.Add(this.textBox_11);
            this.groupBox_running.Controls.Add(this.textBox_1);
            this.groupBox_running.Controls.Add(this.textBox_10);
            this.groupBox_running.Controls.Add(this.groupBox7);
            this.groupBox_running.Controls.Add(this.textBox_2);
            this.groupBox_running.Controls.Add(this.textBox_9);
            this.groupBox_running.Controls.Add(this.textBox_3);
            this.groupBox_running.Controls.Add(this.textBox_8);
            this.groupBox_running.Controls.Add(this.textBox1);
            this.groupBox_running.Controls.Add(this.textBox_7);
            this.groupBox_running.Controls.Add(this.textBox_4);
            this.groupBox_running.Controls.Add(this.button15);
            this.groupBox_running.Controls.Add(this.textBox3);
            this.groupBox_running.Controls.Add(this.label7);
            this.groupBox_running.Controls.Add(this.textBox_5);
            this.groupBox_running.Controls.Add(this.textBox12);
            this.groupBox_running.Controls.Add(this.textBox6);
            this.groupBox_running.Controls.Add(this.textBox11);
            this.groupBox_running.Controls.Add(this.textBox_6);
            this.groupBox_running.Controls.Add(this.textBox10);
            this.groupBox_running.Controls.Add(this.label18);
            this.groupBox_running.Controls.Add(this.textBox9);
            this.groupBox_running.Controls.Add(this.label23);
            this.groupBox_running.Controls.Add(this.textBox8);
            this.groupBox_running.Controls.Add(this.label24);
            this.groupBox_running.Controls.Add(this.textBox7);
            this.groupBox_running.Controls.Add(this.label25);
            this.groupBox_running.Controls.Add(this.button14);
            this.groupBox_running.Controls.Add(this.textBox2);
            this.groupBox_running.Controls.Add(this.button13);
            this.groupBox_running.Controls.Add(this.label26);
            this.groupBox_running.Controls.Add(this.button2);
            this.groupBox_running.Controls.Add(this.textBox5);
            this.groupBox_running.Controls.Add(this.label27);
            this.groupBox_running.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_running.Location = new System.Drawing.Point(417, 386);
            this.groupBox_running.Name = "groupBox_running";
            this.groupBox_running.Size = new System.Drawing.Size(924, 400);
            this.groupBox_running.TabIndex = 153;
            this.groupBox_running.TabStop = false;
            this.groupBox_running.Text = "运行状态";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button16);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label35);
            this.groupBox7.Controls.Add(this.PKMZ_position);
            this.groupBox7.Controls.Add(this.button17);
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.GX_position);
            this.groupBox7.Controls.Add(this.PKMB_position);
            this.groupBox7.Controls.Add(this.GY_position);
            this.groupBox7.Controls.Add(this.PKMA_position);
            this.groupBox7.Controls.Add(this.GZ_position);
            this.groupBox7.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox7.Location = new System.Drawing.Point(602, 59);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(265, 319);
            this.groupBox7.TabIndex = 136;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "姿态";
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 14F);
            this.button16.Location = new System.Drawing.Point(32, 191);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(32, 106);
            this.button16.TabIndex = 135;
            this.button16.Text = "动平台姿态";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label34.Location = new System.Drawing.Point(209, 277);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 14);
            this.label34.TabIndex = 134;
            this.label34.Text = "mm";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("宋体", 14F);
            this.label35.Location = new System.Drawing.Point(85, 275);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 19);
            this.label35.TabIndex = 132;
            this.label35.Text = "Z:";
            // 
            // PKMZ_position
            // 
            this.PKMZ_position.Font = new System.Drawing.Font("宋体", 14F);
            this.PKMZ_position.Location = new System.Drawing.Point(115, 271);
            this.PKMZ_position.Name = "PKMZ_position";
            this.PKMZ_position.ReadOnly = true;
            this.PKMZ_position.Size = new System.Drawing.Size(82, 29);
            this.PKMZ_position.TabIndex = 133;
            this.PKMZ_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("宋体", 14F);
            this.button17.Location = new System.Drawing.Point(32, 39);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(32, 99);
            this.button17.TabIndex = 115;
            this.button17.Text = "刀尖位置";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 14F);
            this.label1.Location = new System.Drawing.Point(77, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 19);
            this.label1.TabIndex = 116;
            this.label1.Text = "GX:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 14F);
            this.label20.Location = new System.Drawing.Point(76, 80);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(39, 19);
            this.label20.TabIndex = 117;
            this.label20.Text = "GY:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label21.Location = new System.Drawing.Point(209, 233);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 14);
            this.label21.TabIndex = 131;
            this.label21.Text = "°";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 14F);
            this.label22.Location = new System.Drawing.Point(76, 127);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 19);
            this.label22.TabIndex = 118;
            this.label22.Text = "GZ:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label28.Location = new System.Drawing.Point(208, 191);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 14);
            this.label28.TabIndex = 130;
            this.label28.Text = "°";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("宋体", 14F);
            this.label29.Location = new System.Drawing.Point(85, 187);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 19);
            this.label29.TabIndex = 119;
            this.label29.Text = "A:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label30.Location = new System.Drawing.Point(209, 81);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 14);
            this.label30.TabIndex = 129;
            this.label30.Text = "mm";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 14F);
            this.label31.Location = new System.Drawing.Point(85, 231);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 19);
            this.label31.TabIndex = 120;
            this.label31.Text = "B:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label32.Location = new System.Drawing.Point(209, 130);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 14);
            this.label32.TabIndex = 128;
            this.label32.Text = "mm";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label33.Location = new System.Drawing.Point(208, 35);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(21, 14);
            this.label33.TabIndex = 127;
            this.label33.Text = "mm";
            // 
            // GX_position
            // 
            this.GX_position.Font = new System.Drawing.Font("宋体", 14F);
            this.GX_position.Location = new System.Drawing.Point(112, 28);
            this.GX_position.Name = "GX_position";
            this.GX_position.ReadOnly = true;
            this.GX_position.Size = new System.Drawing.Size(83, 29);
            this.GX_position.TabIndex = 122;
            this.GX_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMB_position
            // 
            this.PKMB_position.Font = new System.Drawing.Font("宋体", 14F);
            this.PKMB_position.Location = new System.Drawing.Point(115, 227);
            this.PKMB_position.Name = "PKMB_position";
            this.PKMB_position.ReadOnly = true;
            this.PKMB_position.Size = new System.Drawing.Size(82, 29);
            this.PKMB_position.TabIndex = 126;
            this.PKMB_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GY_position
            // 
            this.GY_position.Font = new System.Drawing.Font("宋体", 14F);
            this.GY_position.Location = new System.Drawing.Point(113, 75);
            this.GY_position.Name = "GY_position";
            this.GY_position.ReadOnly = true;
            this.GY_position.Size = new System.Drawing.Size(82, 29);
            this.GY_position.TabIndex = 123;
            this.GY_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMA_position
            // 
            this.PKMA_position.Font = new System.Drawing.Font("宋体", 14F);
            this.PKMA_position.Location = new System.Drawing.Point(115, 183);
            this.PKMA_position.Name = "PKMA_position";
            this.PKMA_position.ReadOnly = true;
            this.PKMA_position.Size = new System.Drawing.Size(82, 29);
            this.PKMA_position.TabIndex = 125;
            this.PKMA_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GZ_position
            // 
            this.GZ_position.Font = new System.Drawing.Font("宋体", 14F);
            this.GZ_position.Location = new System.Drawing.Point(113, 123);
            this.GZ_position.Name = "GZ_position";
            this.GZ_position.ReadOnly = true;
            this.GZ_position.Size = new System.Drawing.Size(82, 29);
            this.GZ_position.TabIndex = 124;
            this.GZ_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox_teach
            // 
            this.groupBox_teach.Controls.Add(this.programming);
            this.groupBox_teach.Controls.Add(this.button_continue);
            this.groupBox_teach.Controls.Add(this.button_stoping0);
            this.groupBox_teach.Controls.Add(this.button_edit);
            this.groupBox_teach.Controls.Add(this.groupBox10);
            this.groupBox_teach.Controls.Add(this.button_stoping);
            this.groupBox_teach.Controls.Add(this.button_running);
            this.groupBox_teach.Controls.Add(this.label96);
            this.groupBox_teach.Controls.Add(this.teached_point);
            this.groupBox_teach.Controls.Add(this.moveto);
            this.groupBox_teach.Controls.Add(this.teaching);
            this.groupBox_teach.Controls.Add(this.label97);
            this.groupBox_teach.Controls.Add(this.teaching_point);
            this.groupBox_teach.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_teach.Location = new System.Drawing.Point(447, 149);
            this.groupBox_teach.Name = "groupBox_teach";
            this.groupBox_teach.Size = new System.Drawing.Size(914, 401);
            this.groupBox_teach.TabIndex = 168;
            this.groupBox_teach.TabStop = false;
            this.groupBox_teach.Text = "示教功能";
            // 
            // programming
            // 
            this.programming.Location = new System.Drawing.Point(347, 54);
            this.programming.Multiline = true;
            this.programming.Name = "programming";
            this.programming.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.programming.Size = new System.Drawing.Size(538, 331);
            this.programming.TabIndex = 167;
            // 
            // button_continue
            // 
            this.button_continue.Font = new System.Drawing.Font("宋体", 12F);
            this.button_continue.Location = new System.Drawing.Point(794, 18);
            this.button_continue.Name = "button_continue";
            this.button_continue.Size = new System.Drawing.Size(91, 28);
            this.button_continue.TabIndex = 148;
            this.button_continue.Text = "继续";
            this.button_continue.UseVisualStyleBackColor = true;
            this.button_continue.Click += new System.EventHandler(this.button_continue_Click);
            // 
            // button_stoping0
            // 
            this.button_stoping0.Font = new System.Drawing.Font("宋体", 12F);
            this.button_stoping0.Location = new System.Drawing.Point(681, 17);
            this.button_stoping0.Name = "button_stoping0";
            this.button_stoping0.Size = new System.Drawing.Size(91, 28);
            this.button_stoping0.TabIndex = 147;
            this.button_stoping0.Text = "暂停";
            this.button_stoping0.UseVisualStyleBackColor = true;
            this.button_stoping0.Click += new System.EventHandler(this.button_stoping0_Click);
            // 
            // button_edit
            // 
            this.button_edit.Font = new System.Drawing.Font("宋体", 12F);
            this.button_edit.Location = new System.Drawing.Point(347, 16);
            this.button_edit.Name = "button_edit";
            this.button_edit.Size = new System.Drawing.Size(91, 28);
            this.button_edit.TabIndex = 146;
            this.button_edit.Text = "编译";
            this.button_edit.UseVisualStyleBackColor = true;
            this.button_edit.Click += new System.EventHandler(this.button_edit_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button21);
            this.groupBox10.Controls.Add(this.button22);
            this.groupBox10.Controls.Add(this.label86);
            this.groupBox10.Controls.Add(this.label87);
            this.groupBox10.Controls.Add(this.label88);
            this.groupBox10.Controls.Add(this.label89);
            this.groupBox10.Controls.Add(this.label90);
            this.groupBox10.Controls.Add(this.label91);
            this.groupBox10.Controls.Add(this.label92);
            this.groupBox10.Controls.Add(this.label93);
            this.groupBox10.Controls.Add(this.label94);
            this.groupBox10.Controls.Add(this.textBox18);
            this.groupBox10.Controls.Add(this.label95);
            this.groupBox10.Controls.Add(this.GX0_position);
            this.groupBox10.Controls.Add(this.PKMB0_position);
            this.groupBox10.Controls.Add(this.GY0_position);
            this.groupBox10.Controls.Add(this.PKMA0_position);
            this.groupBox10.Controls.Add(this.GZ0_position);
            this.groupBox10.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox10.Location = new System.Drawing.Point(51, 136);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(241, 247);
            this.groupBox10.TabIndex = 145;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "姿态";
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("宋体", 12F);
            this.button21.Location = new System.Drawing.Point(26, 22);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(81, 28);
            this.button21.TabIndex = 113;
            this.button21.Text = "当前点位";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("宋体", 12F);
            this.button22.Location = new System.Drawing.Point(16, 96);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(32, 109);
            this.button22.TabIndex = 115;
            this.button22.Text = "当前刀具位姿";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("宋体", 12F);
            this.label86.Location = new System.Drawing.Point(73, 70);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(24, 16);
            this.label86.TabIndex = 116;
            this.label86.Text = "X:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("宋体", 12F);
            this.label87.Location = new System.Drawing.Point(72, 106);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(24, 16);
            this.label87.TabIndex = 117;
            this.label87.Text = "Y:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label88.Location = new System.Drawing.Point(185, 215);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(21, 14);
            this.label88.TabIndex = 131;
            this.label88.Text = "°";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("宋体", 12F);
            this.label89.Location = new System.Drawing.Point(72, 141);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(24, 16);
            this.label89.TabIndex = 118;
            this.label89.Text = "Z:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label90.Location = new System.Drawing.Point(184, 182);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(21, 14);
            this.label90.TabIndex = 130;
            this.label90.Text = "°";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("宋体", 12F);
            this.label91.Location = new System.Drawing.Point(72, 177);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(24, 16);
            this.label91.TabIndex = 119;
            this.label91.Text = "A:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label92.Location = new System.Drawing.Point(185, 106);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(21, 14);
            this.label92.TabIndex = 129;
            this.label92.Text = "mm";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("宋体", 12F);
            this.label93.Location = new System.Drawing.Point(72, 212);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(24, 16);
            this.label93.TabIndex = 120;
            this.label93.Text = "B:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label94.Location = new System.Drawing.Point(185, 143);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(21, 14);
            this.label94.TabIndex = 128;
            this.label94.Text = "mm";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("宋体", 12F);
            this.textBox18.Location = new System.Drawing.Point(134, 24);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(84, 26);
            this.textBox18.TabIndex = 121;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label95.Location = new System.Drawing.Point(184, 72);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(21, 14);
            this.label95.TabIndex = 127;
            this.label95.Text = "mm";
            // 
            // GX0_position
            // 
            this.GX0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GX0_position.Location = new System.Drawing.Point(101, 66);
            this.GX0_position.Name = "GX0_position";
            this.GX0_position.ReadOnly = true;
            this.GX0_position.Size = new System.Drawing.Size(75, 26);
            this.GX0_position.TabIndex = 122;
            this.GX0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMB0_position
            // 
            this.PKMB0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMB0_position.Location = new System.Drawing.Point(102, 208);
            this.PKMB0_position.Name = "PKMB0_position";
            this.PKMB0_position.ReadOnly = true;
            this.PKMB0_position.Size = new System.Drawing.Size(75, 26);
            this.PKMB0_position.TabIndex = 126;
            this.PKMB0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GY0_position
            // 
            this.GY0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GY0_position.Location = new System.Drawing.Point(102, 101);
            this.GY0_position.Name = "GY0_position";
            this.GY0_position.ReadOnly = true;
            this.GY0_position.Size = new System.Drawing.Size(75, 26);
            this.GY0_position.TabIndex = 123;
            this.GY0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMA0_position
            // 
            this.PKMA0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMA0_position.Location = new System.Drawing.Point(102, 173);
            this.PKMA0_position.Name = "PKMA0_position";
            this.PKMA0_position.ReadOnly = true;
            this.PKMA0_position.Size = new System.Drawing.Size(75, 26);
            this.PKMA0_position.TabIndex = 125;
            this.PKMA0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GZ0_position
            // 
            this.GZ0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GZ0_position.Location = new System.Drawing.Point(102, 137);
            this.GZ0_position.Name = "GZ0_position";
            this.GZ0_position.ReadOnly = true;
            this.GZ0_position.Size = new System.Drawing.Size(75, 26);
            this.GZ0_position.TabIndex = 124;
            this.GZ0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_stoping
            // 
            this.button_stoping.Font = new System.Drawing.Font("宋体", 12F);
            this.button_stoping.Location = new System.Drawing.Point(564, 17);
            this.button_stoping.Name = "button_stoping";
            this.button_stoping.Size = new System.Drawing.Size(91, 28);
            this.button_stoping.TabIndex = 144;
            this.button_stoping.Text = "停止";
            this.button_stoping.UseVisualStyleBackColor = true;
            this.button_stoping.Click += new System.EventHandler(this.button_stoping_Click);
            // 
            // button_running
            // 
            this.button_running.Font = new System.Drawing.Font("宋体", 12F);
            this.button_running.Location = new System.Drawing.Point(451, 16);
            this.button_running.Name = "button_running";
            this.button_running.Size = new System.Drawing.Size(91, 28);
            this.button_running.TabIndex = 143;
            this.button_running.Text = "运行";
            this.button_running.UseVisualStyleBackColor = true;
            this.button_running.Click += new System.EventHandler(this.button_running_Click);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("宋体", 12F);
            this.label96.Location = new System.Drawing.Point(35, 96);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(48, 16);
            this.label96.TabIndex = 142;
            this.label96.Text = "点位:";
            // 
            // teached_point
            // 
            this.teached_point.Font = new System.Drawing.Font("宋体", 12F);
            this.teached_point.FormattingEnabled = true;
            this.teached_point.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12",
            "P13",
            "P14",
            "P15",
            "P16",
            "P17",
            "P18",
            "P19",
            "P20",
            "P21",
            "P22",
            "P23",
            "P24",
            "P25",
            "P26",
            "P27",
            "P28",
            "P29",
            "P30",
            "P31",
            "P32",
            "P33",
            "P34",
            "P35",
            "P36",
            "P37",
            "P38",
            "P39",
            "P40",
            "P41",
            "P42",
            "P43",
            "P44",
            "P45",
            "P46",
            "P47",
            "P48",
            "P49",
            "P50",
            "P51",
            "P52",
            "P53",
            "P54",
            "P55",
            "P56",
            "P57",
            "P58",
            "P59",
            "P60",
            "P61",
            "P62",
            "P63",
            "P64",
            "P65",
            "P66",
            "P67",
            "P68",
            "P69",
            "P70",
            "P71",
            "P72",
            "P73",
            "P74",
            "P75",
            "P76",
            "P77",
            "P78",
            "P79",
            "P80",
            "P81",
            "P82",
            "P83",
            "P84",
            "P85",
            "P86",
            "P87",
            "P88",
            "P89",
            "P90",
            "P91",
            "P92",
            "P93",
            "P94",
            "P95",
            "P96",
            "P97",
            "P98",
            "P99",
            "P100"});
            this.teached_point.Location = new System.Drawing.Point(103, 91);
            this.teached_point.Name = "teached_point";
            this.teached_point.Size = new System.Drawing.Size(102, 24);
            this.teached_point.TabIndex = 141;
            // 
            // moveto
            // 
            this.moveto.Font = new System.Drawing.Font("宋体", 12F);
            this.moveto.Location = new System.Drawing.Point(212, 90);
            this.moveto.Name = "moveto";
            this.moveto.Size = new System.Drawing.Size(91, 28);
            this.moveto.TabIndex = 140;
            this.moveto.Text = "前往";
            this.moveto.UseVisualStyleBackColor = true;
            this.moveto.Click += new System.EventHandler(this.moveto_Click);
            // 
            // teaching
            // 
            this.teaching.Font = new System.Drawing.Font("宋体", 12F);
            this.teaching.Location = new System.Drawing.Point(212, 37);
            this.teaching.Name = "teaching";
            this.teaching.Size = new System.Drawing.Size(91, 28);
            this.teaching.TabIndex = 100;
            this.teaching.Text = "教导";
            this.teaching.UseVisualStyleBackColor = true;
            this.teaching.Click += new System.EventHandler(this.teaching_Click);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("宋体", 12F);
            this.label97.Location = new System.Drawing.Point(20, 42);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(80, 16);
            this.label97.TabIndex = 99;
            this.label97.Text = "点位定义:";
            // 
            // teaching_point
            // 
            this.teaching_point.Font = new System.Drawing.Font("宋体", 12F);
            this.teaching_point.FormattingEnabled = true;
            this.teaching_point.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12",
            "P13",
            "P14",
            "P15",
            "P16",
            "P17",
            "P18",
            "P19",
            "P20",
            "P21",
            "P22",
            "P23",
            "P24",
            "P25",
            "P26",
            "P27",
            "P28",
            "P29",
            "P30",
            "P31",
            "P32",
            "P33",
            "P34",
            "P35",
            "P36",
            "P37",
            "P38",
            "P39",
            "P40",
            "P41",
            "P42",
            "P43",
            "P44",
            "P45",
            "P46",
            "P47",
            "P48",
            "P49",
            "P50",
            "P51",
            "P52",
            "P53",
            "P54",
            "P55",
            "P56",
            "P57",
            "P58",
            "P59",
            "P60",
            "P61",
            "P62",
            "P63",
            "P64",
            "P65",
            "P66",
            "P67",
            "P68",
            "P69",
            "P70",
            "P71",
            "P72",
            "P73",
            "P74",
            "P75",
            "P76",
            "P77",
            "P78",
            "P79",
            "P80",
            "P81",
            "P82",
            "P83",
            "P84",
            "P85",
            "P86",
            "P87",
            "P88",
            "P89",
            "P90",
            "P91",
            "P92",
            "P93",
            "P94",
            "P95",
            "P96",
            "P97",
            "P98",
            "P99",
            "P100"});
            this.teaching_point.Location = new System.Drawing.Point(103, 38);
            this.teaching_point.Name = "teaching_point";
            this.teaching_point.Size = new System.Drawing.Size(102, 24);
            this.teaching_point.TabIndex = 98;
            // 
            // groupBox_tool
            // 
            this.groupBox_tool.Controls.Add(this.pictureBox1);
            this.groupBox_tool.Controls.Add(this.label100);
            this.groupBox_tool.Controls.Add(this.label98);
            this.groupBox_tool.Controls.Add(this.label99);
            this.groupBox_tool.Controls.Add(this.G0Y);
            this.groupBox_tool.Controls.Add(this.G0Z);
            this.groupBox_tool.Controls.Add(this.G0X);
            this.groupBox_tool.Controls.Add(this.Xbutton);
            this.groupBox_tool.Controls.Add(this.Ybutton);
            this.groupBox_tool.Controls.Add(this.groupBox3);
            this.groupBox_tool.Controls.Add(this.Zbutton);
            this.groupBox_tool.Controls.Add(this.button1);
            this.groupBox_tool.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_tool.Location = new System.Drawing.Point(1170, 562);
            this.groupBox_tool.Name = "groupBox_tool";
            this.groupBox_tool.Size = new System.Drawing.Size(925, 405);
            this.groupBox_tool.TabIndex = 153;
            this.groupBox_tool.TabStop = false;
            this.groupBox_tool.Text = "对刀";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(18, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(464, 359);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 181;
            this.pictureBox1.TabStop = false;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.Location = new System.Drawing.Point(832, 288);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(24, 16);
            this.label100.TabIndex = 180;
            this.label100.Text = "mm";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label98.Location = new System.Drawing.Point(832, 142);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(24, 16);
            this.label98.TabIndex = 179;
            this.label98.Text = "mm";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label99.Location = new System.Drawing.Point(832, 215);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(24, 16);
            this.label99.TabIndex = 178;
            this.label99.Text = "mm";
            // 
            // G0Y
            // 
            this.G0Y.Font = new System.Drawing.Font("宋体", 14F);
            this.G0Y.Location = new System.Drawing.Point(708, 212);
            this.G0Y.Name = "G0Y";
            this.G0Y.ReadOnly = true;
            this.G0Y.Size = new System.Drawing.Size(116, 29);
            this.G0Y.TabIndex = 177;
            this.G0Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G0Z
            // 
            this.G0Z.Font = new System.Drawing.Font("宋体", 14F);
            this.G0Z.Location = new System.Drawing.Point(708, 285);
            this.G0Z.Name = "G0Z";
            this.G0Z.ReadOnly = true;
            this.G0Z.Size = new System.Drawing.Size(116, 29);
            this.G0Z.TabIndex = 176;
            this.G0Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G0X
            // 
            this.G0X.Font = new System.Drawing.Font("宋体", 14F);
            this.G0X.Location = new System.Drawing.Point(708, 141);
            this.G0X.Name = "G0X";
            this.G0X.ReadOnly = true;
            this.G0X.Size = new System.Drawing.Size(116, 29);
            this.G0X.TabIndex = 175;
            this.G0X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // check_move
            // 
            this.check_move.Enabled = false;
            this.check_move.Font = new System.Drawing.Font("宋体", 20F);
            this.check_move.ForeColor = System.Drawing.Color.Red;
            this.check_move.Location = new System.Drawing.Point(949, 14);
            this.check_move.Name = "check_move";
            this.check_move.Size = new System.Drawing.Size(173, 38);
            this.check_move.TabIndex = 137;
            this.check_move.Text = "空闲中";
            this.check_move.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // close_SF
            // 
            this.close_SF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.close_SF.Location = new System.Drawing.Point(107, 12);
            this.close_SF.Name = "close_SF";
            this.close_SF.Size = new System.Drawing.Size(91, 39);
            this.close_SF.TabIndex = 139;
            this.close_SF.Text = "关闭伺服";
            this.close_SF.UseVisualStyleBackColor = true;
            this.close_SF.Click += new System.EventHandler(this.close_SF_Click);
            // 
            // open_SF
            // 
            this.open_SF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.open_SF.Location = new System.Drawing.Point(6, 12);
            this.open_SF.Name = "open_SF";
            this.open_SF.Size = new System.Drawing.Size(92, 39);
            this.open_SF.TabIndex = 140;
            this.open_SF.Text = "打开伺服";
            this.open_SF.UseVisualStyleBackColor = true;
            this.open_SF.Click += new System.EventHandler(this.open_SF_Click);
            // 
            // Running_Status
            // 
            this.Running_Status.Font = new System.Drawing.Font("宋体", 18F);
            this.Running_Status.Location = new System.Drawing.Point(12, 484);
            this.Running_Status.Name = "Running_Status";
            this.Running_Status.Size = new System.Drawing.Size(150, 70);
            this.Running_Status.TabIndex = 146;
            this.Running_Status.Text = "运行状态";
            this.Running_Status.UseVisualStyleBackColor = true;
            this.Running_Status.Click += new System.EventHandler(this.Running_Status_Click);
            // 
            // Workpiece_system
            // 
            this.Workpiece_system.Font = new System.Drawing.Font("宋体", 18F);
            this.Workpiece_system.Location = new System.Drawing.Point(12, 247);
            this.Workpiece_system.Name = "Workpiece_system";
            this.Workpiece_system.Size = new System.Drawing.Size(150, 70);
            this.Workpiece_system.TabIndex = 148;
            this.Workpiece_system.Text = "对刀";
            this.Workpiece_system.UseVisualStyleBackColor = true;
            this.Workpiece_system.Click += new System.EventHandler(this.Workpiece_system_Click);
            // 
            // button_processing
            // 
            this.button_processing.Font = new System.Drawing.Font("宋体", 18F);
            this.button_processing.Location = new System.Drawing.Point(12, 326);
            this.button_processing.Name = "button_processing";
            this.button_processing.Size = new System.Drawing.Size(150, 70);
            this.button_processing.TabIndex = 149;
            this.button_processing.Text = "加工";
            this.button_processing.UseVisualStyleBackColor = true;
            this.button_processing.Click += new System.EventHandler(this.button_processing_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.forward_correcting);
            this.groupBox8.Controls.Add(this.close_handwheel);
            this.groupBox8.Controls.Add(this.button_change_speed);
            this.groupBox8.Controls.Add(this.open_handwheel);
            this.groupBox8.Controls.Add(this.open_SF);
            this.groupBox8.Controls.Add(this.check_move);
            this.groupBox8.Controls.Add(this.close_SF);
            this.groupBox8.Controls.Add(this.clear_position_button);
            this.groupBox8.Controls.Add(this.stop_button);
            this.groupBox8.Controls.Add(this.Alarm_clearance);
            this.groupBox8.Location = new System.Drawing.Point(172, 12);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1131, 58);
            this.groupBox8.TabIndex = 150;
            this.groupBox8.TabStop = false;
            // 
            // close_handwheel
            // 
            this.close_handwheel.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.close_handwheel.Location = new System.Drawing.Point(408, 13);
            this.close_handwheel.Name = "close_handwheel";
            this.close_handwheel.Size = new System.Drawing.Size(92, 39);
            this.close_handwheel.TabIndex = 153;
            this.close_handwheel.Text = "关闭手轮";
            this.close_handwheel.UseVisualStyleBackColor = true;
            this.close_handwheel.Click += new System.EventHandler(this.close_handwheel_Click);
            // 
            // open_handwheel
            // 
            this.open_handwheel.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.open_handwheel.Location = new System.Drawing.Point(307, 13);
            this.open_handwheel.Name = "open_handwheel";
            this.open_handwheel.Size = new System.Drawing.Size(92, 38);
            this.open_handwheel.TabIndex = 151;
            this.open_handwheel.Text = "启用手轮";
            this.open_handwheel.UseVisualStyleBackColor = true;
            this.open_handwheel.Click += new System.EventHandler(this.open_handwheel_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.spindle_speed);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.t_dec);
            this.groupBox9.Controls.Add(this.start_speed);
            this.groupBox9.Controls.Add(this.label6);
            this.groupBox9.Controls.Add(this.label3);
            this.groupBox9.Controls.Add(this.t_acc);
            this.groupBox9.Controls.Add(this.run_speed);
            this.groupBox9.Controls.Add(this.label5);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.stop_speed);
            this.groupBox9.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox9.Location = new System.Drawing.Point(172, 84);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1131, 55);
            this.groupBox9.TabIndex = 151;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "运动参数设置(mm,rp,s)";
            // 
            // dimention_Box
            // 
            this.dimention_Box.Controls.Add(this.dimention_keep);
            this.dimention_Box.Controls.Add(this.dimention_change);
            this.dimention_Box.Controls.Add(this.label46);
            this.dimention_Box.Controls.Add(this.value_d4max);
            this.dimention_Box.Controls.Add(this.value_d4min);
            this.dimention_Box.Controls.Add(this.value_d3max);
            this.dimention_Box.Controls.Add(this.value_d3min);
            this.dimention_Box.Controls.Add(this.value_d2max);
            this.dimention_Box.Controls.Add(this.value_d2min);
            this.dimention_Box.Controls.Add(this.value_d1max);
            this.dimention_Box.Controls.Add(this.value_d1min);
            this.dimention_Box.Controls.Add(this.label44);
            this.dimention_Box.Controls.Add(this.label45);
            this.dimention_Box.Controls.Add(this.label47);
            this.dimention_Box.Controls.Add(this.label48);
            this.dimention_Box.Controls.Add(this.label49);
            this.dimention_Box.Controls.Add(this.label50);
            this.dimention_Box.Controls.Add(this.label51);
            this.dimention_Box.Controls.Add(this.label52);
            this.dimention_Box.Controls.Add(this.value_U42max);
            this.dimention_Box.Controls.Add(this.value_U42min);
            this.dimention_Box.Controls.Add(this.value_S32max);
            this.dimention_Box.Controls.Add(this.value_S32min);
            this.dimention_Box.Controls.Add(this.value_U22max);
            this.dimention_Box.Controls.Add(this.value_U22min);
            this.dimention_Box.Controls.Add(this.value_U12max);
            this.dimention_Box.Controls.Add(this.value_U12min);
            this.dimention_Box.Controls.Add(this.label53);
            this.dimention_Box.Controls.Add(this.label54);
            this.dimention_Box.Controls.Add(this.label55);
            this.dimention_Box.Controls.Add(this.label56);
            this.dimention_Box.Controls.Add(this.label57);
            this.dimention_Box.Controls.Add(this.label58);
            this.dimention_Box.Controls.Add(this.label59);
            this.dimention_Box.Controls.Add(this.label60);
            this.dimention_Box.Controls.Add(this.value_U4max);
            this.dimention_Box.Controls.Add(this.value_U4min);
            this.dimention_Box.Controls.Add(this.value_S3max);
            this.dimention_Box.Controls.Add(this.value_S3min);
            this.dimention_Box.Controls.Add(this.value_U2max);
            this.dimention_Box.Controls.Add(this.value_U2min);
            this.dimention_Box.Controls.Add(this.value_U1max);
            this.dimention_Box.Controls.Add(this.value_U1min);
            this.dimention_Box.Controls.Add(this.label61);
            this.dimention_Box.Controls.Add(this.label62);
            this.dimention_Box.Controls.Add(this.label63);
            this.dimention_Box.Controls.Add(this.label64);
            this.dimention_Box.Controls.Add(this.label65);
            this.dimention_Box.Controls.Add(this.label66);
            this.dimention_Box.Controls.Add(this.label67);
            this.dimention_Box.Controls.Add(this.label68);
            this.dimention_Box.Controls.Add(this.value_R4max);
            this.dimention_Box.Controls.Add(this.value_R4min);
            this.dimention_Box.Controls.Add(this.value_R3max);
            this.dimention_Box.Controls.Add(this.value_R3min);
            this.dimention_Box.Controls.Add(this.value_R2max);
            this.dimention_Box.Controls.Add(this.value_R2min);
            this.dimention_Box.Controls.Add(this.value_R1max);
            this.dimention_Box.Controls.Add(this.value_R1min);
            this.dimention_Box.Controls.Add(this.label69);
            this.dimention_Box.Controls.Add(this.label70);
            this.dimention_Box.Controls.Add(this.label71);
            this.dimention_Box.Controls.Add(this.label72);
            this.dimention_Box.Controls.Add(this.label73);
            this.dimention_Box.Controls.Add(this.label74);
            this.dimention_Box.Controls.Add(this.label75);
            this.dimention_Box.Controls.Add(this.label76);
            this.dimention_Box.Controls.Add(this.label77);
            this.dimention_Box.Controls.Add(this.value_b4);
            this.dimention_Box.Controls.Add(this.value_b2);
            this.dimention_Box.Controls.Add(this.value_b3);
            this.dimention_Box.Controls.Add(this.label13);
            this.dimention_Box.Controls.Add(this.label14);
            this.dimention_Box.Controls.Add(this.label36);
            this.dimention_Box.Controls.Add(this.label37);
            this.dimention_Box.Controls.Add(this.value_b1);
            this.dimention_Box.Controls.Add(this.label38);
            this.dimention_Box.Controls.Add(this.value_a4);
            this.dimention_Box.Controls.Add(this.value_a2);
            this.dimention_Box.Controls.Add(this.value_a3);
            this.dimention_Box.Controls.Add(this.label39);
            this.dimention_Box.Controls.Add(this.label40);
            this.dimention_Box.Controls.Add(this.label41);
            this.dimention_Box.Controls.Add(this.label42);
            this.dimention_Box.Controls.Add(this.value_a1);
            this.dimention_Box.Controls.Add(this.label43);
            this.dimention_Box.Font = new System.Drawing.Font("宋体", 12F);
            this.dimention_Box.Location = new System.Drawing.Point(1136, 149);
            this.dimention_Box.Name = "dimention_Box";
            this.dimention_Box.Size = new System.Drawing.Size(920, 405);
            this.dimention_Box.TabIndex = 152;
            this.dimention_Box.TabStop = false;
            this.dimention_Box.Text = "机床尺度定义";
            // 
            // dimention_keep
            // 
            this.dimention_keep.Font = new System.Drawing.Font("宋体", 14F);
            this.dimention_keep.Location = new System.Drawing.Point(810, 160);
            this.dimention_keep.Name = "dimention_keep";
            this.dimention_keep.Size = new System.Drawing.Size(98, 54);
            this.dimention_keep.TabIndex = 213;
            this.dimention_keep.Text = "取消修改";
            this.dimention_keep.UseVisualStyleBackColor = true;
            this.dimention_keep.Click += new System.EventHandler(this.dimention_keep_Click);
            // 
            // dimention_change
            // 
            this.dimention_change.Font = new System.Drawing.Font("宋体", 14F);
            this.dimention_change.Location = new System.Drawing.Point(810, 256);
            this.dimention_change.Name = "dimention_change";
            this.dimention_change.Size = new System.Drawing.Size(98, 54);
            this.dimention_change.TabIndex = 212;
            this.dimention_change.Text = "确认修改";
            this.dimention_change.UseVisualStyleBackColor = true;
            this.dimention_change.Click += new System.EventHandler(this.dimention_change_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(613, 88);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(126, 14);
            this.label46.TabIndex = 211;
            this.label46.Text = "主动关节极限位置:";
            // 
            // value_d4max
            // 
            this.value_d4max.Location = new System.Drawing.Point(706, 375);
            this.value_d4max.Name = "value_d4max";
            this.value_d4max.Size = new System.Drawing.Size(74, 26);
            this.value_d4max.TabIndex = 210;
            this.value_d4max.Text = "320";
            this.value_d4max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d4min
            // 
            this.value_d4min.Location = new System.Drawing.Point(705, 339);
            this.value_d4min.Name = "value_d4min";
            this.value_d4min.Size = new System.Drawing.Size(74, 26);
            this.value_d4min.TabIndex = 209;
            this.value_d4min.Text = "137";
            this.value_d4min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d3max
            // 
            this.value_d3max.Location = new System.Drawing.Point(706, 303);
            this.value_d3max.Name = "value_d3max";
            this.value_d3max.Size = new System.Drawing.Size(74, 26);
            this.value_d3max.TabIndex = 208;
            this.value_d3max.Text = "320";
            this.value_d3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d3min
            // 
            this.value_d3min.Location = new System.Drawing.Point(706, 268);
            this.value_d3min.Name = "value_d3min";
            this.value_d3min.Size = new System.Drawing.Size(74, 26);
            this.value_d3min.TabIndex = 207;
            this.value_d3min.Text = "137";
            this.value_d3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d2max
            // 
            this.value_d2max.Location = new System.Drawing.Point(705, 229);
            this.value_d2max.Name = "value_d2max";
            this.value_d2max.Size = new System.Drawing.Size(74, 26);
            this.value_d2max.TabIndex = 206;
            this.value_d2max.Text = "320";
            this.value_d2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d2min
            // 
            this.value_d2min.Location = new System.Drawing.Point(706, 190);
            this.value_d2min.Name = "value_d2min";
            this.value_d2min.Size = new System.Drawing.Size(74, 26);
            this.value_d2min.TabIndex = 205;
            this.value_d2min.Text = "137";
            this.value_d2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d1max
            // 
            this.value_d1max.Location = new System.Drawing.Point(706, 154);
            this.value_d1max.Name = "value_d1max";
            this.value_d1max.Size = new System.Drawing.Size(74, 26);
            this.value_d1max.TabIndex = 204;
            this.value_d1max.Text = "320";
            this.value_d1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d1min
            // 
            this.value_d1min.Location = new System.Drawing.Point(706, 117);
            this.value_d1min.Name = "value_d1min";
            this.value_d1min.Size = new System.Drawing.Size(74, 26);
            this.value_d1min.TabIndex = 203;
            this.value_d1min.Text = "137";
            this.value_d1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(611, 380);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(91, 14);
            this.label44.TabIndex = 202;
            this.label44.Text = "d4_max/(mm):";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(611, 343);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(91, 14);
            this.label45.TabIndex = 201;
            this.label45.Text = "d4_min/(mm):";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(611, 308);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(91, 14);
            this.label47.TabIndex = 200;
            this.label47.Text = "d3_max/(mm):";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(611, 273);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(91, 14);
            this.label48.TabIndex = 199;
            this.label48.Text = "d3_min/(mm):";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(611, 234);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(91, 14);
            this.label49.TabIndex = 198;
            this.label49.Text = "d2_max/(mm):";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(611, 195);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(91, 14);
            this.label50.TabIndex = 197;
            this.label50.Text = "d2_min/(mm):";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(611, 159);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(91, 14);
            this.label51.TabIndex = 196;
            this.label51.Text = "d1_max/(mm):";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label52.Location = new System.Drawing.Point(611, 122);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(91, 14);
            this.label52.TabIndex = 195;
            this.label52.Text = "d1_min/(mm):";
            // 
            // value_U42max
            // 
            this.value_U42max.Location = new System.Drawing.Point(500, 374);
            this.value_U42max.Name = "value_U42max";
            this.value_U42max.Size = new System.Drawing.Size(74, 26);
            this.value_U42max.TabIndex = 194;
            this.value_U42max.Text = "125";
            this.value_U42max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U42min
            // 
            this.value_U42min.Location = new System.Drawing.Point(499, 338);
            this.value_U42min.Name = "value_U42min";
            this.value_U42min.Size = new System.Drawing.Size(74, 26);
            this.value_U42min.TabIndex = 193;
            this.value_U42min.Text = "55";
            this.value_U42min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S32max
            // 
            this.value_S32max.Location = new System.Drawing.Point(500, 302);
            this.value_S32max.Name = "value_S32max";
            this.value_S32max.Size = new System.Drawing.Size(74, 26);
            this.value_S32max.TabIndex = 192;
            this.value_S32max.Text = "120";
            this.value_S32max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S32min
            // 
            this.value_S32min.Location = new System.Drawing.Point(500, 267);
            this.value_S32min.Name = "value_S32min";
            this.value_S32min.Size = new System.Drawing.Size(74, 26);
            this.value_S32min.TabIndex = 191;
            this.value_S32min.Text = "60";
            this.value_S32min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U22max
            // 
            this.value_U22max.Location = new System.Drawing.Point(499, 228);
            this.value_U22max.Name = "value_U22max";
            this.value_U22max.Size = new System.Drawing.Size(74, 26);
            this.value_U22max.TabIndex = 190;
            this.value_U22max.Text = "125";
            this.value_U22max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U22min
            // 
            this.value_U22min.Location = new System.Drawing.Point(500, 189);
            this.value_U22min.Name = "value_U22min";
            this.value_U22min.Size = new System.Drawing.Size(74, 26);
            this.value_U22min.TabIndex = 189;
            this.value_U22min.Text = "55";
            this.value_U22min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U12max
            // 
            this.value_U12max.Location = new System.Drawing.Point(500, 153);
            this.value_U12max.Name = "value_U12max";
            this.value_U12max.Size = new System.Drawing.Size(74, 26);
            this.value_U12max.TabIndex = 188;
            this.value_U12max.Text = "125";
            this.value_U12max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U12min
            // 
            this.value_U12min.Location = new System.Drawing.Point(500, 116);
            this.value_U12min.Name = "value_U12min";
            this.value_U12min.Size = new System.Drawing.Size(74, 26);
            this.value_U12min.TabIndex = 187;
            this.value_U12min.Text = "55";
            this.value_U12min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(399, 380);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(98, 14);
            this.label53.TabIndex = 186;
            this.label53.Text = "U42_max/(°):";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label54.Location = new System.Drawing.Point(399, 343);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(98, 14);
            this.label54.TabIndex = 185;
            this.label54.Text = "U42_min/(°):";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label55.Location = new System.Drawing.Point(399, 308);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(98, 14);
            this.label55.TabIndex = 184;
            this.label55.Text = "S32_max/(°):";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.Location = new System.Drawing.Point(399, 272);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(98, 14);
            this.label56.TabIndex = 183;
            this.label56.Text = "S32_min/(°):";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(399, 234);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(98, 14);
            this.label57.TabIndex = 182;
            this.label57.Text = "U22_max/(°):";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(399, 196);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(98, 14);
            this.label58.TabIndex = 181;
            this.label58.Text = "U22_min/(°):";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(399, 160);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(98, 14);
            this.label59.TabIndex = 180;
            this.label59.Text = "U12_max/(°):";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(399, 121);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(98, 14);
            this.label60.TabIndex = 179;
            this.label60.Text = "U12_min/(°):";
            // 
            // value_U4max
            // 
            this.value_U4max.Location = new System.Drawing.Point(306, 373);
            this.value_U4max.Name = "value_U4max";
            this.value_U4max.Size = new System.Drawing.Size(74, 26);
            this.value_U4max.TabIndex = 178;
            this.value_U4max.Text = "120";
            this.value_U4max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U4min
            // 
            this.value_U4min.Location = new System.Drawing.Point(305, 337);
            this.value_U4min.Name = "value_U4min";
            this.value_U4min.Size = new System.Drawing.Size(74, 26);
            this.value_U4min.TabIndex = 177;
            this.value_U4min.Text = "60";
            this.value_U4min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S3max
            // 
            this.value_S3max.Location = new System.Drawing.Point(306, 301);
            this.value_S3max.Name = "value_S3max";
            this.value_S3max.Size = new System.Drawing.Size(74, 26);
            this.value_S3max.TabIndex = 176;
            this.value_S3max.Text = "125";
            this.value_S3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S3min
            // 
            this.value_S3min.Location = new System.Drawing.Point(306, 266);
            this.value_S3min.Name = "value_S3min";
            this.value_S3min.Size = new System.Drawing.Size(74, 26);
            this.value_S3min.TabIndex = 175;
            this.value_S3min.Text = "55";
            this.value_S3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U2max
            // 
            this.value_U2max.Location = new System.Drawing.Point(305, 227);
            this.value_U2max.Name = "value_U2max";
            this.value_U2max.Size = new System.Drawing.Size(74, 26);
            this.value_U2max.TabIndex = 174;
            this.value_U2max.Text = "125";
            this.value_U2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U2min
            // 
            this.value_U2min.Location = new System.Drawing.Point(306, 188);
            this.value_U2min.Name = "value_U2min";
            this.value_U2min.Size = new System.Drawing.Size(74, 26);
            this.value_U2min.TabIndex = 173;
            this.value_U2min.Text = "55";
            this.value_U2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U1max
            // 
            this.value_U1max.Location = new System.Drawing.Point(306, 152);
            this.value_U1max.Name = "value_U1max";
            this.value_U1max.Size = new System.Drawing.Size(74, 26);
            this.value_U1max.TabIndex = 172;
            this.value_U1max.Text = "125";
            this.value_U1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U1min
            // 
            this.value_U1min.Location = new System.Drawing.Point(306, 115);
            this.value_U1min.Name = "value_U1min";
            this.value_U1min.Size = new System.Drawing.Size(74, 26);
            this.value_U1min.TabIndex = 171;
            this.value_U1min.Text = "55";
            this.value_U1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label61.Location = new System.Drawing.Point(212, 378);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(91, 14);
            this.label61.TabIndex = 170;
            this.label61.Text = "U4_max/(°):";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.Location = new System.Drawing.Point(212, 341);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(91, 14);
            this.label62.TabIndex = 169;
            this.label62.Text = "U4_min/(°):";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(212, 307);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(91, 14);
            this.label63.TabIndex = 168;
            this.label63.Text = "S3_max/(°):";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.Location = new System.Drawing.Point(212, 271);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(91, 14);
            this.label64.TabIndex = 167;
            this.label64.Text = "S3_min/(°):";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(212, 232);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(91, 14);
            this.label65.TabIndex = 166;
            this.label65.Text = "U2_max/(°):";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(212, 194);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(91, 14);
            this.label66.TabIndex = 165;
            this.label66.Text = "U2_min/(°):";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(212, 156);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(91, 14);
            this.label67.TabIndex = 164;
            this.label67.Text = "U1_max/(°):";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(212, 119);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(91, 14);
            this.label68.TabIndex = 163;
            this.label68.Text = "U1_min/(°):";
            // 
            // value_R4max
            // 
            this.value_R4max.Location = new System.Drawing.Point(114, 373);
            this.value_R4max.Name = "value_R4max";
            this.value_R4max.Size = new System.Drawing.Size(74, 26);
            this.value_R4max.TabIndex = 162;
            this.value_R4max.Text = "150";
            this.value_R4max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R4min
            // 
            this.value_R4min.Location = new System.Drawing.Point(113, 337);
            this.value_R4min.Name = "value_R4min";
            this.value_R4min.Size = new System.Drawing.Size(74, 26);
            this.value_R4min.TabIndex = 161;
            this.value_R4min.Text = "30";
            this.value_R4min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R3max
            // 
            this.value_R3max.Location = new System.Drawing.Point(114, 301);
            this.value_R3max.Name = "value_R3max";
            this.value_R3max.Size = new System.Drawing.Size(74, 26);
            this.value_R3max.TabIndex = 160;
            this.value_R3max.Text = "150";
            this.value_R3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R3min
            // 
            this.value_R3min.Location = new System.Drawing.Point(114, 266);
            this.value_R3min.Name = "value_R3min";
            this.value_R3min.Size = new System.Drawing.Size(74, 26);
            this.value_R3min.TabIndex = 159;
            this.value_R3min.Text = "30";
            this.value_R3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R2max
            // 
            this.value_R2max.Location = new System.Drawing.Point(113, 227);
            this.value_R2max.Name = "value_R2max";
            this.value_R2max.Size = new System.Drawing.Size(74, 26);
            this.value_R2max.TabIndex = 158;
            this.value_R2max.Text = "150";
            this.value_R2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R2min
            // 
            this.value_R2min.Location = new System.Drawing.Point(114, 188);
            this.value_R2min.Name = "value_R2min";
            this.value_R2min.Size = new System.Drawing.Size(74, 26);
            this.value_R2min.TabIndex = 157;
            this.value_R2min.Text = "30";
            this.value_R2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R1max
            // 
            this.value_R1max.Location = new System.Drawing.Point(114, 152);
            this.value_R1max.Name = "value_R1max";
            this.value_R1max.Size = new System.Drawing.Size(74, 26);
            this.value_R1max.TabIndex = 156;
            this.value_R1max.Text = "150";
            this.value_R1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R1min
            // 
            this.value_R1min.Location = new System.Drawing.Point(114, 115);
            this.value_R1min.Name = "value_R1min";
            this.value_R1min.Size = new System.Drawing.Size(74, 26);
            this.value_R1min.TabIndex = 155;
            this.value_R1min.Text = "30";
            this.value_R1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(20, 379);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(91, 14);
            this.label69.TabIndex = 154;
            this.label69.Text = "R4_max/(°):";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(20, 342);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(91, 14);
            this.label70.TabIndex = 153;
            this.label70.Text = "R4_min/(°):";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(20, 307);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(91, 14);
            this.label71.TabIndex = 152;
            this.label71.Text = "R3_max/(°):";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.Location = new System.Drawing.Point(20, 271);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(91, 14);
            this.label72.TabIndex = 151;
            this.label72.Text = "R3_min/(°):";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label73.Location = new System.Drawing.Point(20, 233);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(91, 14);
            this.label73.TabIndex = 150;
            this.label73.Text = "R2_max/(°):";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.Location = new System.Drawing.Point(20, 193);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(91, 14);
            this.label74.TabIndex = 149;
            this.label74.Text = "R2_min/(°):";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.Location = new System.Drawing.Point(20, 157);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(91, 14);
            this.label75.TabIndex = 148;
            this.label75.Text = "R1_max/(°):";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label76.Location = new System.Drawing.Point(20, 119);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(91, 14);
            this.label76.TabIndex = 147;
            this.label76.Text = "R1_min/(°):";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(17, 88);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(112, 14);
            this.label77.TabIndex = 146;
            this.label77.Text = "被动关节极限角:";
            // 
            // value_b4
            // 
            this.value_b4.Location = new System.Drawing.Point(834, 45);
            this.value_b4.Name = "value_b4";
            this.value_b4.Size = new System.Drawing.Size(74, 26);
            this.value_b4.TabIndex = 55;
            this.value_b4.Text = "90";
            this.value_b4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_b2
            // 
            this.value_b2.Location = new System.Drawing.Point(646, 45);
            this.value_b2.Name = "value_b2";
            this.value_b2.Size = new System.Drawing.Size(74, 26);
            this.value_b2.TabIndex = 54;
            this.value_b2.Text = "90";
            this.value_b2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_b3
            // 
            this.value_b3.Location = new System.Drawing.Point(739, 45);
            this.value_b3.Name = "value_b3";
            this.value_b3.Size = new System.Drawing.Size(74, 26);
            this.value_b3.TabIndex = 53;
            this.value_b3.Text = "90";
            this.value_b3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(659, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 14);
            this.label13.TabIndex = 52;
            this.label13.Text = "b2/(mm)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(749, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 14);
            this.label14.TabIndex = 51;
            this.label14.Text = "b3/(mm)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(842, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(56, 14);
            this.label36.TabIndex = 50;
            this.label36.Text = "b4/(mm)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(564, 28);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 14);
            this.label37.TabIndex = 49;
            this.label37.Text = "b1/(mm)";
            // 
            // value_b1
            // 
            this.value_b1.Location = new System.Drawing.Point(553, 45);
            this.value_b1.Name = "value_b1";
            this.value_b1.Size = new System.Drawing.Size(74, 26);
            this.value_b1.TabIndex = 48;
            this.value_b1.Text = "90";
            this.value_b1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(466, 45);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(84, 14);
            this.label38.TabIndex = 47;
            this.label38.Text = "动平台半径:";
            // 
            // value_a4
            // 
            this.value_a4.Location = new System.Drawing.Point(377, 46);
            this.value_a4.Name = "value_a4";
            this.value_a4.Size = new System.Drawing.Size(74, 26);
            this.value_a4.TabIndex = 46;
            this.value_a4.Text = "150";
            this.value_a4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_a2
            // 
            this.value_a2.Location = new System.Drawing.Point(188, 45);
            this.value_a2.Name = "value_a2";
            this.value_a2.Size = new System.Drawing.Size(74, 26);
            this.value_a2.TabIndex = 45;
            this.value_a2.Text = "150";
            this.value_a2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_a3
            // 
            this.value_a3.Location = new System.Drawing.Point(282, 46);
            this.value_a3.Name = "value_a3";
            this.value_a3.Size = new System.Drawing.Size(74, 26);
            this.value_a3.TabIndex = 44;
            this.value_a3.Text = "150";
            this.value_a3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label39.Location = new System.Drawing.Point(201, 28);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(56, 14);
            this.label39.TabIndex = 43;
            this.label39.Text = "a2/(mm)";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(291, 27);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 14);
            this.label40.TabIndex = 42;
            this.label40.Text = "a3/(mm)";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(385, 28);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(56, 14);
            this.label41.TabIndex = 41;
            this.label41.Text = "a4/(mm)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(107, 28);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(56, 14);
            this.label42.TabIndex = 40;
            this.label42.Text = "a1/(mm)";
            // 
            // value_a1
            // 
            this.value_a1.Location = new System.Drawing.Point(96, 45);
            this.value_a1.Name = "value_a1";
            this.value_a1.Size = new System.Drawing.Size(74, 26);
            this.value_a1.TabIndex = 39;
            this.value_a1.Text = "150";
            this.value_a1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(8, 45);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(84, 14);
            this.label43.TabIndex = 38;
            this.label43.Text = "静平台半径:";
            // 
            // calibration
            // 
            this.calibration.Font = new System.Drawing.Font("宋体", 18F);
            this.calibration.Location = new System.Drawing.Point(12, 169);
            this.calibration.Name = "calibration";
            this.calibration.Size = new System.Drawing.Size(150, 70);
            this.calibration.TabIndex = 94;
            this.calibration.Text = "机器校零";
            this.calibration.UseVisualStyleBackColor = true;
            this.calibration.Click += new System.EventHandler(this.calibration_Click);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // forward_correcting
            // 
            this.forward_correcting.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.forward_correcting.Location = new System.Drawing.Point(706, 12);
            this.forward_correcting.Name = "forward_correcting";
            this.forward_correcting.Size = new System.Drawing.Size(92, 40);
            this.forward_correcting.TabIndex = 154;
            this.forward_correcting.Text = "正解验证";
            this.forward_correcting.UseVisualStyleBackColor = true;
            this.forward_correcting.Click += new System.EventHandler(this.forward_correcting_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1314, 700);
            this.Controls.Add(this.groupBox_running);
            this.Controls.Add(this.groupBox_tool);
            this.Controls.Add(this.groupBox_teach);
            this.Controls.Add(this.groupBox_processing);
            this.Controls.Add(this.dimention_Box);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.calibration_Box);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.button_processing);
            this.Controls.Add(this.Workpiece_system);
            this.Controls.Add(this.Running_Status);
            this.Controls.Add(this.calibration);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button_single);
            this.Controls.Add(this.button_dimention);
            this.Controls.Add(this.link_button);
            this.Name = "main";
            this.Text = " ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.main_FormClosed);
            this.Load += new System.EventHandler(this.main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.t_dec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_acc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.run_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.processing_speed_change)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spindle_speed)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox_processing.ResumeLayout(false);
            this.groupBox_processing.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picture_processing)).EndInit();
            this.calibration_Box.ResumeLayout(false);
            this.calibration_Box.PerformLayout();
            this.groupBox_running.ResumeLayout(false);
            this.groupBox_running.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox_teach.ResumeLayout(false);
            this.groupBox_teach.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox_tool.ResumeLayout(false);
            this.groupBox_tool.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.dimention_Box.ResumeLayout(false);
            this.dimention_Box.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Xbutton;
        private System.Windows.Forms.Button stop_button;
        private System.Windows.Forms.Button link_button;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button clear_position_button;
        private System.Windows.Forms.Button Alarm_clearance;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_1;
        private System.Windows.Forms.TextBox textBox_2;
        private System.Windows.Forms.TextBox textBox_3;
        private System.Windows.Forms.TextBox textBox_4;
        private System.Windows.Forms.TextBox textBox_5;
        private System.Windows.Forms.TextBox textBox_6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBox_12;
        private System.Windows.Forms.TextBox textBox_11;
        private System.Windows.Forms.TextBox textBox_10;
        private System.Windows.Forms.TextBox textBox_9;
        private System.Windows.Forms.TextBox textBox_8;
        private System.Windows.Forms.TextBox textBox_7;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_change_speed;
        private System.Windows.Forms.TextBox textBox_pointcount;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_datainput;
        private System.Windows.Forms.TextBox textBox_pointnum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_run;
        private System.Windows.Forms.NumericUpDown spindle_speed;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_spindle_run;
        private System.Windows.Forms.Button button_spindle_stop;
        private System.Windows.Forms.Button button_stop0;
        private System.Windows.Forms.Button button_stop1;
        private System.Windows.Forms.Button Ybutton;
        private System.Windows.Forms.Button Zbutton;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button_dimention;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button_single;
        public System.Windows.Forms.NumericUpDown t_dec;
        public System.Windows.Forms.NumericUpDown t_acc;
        public System.Windows.Forms.NumericUpDown stop_speed;
        public System.Windows.Forms.NumericUpDown run_speed;
        public System.Windows.Forms.NumericUpDown start_speed;
        public System.Windows.Forms.TextBox value_tool;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ToolStripMenuItem 单轴控制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置工件坐标ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 机床尺度定义ToolStripMenuItem;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox value_rtool;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox GX_position;
        private System.Windows.Forms.TextBox PKMB_position;
        private System.Windows.Forms.TextBox GY_position;
        private System.Windows.Forms.TextBox PKMA_position;
        private System.Windows.Forms.TextBox GZ_position;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox PKMZ_position;
        private System.Windows.Forms.Button processing_speed;
        public System.Windows.Forms.NumericUpDown processing_speed_change;
        private System.Windows.Forms.TextBox check_move;
        private System.Windows.Forms.Button close_SF;
        private System.Windows.Forms.Button open_SF;
        private System.Windows.Forms.Button Running_Status;
        private System.Windows.Forms.Button Workpiece_system;
        private System.Windows.Forms.Button button_processing;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button close_handwheel;
        private System.Windows.Forms.Button open_handwheel;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox dimention_Box;
        private System.Windows.Forms.TextBox value_b4;
        private System.Windows.Forms.TextBox value_b2;
        private System.Windows.Forms.TextBox value_b3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox value_b1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox value_a4;
        private System.Windows.Forms.TextBox value_a2;
        private System.Windows.Forms.TextBox value_a3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox value_a1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox value_d4max;
        private System.Windows.Forms.TextBox value_d4min;
        private System.Windows.Forms.TextBox value_d3max;
        private System.Windows.Forms.TextBox value_d3min;
        private System.Windows.Forms.TextBox value_d2max;
        private System.Windows.Forms.TextBox value_d2min;
        private System.Windows.Forms.TextBox value_d1max;
        private System.Windows.Forms.TextBox value_d1min;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox value_U42max;
        private System.Windows.Forms.TextBox value_U42min;
        private System.Windows.Forms.TextBox value_S32max;
        private System.Windows.Forms.TextBox value_S32min;
        private System.Windows.Forms.TextBox value_U22max;
        private System.Windows.Forms.TextBox value_U22min;
        private System.Windows.Forms.TextBox value_U12max;
        private System.Windows.Forms.TextBox value_U12min;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox value_U4max;
        private System.Windows.Forms.TextBox value_U4min;
        private System.Windows.Forms.TextBox value_S3max;
        private System.Windows.Forms.TextBox value_S3min;
        private System.Windows.Forms.TextBox value_U2max;
        private System.Windows.Forms.TextBox value_U2min;
        private System.Windows.Forms.TextBox value_U1max;
        private System.Windows.Forms.TextBox value_U1min;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox value_R4max;
        private System.Windows.Forms.TextBox value_R4min;
        private System.Windows.Forms.TextBox value_R3max;
        private System.Windows.Forms.TextBox value_R3min;
        private System.Windows.Forms.TextBox value_R2max;
        private System.Windows.Forms.TextBox value_R2min;
        private System.Windows.Forms.TextBox value_R1max;
        private System.Windows.Forms.TextBox value_R1min;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.GroupBox calibration_Box;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button dimention_keep;
        private System.Windows.Forms.Button dimention_change;
        private System.Windows.Forms.Button calibration;
        private System.Windows.Forms.Button tool_change;
        private System.Windows.Forms.GroupBox groupBox_teach;
        private System.Windows.Forms.GroupBox groupBox_running;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox programming;
        private System.Windows.Forms.Button button_continue;
        private System.Windows.Forms.Button button_stoping0;
        private System.Windows.Forms.Button button_edit;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox GX0_position;
        private System.Windows.Forms.TextBox PKMB0_position;
        private System.Windows.Forms.TextBox GY0_position;
        private System.Windows.Forms.TextBox PKMA0_position;
        private System.Windows.Forms.TextBox GZ0_position;
        private System.Windows.Forms.Button button_stoping;
        private System.Windows.Forms.Button button_running;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.ComboBox teached_point;
        private System.Windows.Forms.Button moveto;
        private System.Windows.Forms.Button teaching;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.ComboBox teaching_point;
        private System.Windows.Forms.Button confirm_zero;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.GroupBox groupBox_tool;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox G0Y;
        private System.Windows.Forms.TextBox G0Z;
        private System.Windows.Forms.TextBox G0X;
        private System.Windows.Forms.GroupBox groupBox_processing;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.PictureBox picture_processing;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.ProgressBar progressBar_processing;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Button forward_correcting;
    }
}

