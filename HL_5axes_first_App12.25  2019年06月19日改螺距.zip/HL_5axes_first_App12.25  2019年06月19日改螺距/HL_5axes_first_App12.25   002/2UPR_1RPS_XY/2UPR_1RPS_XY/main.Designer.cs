﻿namespace _2UPR_1RPS_XY
{
    partial class main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.link_button = new System.Windows.Forms.Button();
            this.open_SF = new System.Windows.Forms.Button();
            this.close_SF = new System.Windows.Forms.Button();
            this.calibration = new System.Windows.Forms.Button();
            this.button_single = new System.Windows.Forms.Button();
            this.Running_Status = new System.Windows.Forms.Button();
            this.processing = new System.Windows.Forms.Button();
            this.Workpiece_system = new System.Windows.Forms.Button();
            this.clear_position_button = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.correct_forward = new System.Windows.Forms.Button();
            this.close_handwheel = new System.Windows.Forms.Button();
            this.open_handwheel = new System.Windows.Forms.Button();
            this.button_change_speed = new System.Windows.Forms.Button();
            this.check_move = new System.Windows.Forms.TextBox();
            this.stop_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.t_dec = new System.Windows.Forms.NumericUpDown();
            this.spindle_speed = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.t_acc = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.stop_speed = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.run_speed = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.start_speed = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox_teach = new System.Windows.Forms.GroupBox();
            this.programming = new System.Windows.Forms.TextBox();
            this.button_continue = new System.Windows.Forms.Button();
            this.button_stoping0 = new System.Windows.Forms.Button();
            this.button_edit = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.GX0_position = new System.Windows.Forms.TextBox();
            this.PKMB0_position = new System.Windows.Forms.TextBox();
            this.GY0_position = new System.Windows.Forms.TextBox();
            this.PKMA0_position = new System.Windows.Forms.TextBox();
            this.GZ0_position = new System.Windows.Forms.TextBox();
            this.button_stoping = new System.Windows.Forms.Button();
            this.button_running = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.teached_point = new System.Windows.Forms.ComboBox();
            this.moveto = new System.Windows.Forms.Button();
            this.teaching = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.teaching_point = new System.Windows.Forms.ComboBox();
            this.groupBox_running = new System.Windows.Forms.GroupBox();
            this.label49 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button27 = new System.Windows.Forms.Button();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.PKMZ_position = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.label60 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.GX_position = new System.Windows.Forms.TextBox();
            this.PKMB_position = new System.Windows.Forms.TextBox();
            this.GY_position = new System.Windows.Forms.TextBox();
            this.PKMA_position = new System.Windows.Forms.TextBox();
            this.GZ_position = new System.Windows.Forms.TextBox();
            this.textBox_11 = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.textBox_10 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox_9 = new System.Windows.Forms.TextBox();
            this.textBox_1 = new System.Windows.Forms.TextBox();
            this.textBox_8 = new System.Windows.Forms.TextBox();
            this.textBox_2 = new System.Windows.Forms.TextBox();
            this.textBox_7 = new System.Windows.Forms.TextBox();
            this.textBox_3 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox_vel1 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox_4 = new System.Windows.Forms.TextBox();
            this.textBox_vel3 = new System.Windows.Forms.TextBox();
            this.textBox_pos5 = new System.Windows.Forms.TextBox();
            this.textBox_5 = new System.Windows.Forms.TextBox();
            this.textBox_pos4 = new System.Windows.Forms.TextBox();
            this.textBox_pos3 = new System.Windows.Forms.TextBox();
            this.textBox_pos2 = new System.Windows.Forms.TextBox();
            this.textBox_vel4 = new System.Windows.Forms.TextBox();
            this.textBox_pos1 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox_vel2 = new System.Windows.Forms.TextBox();
            this.textBox_vel5 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox_processing = new System.Windows.Forms.GroupBox();
            this.processing_speed_change = new System.Windows.Forms.NumericUpDown();
            this.label91 = new System.Windows.Forms.Label();
            this.progressBar_processing = new System.Windows.Forms.ProgressBar();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.picture_processing = new System.Windows.Forms.PictureBox();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox_pointcount = new System.Windows.Forms.TextBox();
            this.processing_speed = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox_pointnum = new System.Windows.Forms.TextBox();
            this.button_run = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.button_stop1 = new System.Windows.Forms.Button();
            this.button_stop0 = new System.Windows.Forms.Button();
            this.button_datainput = new System.Windows.Forms.Button();
            this.groupBox_zero = new System.Windows.Forms.GroupBox();
            this.limbY2 = new System.Windows.Forms.Button();
            this.limbX2 = new System.Windows.Forms.Button();
            this.limb32 = new System.Windows.Forms.Button();
            this.limb22 = new System.Windows.Forms.Button();
            this.limb12 = new System.Windows.Forms.Button();
            this.limbY1 = new System.Windows.Forms.Button();
            this.limbX1 = new System.Windows.Forms.Button();
            this.limb31 = new System.Windows.Forms.Button();
            this.limb21 = new System.Windows.Forms.Button();
            this.limb11 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label39 = new System.Windows.Forms.Label();
            this.confirm_zero = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox_tool = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.G0Y = new System.Windows.Forms.TextBox();
            this.G0Z = new System.Windows.Forms.TextBox();
            this.G0X = new System.Windows.Forms.TextBox();
            this.Zbutton = new System.Windows.Forms.Button();
            this.Ybutton = new System.Windows.Forms.Button();
            this.Xbutton = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.tool_change = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.value_rtool = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.value_tool = new System.Windows.Forms.TextBox();
            this.button_dimention = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button_spindle_stop = new System.Windows.Forms.Button();
            this.button_spindle_run = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox_dimention = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.value_d3max = new System.Windows.Forms.TextBox();
            this.value_d3min = new System.Windows.Forms.TextBox();
            this.value_d2max = new System.Windows.Forms.TextBox();
            this.value_d2min = new System.Windows.Forms.TextBox();
            this.value_d1max = new System.Windows.Forms.TextBox();
            this.value_d1min = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.value_S32max = new System.Windows.Forms.TextBox();
            this.value_S32min = new System.Windows.Forms.TextBox();
            this.value_U22max = new System.Windows.Forms.TextBox();
            this.value_U22min = new System.Windows.Forms.TextBox();
            this.value_U12max = new System.Windows.Forms.TextBox();
            this.value_U12min = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.value_S3max = new System.Windows.Forms.TextBox();
            this.value_S3min = new System.Windows.Forms.TextBox();
            this.value_U2max = new System.Windows.Forms.TextBox();
            this.value_U2min = new System.Windows.Forms.TextBox();
            this.value_U1max = new System.Windows.Forms.TextBox();
            this.value_U1min = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.value_R3max = new System.Windows.Forms.TextBox();
            this.value_R3min = new System.Windows.Forms.TextBox();
            this.value_R2max = new System.Windows.Forms.TextBox();
            this.value_R2min = new System.Windows.Forms.TextBox();
            this.value_R1max = new System.Windows.Forms.TextBox();
            this.value_R1min = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.value_b2 = new System.Windows.Forms.TextBox();
            this.value_b3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.value_b1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.value_a2 = new System.Windows.Forms.TextBox();
            this.value_a3 = new System.Windows.Forms.TextBox();
            this.value_a1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.lab_test = new System.Windows.Forms.Label();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t_dec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spindle_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_acc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.run_speed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start_speed)).BeginInit();
            this.groupBox_teach.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox_running.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox_processing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processing_speed_change)).BeginInit();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_processing)).BeginInit();
            this.groupBox_zero.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox_tool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox12.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox_dimention.SuspendLayout();
            this.SuspendLayout();
            // 
            // link_button
            // 
            this.link_button.Font = new System.Drawing.Font("宋体", 18F);
            this.link_button.Location = new System.Drawing.Point(16, 45);
            this.link_button.Margin = new System.Windows.Forms.Padding(4);
            this.link_button.Name = "link_button";
            this.link_button.Size = new System.Drawing.Size(188, 79);
            this.link_button.TabIndex = 3;
            this.link_button.Text = "连接控制器";
            this.link_button.UseVisualStyleBackColor = true;
            this.link_button.Click += new System.EventHandler(this.link_button_Click);
            // 
            // open_SF
            // 
            this.open_SF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.open_SF.Location = new System.Drawing.Point(8, 20);
            this.open_SF.Margin = new System.Windows.Forms.Padding(4);
            this.open_SF.Name = "open_SF";
            this.open_SF.Size = new System.Drawing.Size(113, 49);
            this.open_SF.TabIndex = 142;
            this.open_SF.Text = "打开伺服";
            this.open_SF.UseVisualStyleBackColor = true;
            this.open_SF.Click += new System.EventHandler(this.open_SF_Click);
            // 
            // close_SF
            // 
            this.close_SF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.close_SF.Location = new System.Drawing.Point(139, 20);
            this.close_SF.Margin = new System.Windows.Forms.Padding(4);
            this.close_SF.Name = "close_SF";
            this.close_SF.Size = new System.Drawing.Size(113, 49);
            this.close_SF.TabIndex = 141;
            this.close_SF.Text = "关闭伺服";
            this.close_SF.UseVisualStyleBackColor = true;
            this.close_SF.Click += new System.EventHandler(this.close_SF_Click);
            // 
            // calibration
            // 
            this.calibration.Font = new System.Drawing.Font("宋体", 18F);
            this.calibration.Location = new System.Drawing.Point(16, 250);
            this.calibration.Margin = new System.Windows.Forms.Padding(4);
            this.calibration.Name = "calibration";
            this.calibration.Size = new System.Drawing.Size(188, 79);
            this.calibration.TabIndex = 143;
            this.calibration.Text = "机器校零";
            this.calibration.UseVisualStyleBackColor = true;
            this.calibration.Click += new System.EventHandler(this.calibration_Click);
            // 
            // button_single
            // 
            this.button_single.Font = new System.Drawing.Font("宋体", 18F);
            this.button_single.Location = new System.Drawing.Point(16, 570);
            this.button_single.Margin = new System.Windows.Forms.Padding(4);
            this.button_single.Name = "button_single";
            this.button_single.Size = new System.Drawing.Size(188, 79);
            this.button_single.TabIndex = 144;
            this.button_single.Text = "示教功能";
            this.button_single.UseVisualStyleBackColor = true;
            this.button_single.Click += new System.EventHandler(this.button_single_Click);
            // 
            // Running_Status
            // 
            this.Running_Status.Font = new System.Drawing.Font("宋体", 18F);
            this.Running_Status.Location = new System.Drawing.Point(16, 675);
            this.Running_Status.Margin = new System.Windows.Forms.Padding(4);
            this.Running_Status.Name = "Running_Status";
            this.Running_Status.Size = new System.Drawing.Size(188, 79);
            this.Running_Status.TabIndex = 145;
            this.Running_Status.Text = "运行状态";
            this.Running_Status.UseVisualStyleBackColor = true;
            this.Running_Status.Click += new System.EventHandler(this.Running_Status_Click);
            // 
            // processing
            // 
            this.processing.Font = new System.Drawing.Font("宋体", 18F);
            this.processing.Location = new System.Drawing.Point(16, 460);
            this.processing.Margin = new System.Windows.Forms.Padding(4);
            this.processing.Name = "processing";
            this.processing.Size = new System.Drawing.Size(188, 79);
            this.processing.TabIndex = 146;
            this.processing.Text = "加工";
            this.processing.UseVisualStyleBackColor = true;
            this.processing.Click += new System.EventHandler(this.processing_Click);
            // 
            // Workpiece_system
            // 
            this.Workpiece_system.Font = new System.Drawing.Font("宋体", 18F);
            this.Workpiece_system.Location = new System.Drawing.Point(16, 355);
            this.Workpiece_system.Margin = new System.Windows.Forms.Padding(4);
            this.Workpiece_system.Name = "Workpiece_system";
            this.Workpiece_system.Size = new System.Drawing.Size(188, 79);
            this.Workpiece_system.TabIndex = 147;
            this.Workpiece_system.Text = "对刀";
            this.Workpiece_system.UseVisualStyleBackColor = true;
            this.Workpiece_system.Click += new System.EventHandler(this.Workpiece_system_Click);
            // 
            // clear_position_button
            // 
            this.clear_position_button.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.clear_position_button.Location = new System.Drawing.Point(273, 20);
            this.clear_position_button.Margin = new System.Windows.Forms.Padding(4);
            this.clear_position_button.Name = "clear_position_button";
            this.clear_position_button.Size = new System.Drawing.Size(113, 49);
            this.clear_position_button.TabIndex = 148;
            this.clear_position_button.Text = "机器回零";
            this.clear_position_button.UseVisualStyleBackColor = true;
            this.clear_position_button.Click += new System.EventHandler(this.clear_position_button_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(727, 414);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(192, 48);
            this.button1.TabIndex = 149;
            this.button1.Text = "前往工件原点";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(this.correct_forward);
            this.groupBox5.Controls.Add(this.close_handwheel);
            this.groupBox5.Controls.Add(this.open_handwheel);
            this.groupBox5.Controls.Add(this.button_change_speed);
            this.groupBox5.Controls.Add(this.check_move);
            this.groupBox5.Controls.Add(this.stop_button);
            this.groupBox5.Controls.Add(this.open_SF);
            this.groupBox5.Controls.Add(this.close_SF);
            this.groupBox5.Controls.Add(this.clear_position_button);
            this.groupBox5.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox5.Location = new System.Drawing.Point(244, 30);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1383, 76);
            this.groupBox5.TabIndex = 150;
            this.groupBox5.TabStop = false;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(971, 20);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(85, 49);
            this.button16.TabIndex = 155;
            this.button16.Text = "求解器";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // correct_forward
            // 
            this.correct_forward.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.correct_forward.Location = new System.Drawing.Point(840, 22);
            this.correct_forward.Margin = new System.Windows.Forms.Padding(4);
            this.correct_forward.Name = "correct_forward";
            this.correct_forward.Size = new System.Drawing.Size(123, 48);
            this.correct_forward.TabIndex = 154;
            this.correct_forward.Text = "正解验证";
            this.correct_forward.UseVisualStyleBackColor = true;
            this.correct_forward.Click += new System.EventHandler(this.correct_forward_Click);
            // 
            // close_handwheel
            // 
            this.close_handwheel.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.close_handwheel.Location = new System.Drawing.Point(547, 21);
            this.close_handwheel.Margin = new System.Windows.Forms.Padding(4);
            this.close_handwheel.Name = "close_handwheel";
            this.close_handwheel.Size = new System.Drawing.Size(123, 48);
            this.close_handwheel.TabIndex = 152;
            this.close_handwheel.Text = "关闭手轮";
            this.close_handwheel.UseVisualStyleBackColor = true;
            this.close_handwheel.Click += new System.EventHandler(this.close_handwheel_Click);
            // 
            // open_handwheel
            // 
            this.open_handwheel.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.open_handwheel.Location = new System.Drawing.Point(401, 20);
            this.open_handwheel.Margin = new System.Windows.Forms.Padding(4);
            this.open_handwheel.Name = "open_handwheel";
            this.open_handwheel.Size = new System.Drawing.Size(123, 48);
            this.open_handwheel.TabIndex = 72;
            this.open_handwheel.Text = "启用手轮";
            this.open_handwheel.UseVisualStyleBackColor = true;
            this.open_handwheel.Click += new System.EventHandler(this.open_handwheel_Click);
            // 
            // button_change_speed
            // 
            this.button_change_speed.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_change_speed.Location = new System.Drawing.Point(696, 22);
            this.button_change_speed.Margin = new System.Windows.Forms.Padding(4);
            this.button_change_speed.Name = "button_change_speed";
            this.button_change_speed.Size = new System.Drawing.Size(123, 48);
            this.button_change_speed.TabIndex = 39;
            this.button_change_speed.Text = "在线变速";
            this.button_change_speed.UseVisualStyleBackColor = true;
            this.button_change_speed.Click += new System.EventHandler(this.button_change_speed_Click);
            // 
            // check_move
            // 
            this.check_move.Enabled = false;
            this.check_move.Font = new System.Drawing.Font("宋体", 20F);
            this.check_move.ForeColor = System.Drawing.Color.Red;
            this.check_move.Location = new System.Drawing.Point(1198, 20);
            this.check_move.Margin = new System.Windows.Forms.Padding(4);
            this.check_move.Name = "check_move";
            this.check_move.Size = new System.Drawing.Size(169, 45);
            this.check_move.TabIndex = 151;
            this.check_move.Text = "空闲中";
            this.check_move.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // stop_button
            // 
            this.stop_button.BackColor = System.Drawing.Color.Red;
            this.stop_button.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.stop_button.ForeColor = System.Drawing.Color.Black;
            this.stop_button.Location = new System.Drawing.Point(1060, 15);
            this.stop_button.Margin = new System.Windows.Forms.Padding(4);
            this.stop_button.Name = "stop_button";
            this.stop_button.Size = new System.Drawing.Size(129, 56);
            this.stop_button.TabIndex = 150;
            this.stop_button.Text = "急  停";
            this.stop_button.UseVisualStyleBackColor = false;
            this.stop_button.Click += new System.EventHandler(this.stop_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.t_dec);
            this.groupBox2.Controls.Add(this.spindle_speed);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.t_acc);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.stop_speed);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.run_speed);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.start_speed);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(244, 141);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1383, 81);
            this.groupBox2.TabIndex = 151;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "运动参数设置(mm,rp,s)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(1151, 36);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 20);
            this.label10.TabIndex = 71;
            this.label10.Text = "主轴转速:";
            // 
            // t_dec
            // 
            this.t_dec.DecimalPlaces = 3;
            this.t_dec.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.t_dec.Location = new System.Drawing.Point(1024, 31);
            this.t_dec.Margin = new System.Windows.Forms.Padding(4);
            this.t_dec.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.t_dec.Name = "t_dec";
            this.t_dec.Size = new System.Drawing.Size(108, 30);
            this.t_dec.TabIndex = 1;
            this.t_dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_dec.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // spindle_speed
            // 
            this.spindle_speed.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.spindle_speed.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spindle_speed.Location = new System.Drawing.Point(1257, 32);
            this.spindle_speed.Margin = new System.Windows.Forms.Padding(4);
            this.spindle_speed.Maximum = new decimal(new int[] {
            12000,
            0,
            0,
            0});
            this.spindle_speed.Name = "spindle_speed";
            this.spindle_speed.Size = new System.Drawing.Size(108, 30);
            this.spindle_speed.TabIndex = 70;
            this.spindle_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.spindle_speed.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(923, 36);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "减速时间:";
            // 
            // t_acc
            // 
            this.t_acc.DecimalPlaces = 3;
            this.t_acc.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.t_acc.Location = new System.Drawing.Point(792, 31);
            this.t_acc.Margin = new System.Windows.Forms.Padding(4);
            this.t_acc.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.t_acc.Name = "t_acc";
            this.t_acc.Size = new System.Drawing.Size(108, 30);
            this.t_acc.TabIndex = 1;
            this.t_acc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.t_acc.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(691, 36);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "加速时间:";
            // 
            // stop_speed
            // 
            this.stop_speed.Location = new System.Drawing.Point(563, 31);
            this.stop_speed.Margin = new System.Windows.Forms.Padding(4);
            this.stop_speed.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.stop_speed.Name = "stop_speed";
            this.stop_speed.Size = new System.Drawing.Size(108, 30);
            this.stop_speed.TabIndex = 1;
            this.stop_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(461, 36);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "停止速度:";
            // 
            // run_speed
            // 
            this.run_speed.DecimalPlaces = 1;
            this.run_speed.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.run_speed.Location = new System.Drawing.Point(336, 31);
            this.run_speed.Margin = new System.Windows.Forms.Padding(4);
            this.run_speed.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.run_speed.Name = "run_speed";
            this.run_speed.Size = new System.Drawing.Size(108, 30);
            this.run_speed.TabIndex = 1;
            this.run_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.run_speed.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 36);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "运行速度:";
            // 
            // start_speed
            // 
            this.start_speed.DecimalPlaces = 1;
            this.start_speed.Location = new System.Drawing.Point(112, 31);
            this.start_speed.Margin = new System.Windows.Forms.Padding(4);
            this.start_speed.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            this.start_speed.Name = "start_speed";
            this.start_speed.Size = new System.Drawing.Size(108, 30);
            this.start_speed.TabIndex = 1;
            this.start_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.start_speed.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 36);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "起始速度:";
            // 
            // groupBox_teach
            // 
            this.groupBox_teach.Controls.Add(this.programming);
            this.groupBox_teach.Controls.Add(this.button_continue);
            this.groupBox_teach.Controls.Add(this.button_stoping0);
            this.groupBox_teach.Controls.Add(this.button_edit);
            this.groupBox_teach.Controls.Add(this.groupBox10);
            this.groupBox_teach.Controls.Add(this.button_stoping);
            this.groupBox_teach.Controls.Add(this.button_running);
            this.groupBox_teach.Controls.Add(this.label71);
            this.groupBox_teach.Controls.Add(this.teached_point);
            this.groupBox_teach.Controls.Add(this.moveto);
            this.groupBox_teach.Controls.Add(this.teaching);
            this.groupBox_teach.Controls.Add(this.label72);
            this.groupBox_teach.Controls.Add(this.teaching_point);
            this.groupBox_teach.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_teach.Location = new System.Drawing.Point(1434, 330);
            this.groupBox_teach.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_teach.Name = "groupBox_teach";
            this.groupBox_teach.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_teach.Size = new System.Drawing.Size(1115, 501);
            this.groupBox_teach.TabIndex = 167;
            this.groupBox_teach.TabStop = false;
            this.groupBox_teach.Text = "示教功能";
            // 
            // programming
            // 
            this.programming.Location = new System.Drawing.Point(431, 68);
            this.programming.Margin = new System.Windows.Forms.Padding(4);
            this.programming.Multiline = true;
            this.programming.Name = "programming";
            this.programming.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.programming.Size = new System.Drawing.Size(643, 413);
            this.programming.TabIndex = 167;
            // 
            // button_continue
            // 
            this.button_continue.Font = new System.Drawing.Font("宋体", 12F);
            this.button_continue.Location = new System.Drawing.Point(960, 22);
            this.button_continue.Margin = new System.Windows.Forms.Padding(4);
            this.button_continue.Name = "button_continue";
            this.button_continue.Size = new System.Drawing.Size(121, 35);
            this.button_continue.TabIndex = 148;
            this.button_continue.Text = "继续";
            this.button_continue.UseVisualStyleBackColor = true;
            this.button_continue.Click += new System.EventHandler(this.button_continue_Click);
            // 
            // button_stoping0
            // 
            this.button_stoping0.Font = new System.Drawing.Font("宋体", 12F);
            this.button_stoping0.Location = new System.Drawing.Point(827, 21);
            this.button_stoping0.Margin = new System.Windows.Forms.Padding(4);
            this.button_stoping0.Name = "button_stoping0";
            this.button_stoping0.Size = new System.Drawing.Size(121, 35);
            this.button_stoping0.TabIndex = 147;
            this.button_stoping0.Text = "暂停";
            this.button_stoping0.UseVisualStyleBackColor = true;
            this.button_stoping0.Click += new System.EventHandler(this.button_stoping0_Click);
            // 
            // button_edit
            // 
            this.button_edit.Font = new System.Drawing.Font("宋体", 12F);
            this.button_edit.Location = new System.Drawing.Point(429, 20);
            this.button_edit.Margin = new System.Windows.Forms.Padding(4);
            this.button_edit.Name = "button_edit";
            this.button_edit.Size = new System.Drawing.Size(121, 35);
            this.button_edit.TabIndex = 146;
            this.button_edit.Text = "编译";
            this.button_edit.UseVisualStyleBackColor = true;
            this.button_edit.Click += new System.EventHandler(this.button_edit_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button19);
            this.groupBox10.Controls.Add(this.button20);
            this.groupBox10.Controls.Add(this.label61);
            this.groupBox10.Controls.Add(this.label62);
            this.groupBox10.Controls.Add(this.label63);
            this.groupBox10.Controls.Add(this.label64);
            this.groupBox10.Controls.Add(this.label65);
            this.groupBox10.Controls.Add(this.label66);
            this.groupBox10.Controls.Add(this.label67);
            this.groupBox10.Controls.Add(this.label68);
            this.groupBox10.Controls.Add(this.label69);
            this.groupBox10.Controls.Add(this.textBox7);
            this.groupBox10.Controls.Add(this.label70);
            this.groupBox10.Controls.Add(this.GX0_position);
            this.groupBox10.Controls.Add(this.PKMB0_position);
            this.groupBox10.Controls.Add(this.GY0_position);
            this.groupBox10.Controls.Add(this.PKMA0_position);
            this.groupBox10.Controls.Add(this.GZ0_position);
            this.groupBox10.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox10.Location = new System.Drawing.Point(48, 178);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(321, 309);
            this.groupBox10.TabIndex = 145;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "姿态";
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("宋体", 12F);
            this.button19.Location = new System.Drawing.Point(35, 28);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(108, 35);
            this.button19.TabIndex = 113;
            this.button19.Text = "当前点位";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("宋体", 12F);
            this.button20.Location = new System.Drawing.Point(21, 120);
            this.button20.Margin = new System.Windows.Forms.Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(43, 136);
            this.button20.TabIndex = 115;
            this.button20.Text = "当前刀具位姿";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("宋体", 12F);
            this.label61.Location = new System.Drawing.Point(97, 88);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(29, 20);
            this.label61.TabIndex = 116;
            this.label61.Text = "X:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("宋体", 12F);
            this.label62.Location = new System.Drawing.Point(96, 132);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(29, 20);
            this.label62.TabIndex = 117;
            this.label62.Text = "Y:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label63.Location = new System.Drawing.Point(247, 269);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(26, 18);
            this.label63.TabIndex = 131;
            this.label63.Text = "°";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("宋体", 12F);
            this.label64.Location = new System.Drawing.Point(96, 176);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(29, 20);
            this.label64.TabIndex = 118;
            this.label64.Text = "Z:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label65.Location = new System.Drawing.Point(245, 228);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(26, 18);
            this.label65.TabIndex = 130;
            this.label65.Text = "°";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("宋体", 12F);
            this.label66.Location = new System.Drawing.Point(96, 221);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(29, 20);
            this.label66.TabIndex = 119;
            this.label66.Text = "A:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label67.Location = new System.Drawing.Point(247, 132);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(26, 18);
            this.label67.TabIndex = 129;
            this.label67.Text = "mm";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("宋体", 12F);
            this.label68.Location = new System.Drawing.Point(96, 265);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(29, 20);
            this.label68.TabIndex = 120;
            this.label68.Text = "B:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label69.Location = new System.Drawing.Point(247, 179);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(26, 18);
            this.label69.TabIndex = 128;
            this.label69.Text = "mm";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("宋体", 12F);
            this.textBox7.Location = new System.Drawing.Point(179, 30);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(111, 30);
            this.textBox7.TabIndex = 121;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label70.Location = new System.Drawing.Point(245, 90);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(26, 18);
            this.label70.TabIndex = 127;
            this.label70.Text = "mm";
            // 
            // GX0_position
            // 
            this.GX0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GX0_position.Location = new System.Drawing.Point(135, 82);
            this.GX0_position.Margin = new System.Windows.Forms.Padding(4);
            this.GX0_position.Name = "GX0_position";
            this.GX0_position.ReadOnly = true;
            this.GX0_position.Size = new System.Drawing.Size(99, 30);
            this.GX0_position.TabIndex = 122;
            this.GX0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMB0_position
            // 
            this.PKMB0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMB0_position.Location = new System.Drawing.Point(136, 260);
            this.PKMB0_position.Margin = new System.Windows.Forms.Padding(4);
            this.PKMB0_position.Name = "PKMB0_position";
            this.PKMB0_position.ReadOnly = true;
            this.PKMB0_position.Size = new System.Drawing.Size(99, 30);
            this.PKMB0_position.TabIndex = 126;
            this.PKMB0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GY0_position
            // 
            this.GY0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GY0_position.Location = new System.Drawing.Point(136, 126);
            this.GY0_position.Margin = new System.Windows.Forms.Padding(4);
            this.GY0_position.Name = "GY0_position";
            this.GY0_position.ReadOnly = true;
            this.GY0_position.Size = new System.Drawing.Size(99, 30);
            this.GY0_position.TabIndex = 123;
            this.GY0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMA0_position
            // 
            this.PKMA0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMA0_position.Location = new System.Drawing.Point(136, 216);
            this.PKMA0_position.Margin = new System.Windows.Forms.Padding(4);
            this.PKMA0_position.Name = "PKMA0_position";
            this.PKMA0_position.ReadOnly = true;
            this.PKMA0_position.Size = new System.Drawing.Size(99, 30);
            this.PKMA0_position.TabIndex = 125;
            this.PKMA0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GZ0_position
            // 
            this.GZ0_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GZ0_position.Location = new System.Drawing.Point(136, 171);
            this.GZ0_position.Margin = new System.Windows.Forms.Padding(4);
            this.GZ0_position.Name = "GZ0_position";
            this.GZ0_position.ReadOnly = true;
            this.GZ0_position.Size = new System.Drawing.Size(99, 30);
            this.GZ0_position.TabIndex = 124;
            this.GZ0_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_stoping
            // 
            this.button_stoping.Font = new System.Drawing.Font("宋体", 12F);
            this.button_stoping.Location = new System.Drawing.Point(692, 21);
            this.button_stoping.Margin = new System.Windows.Forms.Padding(4);
            this.button_stoping.Name = "button_stoping";
            this.button_stoping.Size = new System.Drawing.Size(121, 35);
            this.button_stoping.TabIndex = 144;
            this.button_stoping.Text = "停止";
            this.button_stoping.UseVisualStyleBackColor = true;
            this.button_stoping.Click += new System.EventHandler(this.button_stoping_Click);
            // 
            // button_running
            // 
            this.button_running.Font = new System.Drawing.Font("宋体", 12F);
            this.button_running.Location = new System.Drawing.Point(559, 20);
            this.button_running.Margin = new System.Windows.Forms.Padding(4);
            this.button_running.Name = "button_running";
            this.button_running.Size = new System.Drawing.Size(121, 35);
            this.button_running.TabIndex = 143;
            this.button_running.Text = "运行";
            this.button_running.UseVisualStyleBackColor = true;
            this.button_running.Click += new System.EventHandler(this.button_running_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("宋体", 12F);
            this.label71.Location = new System.Drawing.Point(28, 120);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(59, 20);
            this.label71.TabIndex = 142;
            this.label71.Text = "点位:";
            // 
            // teached_point
            // 
            this.teached_point.Font = new System.Drawing.Font("宋体", 12F);
            this.teached_point.FormattingEnabled = true;
            this.teached_point.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12",
            "P13",
            "P14",
            "P15",
            "P16",
            "P17",
            "P18",
            "P19",
            "P20",
            "P21",
            "P22",
            "P23",
            "P24",
            "P25",
            "P26",
            "P27",
            "P28",
            "P29",
            "P30",
            "P31",
            "P32",
            "P33",
            "P34",
            "P35",
            "P36",
            "P37",
            "P38",
            "P39",
            "P40",
            "P41",
            "P42",
            "P43",
            "P44",
            "P45",
            "P46",
            "P47",
            "P48",
            "P49",
            "P50",
            "P51",
            "P52",
            "P53",
            "P54",
            "P55",
            "P56",
            "P57",
            "P58",
            "P59",
            "P60",
            "P61",
            "P62",
            "P63",
            "P64",
            "P65",
            "P66",
            "P67",
            "P68",
            "P69",
            "P70",
            "P71",
            "P72",
            "P73",
            "P74",
            "P75",
            "P76",
            "P77",
            "P78",
            "P79",
            "P80",
            "P81",
            "P82",
            "P83",
            "P84",
            "P85",
            "P86",
            "P87",
            "P88",
            "P89",
            "P90",
            "P91",
            "P92",
            "P93",
            "P94",
            "P95",
            "P96",
            "P97",
            "P98",
            "P99",
            "P100"});
            this.teached_point.Location = new System.Drawing.Point(119, 114);
            this.teached_point.Margin = new System.Windows.Forms.Padding(4);
            this.teached_point.Name = "teached_point";
            this.teached_point.Size = new System.Drawing.Size(135, 28);
            this.teached_point.TabIndex = 141;
            // 
            // moveto
            // 
            this.moveto.Font = new System.Drawing.Font("宋体", 12F);
            this.moveto.Location = new System.Drawing.Point(264, 112);
            this.moveto.Margin = new System.Windows.Forms.Padding(4);
            this.moveto.Name = "moveto";
            this.moveto.Size = new System.Drawing.Size(121, 35);
            this.moveto.TabIndex = 140;
            this.moveto.Text = "前往";
            this.moveto.UseVisualStyleBackColor = true;
            this.moveto.Click += new System.EventHandler(this.moveto_Click);
            // 
            // teaching
            // 
            this.teaching.Font = new System.Drawing.Font("宋体", 12F);
            this.teaching.Location = new System.Drawing.Point(264, 46);
            this.teaching.Margin = new System.Windows.Forms.Padding(4);
            this.teaching.Name = "teaching";
            this.teaching.Size = new System.Drawing.Size(121, 35);
            this.teaching.TabIndex = 100;
            this.teaching.Text = "教导";
            this.teaching.UseVisualStyleBackColor = true;
            this.teaching.Click += new System.EventHandler(this.teaching_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("宋体", 12F);
            this.label72.Location = new System.Drawing.Point(8, 52);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(99, 20);
            this.label72.TabIndex = 99;
            this.label72.Text = "点位定义:";
            // 
            // teaching_point
            // 
            this.teaching_point.Font = new System.Drawing.Font("宋体", 12F);
            this.teaching_point.FormattingEnabled = true;
            this.teaching_point.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12",
            "P13",
            "P14",
            "P15",
            "P16",
            "P17",
            "P18",
            "P19",
            "P20",
            "P21",
            "P22",
            "P23",
            "P24",
            "P25",
            "P26",
            "P27",
            "P28",
            "P29",
            "P30",
            "P31",
            "P32",
            "P33",
            "P34",
            "P35",
            "P36",
            "P37",
            "P38",
            "P39",
            "P40",
            "P41",
            "P42",
            "P43",
            "P44",
            "P45",
            "P46",
            "P47",
            "P48",
            "P49",
            "P50",
            "P51",
            "P52",
            "P53",
            "P54",
            "P55",
            "P56",
            "P57",
            "P58",
            "P59",
            "P60",
            "P61",
            "P62",
            "P63",
            "P64",
            "P65",
            "P66",
            "P67",
            "P68",
            "P69",
            "P70",
            "P71",
            "P72",
            "P73",
            "P74",
            "P75",
            "P76",
            "P77",
            "P78",
            "P79",
            "P80",
            "P81",
            "P82",
            "P83",
            "P84",
            "P85",
            "P86",
            "P87",
            "P88",
            "P89",
            "P90",
            "P91",
            "P92",
            "P93",
            "P94",
            "P95",
            "P96",
            "P97",
            "P98",
            "P99",
            "P100"});
            this.teaching_point.Location = new System.Drawing.Point(119, 48);
            this.teaching_point.Margin = new System.Windows.Forms.Padding(4);
            this.teaching_point.Name = "teaching_point";
            this.teaching_point.Size = new System.Drawing.Size(135, 28);
            this.teaching_point.TabIndex = 98;
            // 
            // groupBox_running
            // 
            this.groupBox_running.Controls.Add(this.label49);
            this.groupBox_running.Controls.Add(this.groupBox11);
            this.groupBox_running.Controls.Add(this.textBox_11);
            this.groupBox_running.Controls.Add(this.button26);
            this.groupBox_running.Controls.Add(this.textBox_10);
            this.groupBox_running.Controls.Add(this.label57);
            this.groupBox_running.Controls.Add(this.textBox_9);
            this.groupBox_running.Controls.Add(this.textBox_1);
            this.groupBox_running.Controls.Add(this.textBox_8);
            this.groupBox_running.Controls.Add(this.textBox_2);
            this.groupBox_running.Controls.Add(this.textBox_7);
            this.groupBox_running.Controls.Add(this.textBox_3);
            this.groupBox_running.Controls.Add(this.button15);
            this.groupBox_running.Controls.Add(this.textBox_vel1);
            this.groupBox_running.Controls.Add(this.label50);
            this.groupBox_running.Controls.Add(this.textBox_4);
            this.groupBox_running.Controls.Add(this.textBox_vel3);
            this.groupBox_running.Controls.Add(this.textBox_pos5);
            this.groupBox_running.Controls.Add(this.textBox_5);
            this.groupBox_running.Controls.Add(this.textBox_pos4);
            this.groupBox_running.Controls.Add(this.textBox_pos3);
            this.groupBox_running.Controls.Add(this.textBox_pos2);
            this.groupBox_running.Controls.Add(this.textBox_vel4);
            this.groupBox_running.Controls.Add(this.textBox_pos1);
            this.groupBox_running.Controls.Add(this.label56);
            this.groupBox_running.Controls.Add(this.button13);
            this.groupBox_running.Controls.Add(this.label55);
            this.groupBox_running.Controls.Add(this.button25);
            this.groupBox_running.Controls.Add(this.label54);
            this.groupBox_running.Controls.Add(this.label53);
            this.groupBox_running.Controls.Add(this.textBox_vel2);
            this.groupBox_running.Controls.Add(this.textBox_vel5);
            this.groupBox_running.Controls.Add(this.label52);
            this.groupBox_running.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_running.Location = new System.Drawing.Point(428, 805);
            this.groupBox_running.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_running.Name = "groupBox_running";
            this.groupBox_running.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_running.Size = new System.Drawing.Size(1121, 501);
            this.groupBox_running.TabIndex = 166;
            this.groupBox_running.TabStop = false;
            this.groupBox_running.Text = "查看运行状态";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(432, 112);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(29, 20);
            this.label49.TabIndex = 68;
            this.label49.Text = "mm";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button27);
            this.groupBox11.Controls.Add(this.label58);
            this.groupBox11.Controls.Add(this.label59);
            this.groupBox11.Controls.Add(this.PKMZ_position);
            this.groupBox11.Controls.Add(this.button28);
            this.groupBox11.Controls.Add(this.label60);
            this.groupBox11.Controls.Add(this.label73);
            this.groupBox11.Controls.Add(this.label74);
            this.groupBox11.Controls.Add(this.label75);
            this.groupBox11.Controls.Add(this.label76);
            this.groupBox11.Controls.Add(this.label77);
            this.groupBox11.Controls.Add(this.label78);
            this.groupBox11.Controls.Add(this.label79);
            this.groupBox11.Controls.Add(this.label80);
            this.groupBox11.Controls.Add(this.label81);
            this.groupBox11.Controls.Add(this.GX_position);
            this.groupBox11.Controls.Add(this.PKMB_position);
            this.groupBox11.Controls.Add(this.GY_position);
            this.groupBox11.Controls.Add(this.PKMA_position);
            this.groupBox11.Controls.Add(this.GZ_position);
            this.groupBox11.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox11.Location = new System.Drawing.Point(732, 76);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(351, 355);
            this.groupBox11.TabIndex = 137;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "姿态";
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("宋体", 12F);
            this.button27.Location = new System.Drawing.Point(24, 202);
            this.button27.Margin = new System.Windows.Forms.Padding(4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(43, 115);
            this.button27.TabIndex = 135;
            this.button27.Text = "动平台姿态";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label58.Location = new System.Drawing.Point(292, 304);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(26, 18);
            this.label58.TabIndex = 134;
            this.label58.Text = "mm";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("宋体", 12F);
            this.label59.Location = new System.Drawing.Point(105, 302);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(29, 20);
            this.label59.TabIndex = 132;
            this.label59.Text = "Z:";
            // 
            // PKMZ_position
            // 
            this.PKMZ_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMZ_position.Location = new System.Drawing.Point(145, 298);
            this.PKMZ_position.Margin = new System.Windows.Forms.Padding(4);
            this.PKMZ_position.Name = "PKMZ_position";
            this.PKMZ_position.ReadOnly = true;
            this.PKMZ_position.Size = new System.Drawing.Size(136, 30);
            this.PKMZ_position.TabIndex = 133;
            this.PKMZ_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("宋体", 12F);
            this.button28.Location = new System.Drawing.Point(24, 45);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(43, 115);
            this.button28.TabIndex = 115;
            this.button28.Text = "刀尖位置";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("宋体", 12F);
            this.label60.Location = new System.Drawing.Point(97, 36);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(39, 20);
            this.label60.TabIndex = 116;
            this.label60.Text = "GX:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("宋体", 12F);
            this.label73.Location = new System.Drawing.Point(96, 88);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(39, 20);
            this.label73.TabIndex = 117;
            this.label73.Text = "GY:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label74.Location = new System.Drawing.Point(292, 254);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(26, 18);
            this.label74.TabIndex = 131;
            this.label74.Text = "°";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("宋体", 12F);
            this.label75.Location = new System.Drawing.Point(96, 138);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(39, 20);
            this.label75.TabIndex = 118;
            this.label75.Text = "GZ:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label76.Location = new System.Drawing.Point(291, 206);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(26, 18);
            this.label76.TabIndex = 130;
            this.label76.Text = "°";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("宋体", 12F);
            this.label77.Location = new System.Drawing.Point(105, 202);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(29, 20);
            this.label77.TabIndex = 119;
            this.label77.Text = "A:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label78.Location = new System.Drawing.Point(292, 88);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(26, 18);
            this.label78.TabIndex = 129;
            this.label78.Text = "mm";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("宋体", 12F);
            this.label79.Location = new System.Drawing.Point(105, 252);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 20);
            this.label79.TabIndex = 120;
            this.label79.Text = "B:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label80.Location = new System.Drawing.Point(292, 140);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(26, 18);
            this.label80.TabIndex = 128;
            this.label80.Text = "mm";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("宋体", 10.5F);
            this.label81.Location = new System.Drawing.Point(291, 39);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(26, 18);
            this.label81.TabIndex = 127;
            this.label81.Text = "mm";
            // 
            // GX_position
            // 
            this.GX_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GX_position.Location = new System.Drawing.Point(144, 31);
            this.GX_position.Margin = new System.Windows.Forms.Padding(4);
            this.GX_position.Name = "GX_position";
            this.GX_position.ReadOnly = true;
            this.GX_position.Size = new System.Drawing.Size(137, 30);
            this.GX_position.TabIndex = 122;
            this.GX_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMB_position
            // 
            this.PKMB_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMB_position.Location = new System.Drawing.Point(145, 248);
            this.PKMB_position.Margin = new System.Windows.Forms.Padding(4);
            this.PKMB_position.Name = "PKMB_position";
            this.PKMB_position.ReadOnly = true;
            this.PKMB_position.Size = new System.Drawing.Size(136, 30);
            this.PKMB_position.TabIndex = 126;
            this.PKMB_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GY_position
            // 
            this.GY_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GY_position.Location = new System.Drawing.Point(145, 81);
            this.GY_position.Margin = new System.Windows.Forms.Padding(4);
            this.GY_position.Name = "GY_position";
            this.GY_position.ReadOnly = true;
            this.GY_position.Size = new System.Drawing.Size(136, 30);
            this.GY_position.TabIndex = 123;
            this.GY_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PKMA_position
            // 
            this.PKMA_position.Font = new System.Drawing.Font("宋体", 12F);
            this.PKMA_position.Location = new System.Drawing.Point(145, 198);
            this.PKMA_position.Margin = new System.Windows.Forms.Padding(4);
            this.PKMA_position.Name = "PKMA_position";
            this.PKMA_position.ReadOnly = true;
            this.PKMA_position.Size = new System.Drawing.Size(136, 30);
            this.PKMA_position.TabIndex = 125;
            this.PKMA_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GZ_position
            // 
            this.GZ_position.Font = new System.Drawing.Font("宋体", 12F);
            this.GZ_position.Location = new System.Drawing.Point(145, 132);
            this.GZ_position.Margin = new System.Windows.Forms.Padding(4);
            this.GZ_position.Name = "GZ_position";
            this.GZ_position.ReadOnly = true;
            this.GZ_position.Size = new System.Drawing.Size(136, 30);
            this.GZ_position.TabIndex = 124;
            this.GZ_position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_11
            // 
            this.textBox_11.Location = new System.Drawing.Point(541, 400);
            this.textBox_11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_11.Name = "textBox_11";
            this.textBox_11.ReadOnly = true;
            this.textBox_11.Size = new System.Drawing.Size(132, 30);
            this.textBox_11.TabIndex = 66;
            this.textBox_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button26.Location = new System.Drawing.Point(91, 74);
            this.button26.Margin = new System.Windows.Forms.Padding(4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(112, 36);
            this.button26.TabIndex = 51;
            this.button26.Text = "运行状态";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // textBox_10
            // 
            this.textBox_10.Location = new System.Drawing.Point(541, 336);
            this.textBox_10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_10.Name = "textBox_10";
            this.textBox_10.ReadOnly = true;
            this.textBox_10.Size = new System.Drawing.Size(132, 30);
            this.textBox_10.TabIndex = 65;
            this.textBox_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(268, 115);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(49, 20);
            this.label57.TabIndex = 0;
            this.label57.Text = "mm/s";
            // 
            // textBox_9
            // 
            this.textBox_9.Location = new System.Drawing.Point(541, 279);
            this.textBox_9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_9.Name = "textBox_9";
            this.textBox_9.ReadOnly = true;
            this.textBox_9.Size = new System.Drawing.Size(132, 30);
            this.textBox_9.TabIndex = 64;
            this.textBox_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_1
            // 
            this.textBox_1.Location = new System.Drawing.Point(91, 154);
            this.textBox_1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_1.Name = "textBox_1";
            this.textBox_1.ReadOnly = true;
            this.textBox_1.Size = new System.Drawing.Size(111, 30);
            this.textBox_1.TabIndex = 39;
            this.textBox_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_8
            // 
            this.textBox_8.Location = new System.Drawing.Point(541, 218);
            this.textBox_8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_8.Name = "textBox_8";
            this.textBox_8.ReadOnly = true;
            this.textBox_8.Size = new System.Drawing.Size(132, 30);
            this.textBox_8.TabIndex = 63;
            this.textBox_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_2
            // 
            this.textBox_2.Location = new System.Drawing.Point(91, 216);
            this.textBox_2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_2.Name = "textBox_2";
            this.textBox_2.ReadOnly = true;
            this.textBox_2.Size = new System.Drawing.Size(111, 30);
            this.textBox_2.TabIndex = 40;
            this.textBox_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_7
            // 
            this.textBox_7.Location = new System.Drawing.Point(541, 155);
            this.textBox_7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_7.Name = "textBox_7";
            this.textBox_7.ReadOnly = true;
            this.textBox_7.Size = new System.Drawing.Size(132, 30);
            this.textBox_7.TabIndex = 62;
            this.textBox_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_3
            // 
            this.textBox_3.Location = new System.Drawing.Point(91, 276);
            this.textBox_3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_3.Name = "textBox_3";
            this.textBox_3.ReadOnly = true;
            this.textBox_3.Size = new System.Drawing.Size(111, 30);
            this.textBox_3.TabIndex = 41;
            this.textBox_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(540, 72);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(147, 34);
            this.button15.TabIndex = 61;
            this.button15.Text = "当前编码器位置";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // textBox_vel1
            // 
            this.textBox_vel1.Location = new System.Drawing.Point(231, 154);
            this.textBox_vel1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_vel1.Name = "textBox_vel1";
            this.textBox_vel1.ReadOnly = true;
            this.textBox_vel1.Size = new System.Drawing.Size(133, 30);
            this.textBox_vel1.TabIndex = 1;
            this.textBox_vel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(591, 118);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(29, 20);
            this.label50.TabIndex = 60;
            this.label50.Text = "mm";
            // 
            // textBox_4
            // 
            this.textBox_4.Location = new System.Drawing.Point(91, 335);
            this.textBox_4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_4.Name = "textBox_4";
            this.textBox_4.ReadOnly = true;
            this.textBox_4.Size = new System.Drawing.Size(111, 30);
            this.textBox_4.TabIndex = 42;
            this.textBox_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_vel3
            // 
            this.textBox_vel3.Location = new System.Drawing.Point(231, 278);
            this.textBox_vel3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_vel3.Name = "textBox_vel3";
            this.textBox_vel3.ReadOnly = true;
            this.textBox_vel3.Size = new System.Drawing.Size(133, 30);
            this.textBox_vel3.TabIndex = 1;
            this.textBox_vel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_pos5
            // 
            this.textBox_pos5.Location = new System.Drawing.Point(384, 399);
            this.textBox_pos5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pos5.Name = "textBox_pos5";
            this.textBox_pos5.ReadOnly = true;
            this.textBox_pos5.Size = new System.Drawing.Size(135, 30);
            this.textBox_pos5.TabIndex = 58;
            this.textBox_pos5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_5
            // 
            this.textBox_5.Location = new System.Drawing.Point(91, 399);
            this.textBox_5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_5.Name = "textBox_5";
            this.textBox_5.ReadOnly = true;
            this.textBox_5.Size = new System.Drawing.Size(111, 30);
            this.textBox_5.TabIndex = 43;
            this.textBox_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_pos4
            // 
            this.textBox_pos4.Location = new System.Drawing.Point(384, 335);
            this.textBox_pos4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pos4.Name = "textBox_pos4";
            this.textBox_pos4.ReadOnly = true;
            this.textBox_pos4.Size = new System.Drawing.Size(135, 30);
            this.textBox_pos4.TabIndex = 57;
            this.textBox_pos4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_pos3
            // 
            this.textBox_pos3.Location = new System.Drawing.Point(384, 278);
            this.textBox_pos3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pos3.Name = "textBox_pos3";
            this.textBox_pos3.ReadOnly = true;
            this.textBox_pos3.Size = new System.Drawing.Size(135, 30);
            this.textBox_pos3.TabIndex = 56;
            this.textBox_pos3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_pos2
            // 
            this.textBox_pos2.Location = new System.Drawing.Point(384, 216);
            this.textBox_pos2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pos2.Name = "textBox_pos2";
            this.textBox_pos2.ReadOnly = true;
            this.textBox_pos2.Size = new System.Drawing.Size(135, 30);
            this.textBox_pos2.TabIndex = 55;
            this.textBox_pos2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_vel4
            // 
            this.textBox_vel4.Location = new System.Drawing.Point(231, 335);
            this.textBox_vel4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_vel4.Name = "textBox_vel4";
            this.textBox_vel4.ReadOnly = true;
            this.textBox_vel4.Size = new System.Drawing.Size(133, 30);
            this.textBox_vel4.TabIndex = 1;
            this.textBox_vel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_pos1
            // 
            this.textBox_pos1.Location = new System.Drawing.Point(384, 154);
            this.textBox_pos1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pos1.Name = "textBox_pos1";
            this.textBox_pos1.ReadOnly = true;
            this.textBox_pos1.Size = new System.Drawing.Size(135, 30);
            this.textBox_pos1.TabIndex = 54;
            this.textBox_pos1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("宋体", 12F);
            this.label56.Location = new System.Drawing.Point(32, 154);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(49, 20);
            this.label56.TabIndex = 45;
            this.label56.Text = "轴1:";
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(384, 72);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(136, 34);
            this.button13.TabIndex = 53;
            this.button13.Text = "当前指令位置";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("宋体", 12F);
            this.label55.Location = new System.Drawing.Point(31, 219);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(49, 20);
            this.label55.TabIndex = 46;
            this.label55.Text = "轴2:";
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button25.Location = new System.Drawing.Point(231, 72);
            this.button25.Margin = new System.Windows.Forms.Padding(4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(135, 35);
            this.button25.TabIndex = 52;
            this.button25.Text = "当前运行速度";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("宋体", 12F);
            this.label54.Location = new System.Drawing.Point(31, 281);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(49, 20);
            this.label54.TabIndex = 47;
            this.label54.Text = "轴3:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("宋体", 12F);
            this.label53.Location = new System.Drawing.Point(32, 339);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(49, 20);
            this.label53.TabIndex = 48;
            this.label53.Text = "轴4:";
            // 
            // textBox_vel2
            // 
            this.textBox_vel2.Location = new System.Drawing.Point(231, 216);
            this.textBox_vel2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_vel2.Name = "textBox_vel2";
            this.textBox_vel2.ReadOnly = true;
            this.textBox_vel2.Size = new System.Drawing.Size(133, 30);
            this.textBox_vel2.TabIndex = 1;
            this.textBox_vel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_vel5
            // 
            this.textBox_vel5.Location = new System.Drawing.Point(231, 399);
            this.textBox_vel5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_vel5.Name = "textBox_vel5";
            this.textBox_vel5.ReadOnly = true;
            this.textBox_vel5.Size = new System.Drawing.Size(133, 30);
            this.textBox_vel5.TabIndex = 1;
            this.textBox_vel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("宋体", 12F);
            this.label52.Location = new System.Drawing.Point(31, 401);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(49, 20);
            this.label52.TabIndex = 49;
            this.label52.Text = "轴5:";
            // 
            // groupBox_processing
            // 
            this.groupBox_processing.Controls.Add(this.processing_speed_change);
            this.groupBox_processing.Controls.Add(this.label91);
            this.groupBox_processing.Controls.Add(this.progressBar_processing);
            this.groupBox_processing.Controls.Add(this.groupBox15);
            this.groupBox_processing.Controls.Add(this.label90);
            this.groupBox_processing.Controls.Add(this.textBox_pointcount);
            this.groupBox_processing.Controls.Add(this.processing_speed);
            this.groupBox_processing.Controls.Add(this.label88);
            this.groupBox_processing.Controls.Add(this.textBox_pointnum);
            this.groupBox_processing.Controls.Add(this.button_run);
            this.groupBox_processing.Controls.Add(this.label89);
            this.groupBox_processing.Controls.Add(this.button_stop1);
            this.groupBox_processing.Controls.Add(this.button_stop0);
            this.groupBox_processing.Controls.Add(this.button_datainput);
            this.groupBox_processing.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_processing.Location = new System.Drawing.Point(802, 727);
            this.groupBox_processing.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_processing.Name = "groupBox_processing";
            this.groupBox_processing.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_processing.Size = new System.Drawing.Size(1115, 501);
            this.groupBox_processing.TabIndex = 175;
            this.groupBox_processing.TabStop = false;
            this.groupBox_processing.Text = "加工";
            // 
            // processing_speed_change
            // 
            this.processing_speed_change.DecimalPlaces = 1;
            this.processing_speed_change.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.processing_speed_change.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.processing_speed_change.Location = new System.Drawing.Point(905, 422);
            this.processing_speed_change.Margin = new System.Windows.Forms.Padding(4);
            this.processing_speed_change.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.processing_speed_change.Name = "processing_speed_change";
            this.processing_speed_change.Size = new System.Drawing.Size(123, 30);
            this.processing_speed_change.TabIndex = 72;
            this.processing_speed_change.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.processing_speed_change.Value = new decimal(new int[] {
            10,
            0,
            0,
            65536});
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("宋体", 14F);
            this.label91.Location = new System.Drawing.Point(760, 34);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(118, 24);
            this.label91.TabIndex = 45;
            this.label91.Text = "当前进度:";
            // 
            // progressBar_processing
            // 
            this.progressBar_processing.Location = new System.Drawing.Point(895, 30);
            this.progressBar_processing.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar_processing.Name = "progressBar_processing";
            this.progressBar_processing.Size = new System.Drawing.Size(201, 29);
            this.progressBar_processing.TabIndex = 44;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.picture_processing);
            this.groupBox15.Location = new System.Drawing.Point(31, 31);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(621, 459);
            this.groupBox15.TabIndex = 43;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "加工路径显示(XY)";
            // 
            // picture_processing
            // 
            this.picture_processing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picture_processing.Location = new System.Drawing.Point(11, 19);
            this.picture_processing.Margin = new System.Windows.Forms.Padding(4);
            this.picture_processing.Name = "picture_processing";
            this.picture_processing.Size = new System.Drawing.Size(600, 438);
            this.picture_processing.TabIndex = 0;
            this.picture_processing.TabStop = false;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("宋体", 14F);
            this.label90.Location = new System.Drawing.Point(1031, 421);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(34, 24);
            this.label90.TabIndex = 42;
            this.label90.Text = "倍";
            // 
            // textBox_pointcount
            // 
            this.textBox_pointcount.Enabled = false;
            this.textBox_pointcount.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_pointcount.Location = new System.Drawing.Point(899, 74);
            this.textBox_pointcount.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pointcount.Name = "textBox_pointcount";
            this.textBox_pointcount.Size = new System.Drawing.Size(155, 34);
            this.textBox_pointcount.TabIndex = 16;
            this.textBox_pointcount.Text = "Not Runing";
            // 
            // processing_speed
            // 
            this.processing_speed.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.processing_speed.Location = new System.Drawing.Point(711, 400);
            this.processing_speed.Margin = new System.Windows.Forms.Padding(4);
            this.processing_speed.Name = "processing_speed";
            this.processing_speed.Size = new System.Drawing.Size(171, 69);
            this.processing_speed.TabIndex = 40;
            this.processing_speed.Text = "加工速度调整";
            this.processing_speed.UseVisualStyleBackColor = true;
            this.processing_speed.Click += new System.EventHandler(this.processing_speed_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("宋体", 14F);
            this.label88.Location = new System.Drawing.Point(719, 131);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(166, 24);
            this.label88.TabIndex = 15;
            this.label88.Text = "路径总节点数:";
            // 
            // textBox_pointnum
            // 
            this.textBox_pointnum.Enabled = false;
            this.textBox_pointnum.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox_pointnum.Location = new System.Drawing.Point(900, 129);
            this.textBox_pointnum.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pointnum.Name = "textBox_pointnum";
            this.textBox_pointnum.Size = new System.Drawing.Size(156, 34);
            this.textBox_pointnum.TabIndex = 13;
            this.textBox_pointnum.Text = "Waiting";
            // 
            // button_run
            // 
            this.button_run.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_run.Font = new System.Drawing.Font("宋体", 12F);
            this.button_run.Location = new System.Drawing.Point(905, 191);
            this.button_run.Margin = new System.Windows.Forms.Padding(4);
            this.button_run.Name = "button_run";
            this.button_run.Size = new System.Drawing.Size(171, 69);
            this.button_run.TabIndex = 41;
            this.button_run.Text = "开始加工";
            this.button_run.UseVisualStyleBackColor = true;
            this.button_run.Click += new System.EventHandler(this.button_run_Click);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("宋体", 14F);
            this.label89.Location = new System.Drawing.Point(739, 76);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(142, 24);
            this.label89.TabIndex = 11;
            this.label89.Text = "当前节点数:";
            // 
            // button_stop1
            // 
            this.button_stop1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_stop1.Location = new System.Drawing.Point(909, 292);
            this.button_stop1.Margin = new System.Windows.Forms.Padding(4);
            this.button_stop1.Name = "button_stop1";
            this.button_stop1.Size = new System.Drawing.Size(171, 69);
            this.button_stop1.TabIndex = 37;
            this.button_stop1.Text = "停止加工";
            this.button_stop1.UseVisualStyleBackColor = true;
            this.button_stop1.Click += new System.EventHandler(this.button_stop1_Click);
            // 
            // button_stop0
            // 
            this.button_stop0.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_stop0.Location = new System.Drawing.Point(711, 292);
            this.button_stop0.Margin = new System.Windows.Forms.Padding(4);
            this.button_stop0.Name = "button_stop0";
            this.button_stop0.Size = new System.Drawing.Size(175, 69);
            this.button_stop0.TabIndex = 38;
            this.button_stop0.Text = "暂停加工";
            this.button_stop0.UseVisualStyleBackColor = true;
            this.button_stop0.Click += new System.EventHandler(this.button_stop0_Click);
            // 
            // button_datainput
            // 
            this.button_datainput.Location = new System.Drawing.Point(713, 191);
            this.button_datainput.Margin = new System.Windows.Forms.Padding(4);
            this.button_datainput.Name = "button_datainput";
            this.button_datainput.Size = new System.Drawing.Size(172, 69);
            this.button_datainput.TabIndex = 14;
            this.button_datainput.Text = "导入加工路径";
            this.button_datainput.UseVisualStyleBackColor = true;
            this.button_datainput.Click += new System.EventHandler(this.button_datainput_Click);
            // 
            // groupBox_zero
            // 
            this.groupBox_zero.Controls.Add(this.limbY2);
            this.groupBox_zero.Controls.Add(this.limbX2);
            this.groupBox_zero.Controls.Add(this.limb32);
            this.groupBox_zero.Controls.Add(this.limb22);
            this.groupBox_zero.Controls.Add(this.limb12);
            this.groupBox_zero.Controls.Add(this.limbY1);
            this.groupBox_zero.Controls.Add(this.limbX1);
            this.groupBox_zero.Controls.Add(this.limb31);
            this.groupBox_zero.Controls.Add(this.limb21);
            this.groupBox_zero.Controls.Add(this.limb11);
            this.groupBox_zero.Controls.Add(this.pictureBox2);
            this.groupBox_zero.Controls.Add(this.label39);
            this.groupBox_zero.Controls.Add(this.confirm_zero);
            this.groupBox_zero.Controls.Add(this.label30);
            this.groupBox_zero.Controls.Add(this.label31);
            this.groupBox_zero.Controls.Add(this.textBox4);
            this.groupBox_zero.Controls.Add(this.label38);
            this.groupBox_zero.Controls.Add(this.textBox5);
            this.groupBox_zero.Controls.Add(this.label23);
            this.groupBox_zero.Controls.Add(this.label22);
            this.groupBox_zero.Controls.Add(this.textBox3);
            this.groupBox_zero.Controls.Add(this.label21);
            this.groupBox_zero.Controls.Add(this.textBox2);
            this.groupBox_zero.Controls.Add(this.label20);
            this.groupBox_zero.Controls.Add(this.textBox1);
            this.groupBox_zero.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_zero.Location = new System.Drawing.Point(223, 235);
            this.groupBox_zero.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_zero.Name = "groupBox_zero";
            this.groupBox_zero.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_zero.Size = new System.Drawing.Size(1115, 501);
            this.groupBox_zero.TabIndex = 155;
            this.groupBox_zero.TabStop = false;
            this.groupBox_zero.Text = "机床校零";
            // 
            // limbY2
            // 
            this.limbY2.Font = new System.Drawing.Font("宋体", 14F);
            this.limbY2.Location = new System.Drawing.Point(1008, 418);
            this.limbY2.Margin = new System.Windows.Forms.Padding(4);
            this.limbY2.Name = "limbY2";
            this.limbY2.Size = new System.Drawing.Size(84, 49);
            this.limbY2.TabIndex = 178;
            this.limbY2.Text = "轴Y-";
            this.limbY2.UseVisualStyleBackColor = true;
            this.limbY2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limbY2_MouseDown);
            this.limbY2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limbY2_MouseUp);
            // 
            // limbX2
            // 
            this.limbX2.Font = new System.Drawing.Font("宋体", 14F);
            this.limbX2.Location = new System.Drawing.Point(903, 420);
            this.limbX2.Margin = new System.Windows.Forms.Padding(4);
            this.limbX2.Name = "limbX2";
            this.limbX2.Size = new System.Drawing.Size(84, 49);
            this.limbX2.TabIndex = 177;
            this.limbX2.Text = "轴X-";
            this.limbX2.UseVisualStyleBackColor = true;
            this.limbX2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limbX2_MouseDown);
            this.limbX2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limbX2_MouseUp);
            // 
            // limb32
            // 
            this.limb32.Font = new System.Drawing.Font("宋体", 14F);
            this.limb32.Location = new System.Drawing.Point(799, 421);
            this.limb32.Margin = new System.Windows.Forms.Padding(4);
            this.limb32.Name = "limb32";
            this.limb32.Size = new System.Drawing.Size(84, 49);
            this.limb32.TabIndex = 176;
            this.limb32.Text = "轴3-";
            this.limb32.UseVisualStyleBackColor = true;
            this.limb32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb32_MouseDown);
            this.limb32.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb32_MouseUp);
            // 
            // limb22
            // 
            this.limb22.Font = new System.Drawing.Font("宋体", 14F);
            this.limb22.Location = new System.Drawing.Point(692, 424);
            this.limb22.Margin = new System.Windows.Forms.Padding(4);
            this.limb22.Name = "limb22";
            this.limb22.Size = new System.Drawing.Size(84, 49);
            this.limb22.TabIndex = 175;
            this.limb22.Text = "轴2-";
            this.limb22.UseVisualStyleBackColor = true;
            this.limb22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb22_MouseDown);
            this.limb22.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb22_MouseUp);
            // 
            // limb12
            // 
            this.limb12.Font = new System.Drawing.Font("宋体", 14F);
            this.limb12.Location = new System.Drawing.Point(589, 424);
            this.limb12.Margin = new System.Windows.Forms.Padding(4);
            this.limb12.Name = "limb12";
            this.limb12.Size = new System.Drawing.Size(84, 49);
            this.limb12.TabIndex = 174;
            this.limb12.Text = "轴1-";
            this.limb12.UseVisualStyleBackColor = true;
            this.limb12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb12_MouseDown);
            this.limb12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb12_MouseUp);
            // 
            // limbY1
            // 
            this.limbY1.Font = new System.Drawing.Font("宋体", 14F);
            this.limbY1.Location = new System.Drawing.Point(1008, 351);
            this.limbY1.Margin = new System.Windows.Forms.Padding(4);
            this.limbY1.Name = "limbY1";
            this.limbY1.Size = new System.Drawing.Size(84, 49);
            this.limbY1.TabIndex = 173;
            this.limbY1.Text = "轴Y+";
            this.limbY1.UseVisualStyleBackColor = true;
            this.limbY1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limbY1_MouseDown);
            this.limbY1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limbY1_MouseUp);
            // 
            // limbX1
            // 
            this.limbX1.Font = new System.Drawing.Font("宋体", 14F);
            this.limbX1.Location = new System.Drawing.Point(903, 354);
            this.limbX1.Margin = new System.Windows.Forms.Padding(4);
            this.limbX1.Name = "limbX1";
            this.limbX1.Size = new System.Drawing.Size(84, 49);
            this.limbX1.TabIndex = 172;
            this.limbX1.Text = "轴X+";
            this.limbX1.UseVisualStyleBackColor = true;
            this.limbX1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limbX1_MouseDown);
            this.limbX1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limbX1_MouseUp);
            // 
            // limb31
            // 
            this.limb31.Font = new System.Drawing.Font("宋体", 14F);
            this.limb31.Location = new System.Drawing.Point(799, 355);
            this.limb31.Margin = new System.Windows.Forms.Padding(4);
            this.limb31.Name = "limb31";
            this.limb31.Size = new System.Drawing.Size(84, 49);
            this.limb31.TabIndex = 171;
            this.limb31.Text = "轴3+";
            this.limb31.UseVisualStyleBackColor = true;
            this.limb31.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb31_MouseDown);
            this.limb31.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb31_MouseUp);
            // 
            // limb21
            // 
            this.limb21.Font = new System.Drawing.Font("宋体", 14F);
            this.limb21.Location = new System.Drawing.Point(692, 358);
            this.limb21.Margin = new System.Windows.Forms.Padding(4);
            this.limb21.Name = "limb21";
            this.limb21.Size = new System.Drawing.Size(84, 49);
            this.limb21.TabIndex = 170;
            this.limb21.Text = "轴2+";
            this.limb21.UseVisualStyleBackColor = true;
            this.limb21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb21_MouseDown);
            this.limb21.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb21_MouseUp);
            // 
            // limb11
            // 
            this.limb11.Font = new System.Drawing.Font("宋体", 14F);
            this.limb11.Location = new System.Drawing.Point(589, 358);
            this.limb11.Margin = new System.Windows.Forms.Padding(4);
            this.limb11.Name = "limb11";
            this.limb11.Size = new System.Drawing.Size(84, 49);
            this.limb11.TabIndex = 169;
            this.limb11.Text = "轴1+";
            this.limb11.UseVisualStyleBackColor = true;
            this.limb11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.limb11_MouseDown);
            this.limb11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.limb11_MouseUp);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(36, 39);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(533, 450);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 168;
            this.pictureBox2.TabStop = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 16F);
            this.label39.Location = new System.Drawing.Point(697, 39);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 27);
            this.label39.TabIndex = 165;
            this.label39.Text = "机械原点";
            // 
            // confirm_zero
            // 
            this.confirm_zero.Font = new System.Drawing.Font("宋体", 14F);
            this.confirm_zero.Location = new System.Drawing.Point(976, 158);
            this.confirm_zero.Margin = new System.Windows.Forms.Padding(4);
            this.confirm_zero.Name = "confirm_zero";
            this.confirm_zero.Size = new System.Drawing.Size(117, 115);
            this.confirm_zero.TabIndex = 164;
            this.confirm_zero.Text = "确认到达机械原点";
            this.confirm_zero.UseVisualStyleBackColor = true;
            this.confirm_zero.Click += new System.EventHandler(this.confirm_zero_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("宋体", 16F);
            this.label30.Location = new System.Drawing.Point(793, 80);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(148, 27);
            this.label30.TabIndex = 163;
            this.label30.Text = "XY平台位置";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 14F);
            this.label31.Location = new System.Drawing.Point(793, 211);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(34, 24);
            this.label31.TabIndex = 162;
            this.label31.Text = "Y:";
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(847, 210);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(112, 34);
            this.textBox4.TabIndex = 161;
            this.textBox4.Text = "0";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 14F);
            this.label38.Location = new System.Drawing.Point(793, 146);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(34, 24);
            this.label38.TabIndex = 160;
            this.label38.Text = "X:";
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox5.ForeColor = System.Drawing.Color.Black;
            this.textBox5.Location = new System.Drawing.Point(847, 145);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(112, 34);
            this.textBox5.TabIndex = 159;
            this.textBox5.Text = "0";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 16F);
            this.label23.Location = new System.Drawing.Point(608, 80);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(147, 27);
            this.label23.TabIndex = 158;
            this.label23.Text = "动平台姿态";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 14F);
            this.label22.Location = new System.Drawing.Point(608, 279);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 24);
            this.label22.TabIndex = 157;
            this.label22.Text = "Z:";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            this.textBox3.Location = new System.Drawing.Point(661, 276);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(112, 34);
            this.textBox3.TabIndex = 156;
            this.textBox3.Text = "200";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 14F);
            this.label21.Location = new System.Drawing.Point(608, 211);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 24);
            this.label21.TabIndex = 155;
            this.label21.Text = "B:";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(661, 209);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(112, 34);
            this.textBox2.TabIndex = 154;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 14F);
            this.label20.Location = new System.Drawing.Point(608, 146);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(34, 24);
            this.label20.TabIndex = 153;
            this.label20.Text = "A:";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("宋体", 14F);
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(661, 144);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(112, 34);
            this.textBox1.TabIndex = 152;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox_tool
            // 
            this.groupBox_tool.Controls.Add(this.pictureBox1);
            this.groupBox_tool.Controls.Add(this.label87);
            this.groupBox_tool.Controls.Add(this.label86);
            this.groupBox_tool.Controls.Add(this.label85);
            this.groupBox_tool.Controls.Add(this.G0Y);
            this.groupBox_tool.Controls.Add(this.G0Z);
            this.groupBox_tool.Controls.Add(this.G0X);
            this.groupBox_tool.Controls.Add(this.Zbutton);
            this.groupBox_tool.Controls.Add(this.Ybutton);
            this.groupBox_tool.Controls.Add(this.Xbutton);
            this.groupBox_tool.Controls.Add(this.groupBox12);
            this.groupBox_tool.Controls.Add(this.button1);
            this.groupBox_tool.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_tool.Location = new System.Drawing.Point(329, 816);
            this.groupBox_tool.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_tool.Name = "groupBox_tool";
            this.groupBox_tool.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_tool.Size = new System.Drawing.Size(1115, 501);
            this.groupBox_tool.TabIndex = 167;
            this.groupBox_tool.TabStop = false;
            this.groupBox_tool.Text = "对刀";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 31);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(577, 451);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 175;
            this.pictureBox1.TabStop = false;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.Location = new System.Drawing.Point(980, 275);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(29, 20);
            this.label87.TabIndex = 174;
            this.label87.Text = "mm";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.Location = new System.Drawing.Point(980, 349);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(29, 20);
            this.label86.TabIndex = 173;
            this.label86.Text = "mm";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.Location = new System.Drawing.Point(980, 199);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(29, 20);
            this.label85.TabIndex = 172;
            this.label85.Text = "mm";
            // 
            // G0Y
            // 
            this.G0Y.Font = new System.Drawing.Font("宋体", 12F);
            this.G0Y.Location = new System.Drawing.Point(849, 272);
            this.G0Y.Margin = new System.Windows.Forms.Padding(4);
            this.G0Y.Name = "G0Y";
            this.G0Y.ReadOnly = true;
            this.G0Y.Size = new System.Drawing.Size(123, 30);
            this.G0Y.TabIndex = 171;
            this.G0Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G0Z
            // 
            this.G0Z.Font = new System.Drawing.Font("宋体", 12F);
            this.G0Z.Location = new System.Drawing.Point(849, 344);
            this.G0Z.Margin = new System.Windows.Forms.Padding(4);
            this.G0Z.Name = "G0Z";
            this.G0Z.ReadOnly = true;
            this.G0Z.Size = new System.Drawing.Size(123, 30);
            this.G0Z.TabIndex = 170;
            this.G0Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G0X
            // 
            this.G0X.Font = new System.Drawing.Font("宋体", 12F);
            this.G0X.Location = new System.Drawing.Point(849, 195);
            this.G0X.Margin = new System.Windows.Forms.Padding(4);
            this.G0X.Name = "G0X";
            this.G0X.ReadOnly = true;
            this.G0X.Size = new System.Drawing.Size(123, 30);
            this.G0X.TabIndex = 169;
            this.G0X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Zbutton
            // 
            this.Zbutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Zbutton.Location = new System.Drawing.Point(636, 344);
            this.Zbutton.Margin = new System.Windows.Forms.Padding(4);
            this.Zbutton.Name = "Zbutton";
            this.Zbutton.Size = new System.Drawing.Size(176, 36);
            this.Zbutton.TabIndex = 71;
            this.Zbutton.Text = "设置工件Z坐标";
            this.Zbutton.UseVisualStyleBackColor = true;
            this.Zbutton.Click += new System.EventHandler(this.Zbutton_Click);
            this.Zbutton.MouseEnter += new System.EventHandler(this.Zbutton_MouseEnter);
            // 
            // Ybutton
            // 
            this.Ybutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Ybutton.Location = new System.Drawing.Point(636, 271);
            this.Ybutton.Margin = new System.Windows.Forms.Padding(4);
            this.Ybutton.Name = "Ybutton";
            this.Ybutton.Size = new System.Drawing.Size(176, 36);
            this.Ybutton.TabIndex = 70;
            this.Ybutton.Text = "设置工件Y坐标";
            this.Ybutton.UseVisualStyleBackColor = true;
            this.Ybutton.Click += new System.EventHandler(this.Ybutton_Click);
            this.Ybutton.MouseEnter += new System.EventHandler(this.Ybutton_MouseEnter);
            // 
            // Xbutton
            // 
            this.Xbutton.Font = new System.Drawing.Font("宋体", 12F);
            this.Xbutton.Location = new System.Drawing.Point(636, 191);
            this.Xbutton.Margin = new System.Windows.Forms.Padding(4);
            this.Xbutton.Name = "Xbutton";
            this.Xbutton.Size = new System.Drawing.Size(176, 38);
            this.Xbutton.TabIndex = 0;
            this.Xbutton.Text = "设置工件X坐标";
            this.Xbutton.UseVisualStyleBackColor = true;
            this.Xbutton.Click += new System.EventHandler(this.Xbutton_Click);
            this.Xbutton.MouseEnter += new System.EventHandler(this.Xbutton_MouseEnter);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.tool_change);
            this.groupBox12.Controls.Add(this.label51);
            this.groupBox12.Controls.Add(this.label82);
            this.groupBox12.Controls.Add(this.label83);
            this.groupBox12.Controls.Add(this.value_rtool);
            this.groupBox12.Controls.Add(this.label84);
            this.groupBox12.Controls.Add(this.value_tool);
            this.groupBox12.Location = new System.Drawing.Point(636, 42);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(437, 111);
            this.groupBox12.TabIndex = 90;
            this.groupBox12.TabStop = false;
            // 
            // tool_change
            // 
            this.tool_change.Font = new System.Drawing.Font("宋体", 14F);
            this.tool_change.Location = new System.Drawing.Point(336, 38);
            this.tool_change.Margin = new System.Windows.Forms.Padding(4);
            this.tool_change.Name = "tool_change";
            this.tool_change.Size = new System.Drawing.Size(83, 46);
            this.tool_change.TabIndex = 91;
            this.tool_change.Text = "确认";
            this.tool_change.UseVisualStyleBackColor = true;
            this.tool_change.Click += new System.EventHandler(this.tool_change_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(285, 75);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 20);
            this.label51.TabIndex = 89;
            this.label51.Text = "mm";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(285, 29);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(29, 20);
            this.label82.TabIndex = 88;
            this.label82.Text = "mm";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label83.Location = new System.Drawing.Point(24, 75);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(99, 20);
            this.label83.TabIndex = 86;
            this.label83.Text = "刀具半径:";
            // 
            // value_rtool
            // 
            this.value_rtool.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.value_rtool.Location = new System.Drawing.Point(149, 71);
            this.value_rtool.Margin = new System.Windows.Forms.Padding(4);
            this.value_rtool.Name = "value_rtool";
            this.value_rtool.Size = new System.Drawing.Size(124, 30);
            this.value_rtool.TabIndex = 87;
            this.value_rtool.Text = "1.5";
            this.value_rtool.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(24, 28);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(99, 20);
            this.label84.TabIndex = 83;
            this.label84.Text = "刀具长度:";
            // 
            // value_tool
            // 
            this.value_tool.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.value_tool.Location = new System.Drawing.Point(149, 24);
            this.value_tool.Margin = new System.Windows.Forms.Padding(4);
            this.value_tool.Name = "value_tool";
            this.value_tool.Size = new System.Drawing.Size(124, 30);
            this.value_tool.TabIndex = 85;
            this.value_tool.Text = "50";
            this.value_tool.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_dimention
            // 
            this.button_dimention.BackColor = System.Drawing.Color.Transparent;
            this.button_dimention.Font = new System.Drawing.Font("宋体", 18F);
            this.button_dimention.Location = new System.Drawing.Point(16, 145);
            this.button_dimention.Margin = new System.Windows.Forms.Padding(4);
            this.button_dimention.Name = "button_dimention";
            this.button_dimention.Size = new System.Drawing.Size(188, 79);
            this.button_dimention.TabIndex = 152;
            this.button_dimention.Text = "机床尺度";
            this.button_dimention.UseVisualStyleBackColor = false;
            this.button_dimention.Click += new System.EventHandler(this.button_dimention_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button_spindle_stop);
            this.groupBox6.Controls.Add(this.button_spindle_run);
            this.groupBox6.Controls.Add(this.button5);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Controls.Add(this.button7);
            this.groupBox6.Controls.Add(this.button8);
            this.groupBox6.Controls.Add(this.button9);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox6.Location = new System.Drawing.Point(244, 251);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(241, 502);
            this.groupBox6.TabIndex = 153;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "单轴运动";
            // 
            // button_spindle_stop
            // 
            this.button_spindle_stop.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_spindle_stop.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_spindle_stop.Location = new System.Drawing.Point(20, 438);
            this.button_spindle_stop.Margin = new System.Windows.Forms.Padding(4);
            this.button_spindle_stop.Name = "button_spindle_stop";
            this.button_spindle_stop.Size = new System.Drawing.Size(200, 49);
            this.button_spindle_stop.TabIndex = 44;
            this.button_spindle_stop.Text = "关闭主轴";
            this.button_spindle_stop.UseVisualStyleBackColor = true;
            this.button_spindle_stop.Click += new System.EventHandler(this.button_spindle_stop_Click);
            // 
            // button_spindle_run
            // 
            this.button_spindle_run.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_spindle_run.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_spindle_run.Location = new System.Drawing.Point(20, 371);
            this.button_spindle_run.Margin = new System.Windows.Forms.Padding(4);
            this.button_spindle_run.Name = "button_spindle_run";
            this.button_spindle_run.Size = new System.Drawing.Size(200, 49);
            this.button_spindle_run.TabIndex = 43;
            this.button_spindle_run.Text = "启动主轴";
            this.button_spindle_run.UseVisualStyleBackColor = true;
            this.button_spindle_run.Click += new System.EventHandler(this.button_spindle_run_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("宋体", 14F);
            this.button5.Location = new System.Drawing.Point(20, 39);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(84, 49);
            this.button5.TabIndex = 24;
            this.button5.Text = "X+";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button5_MouseDown);
            this.button5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button5_MouseUp);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("宋体", 14F);
            this.button6.Location = new System.Drawing.Point(136, 39);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(84, 49);
            this.button6.TabIndex = 25;
            this.button6.Text = "X-";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button6_MouseDown);
            this.button6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button6_MouseUp);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 14F);
            this.button3.Location = new System.Drawing.Point(20, 104);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 49);
            this.button3.TabIndex = 22;
            this.button3.Text = "Y+";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
            this.button3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button3_MouseUp);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 14F);
            this.button4.Location = new System.Drawing.Point(136, 104);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 49);
            this.button4.TabIndex = 23;
            this.button4.Text = "Y-";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button4_MouseDown);
            this.button4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button4_MouseUp);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("宋体", 14F);
            this.button7.Location = new System.Drawing.Point(20, 170);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(84, 49);
            this.button7.TabIndex = 26;
            this.button7.Text = "Z+";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button7_MouseDown);
            this.button7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button7_MouseUp);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("宋体", 14F);
            this.button8.Location = new System.Drawing.Point(136, 170);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(84, 49);
            this.button8.TabIndex = 27;
            this.button8.Text = "Z-";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button8_MouseDown);
            this.button8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button8_MouseUp);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 14F);
            this.button9.Location = new System.Drawing.Point(20, 236);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(84, 49);
            this.button9.TabIndex = 28;
            this.button9.Text = "A+";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button9_MouseDown);
            this.button9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button9_MouseUp);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("宋体", 14F);
            this.button11.Location = new System.Drawing.Point(20, 304);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(84, 49);
            this.button11.TabIndex = 30;
            this.button11.Text = "B+";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button11_MouseDown);
            this.button11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button11_MouseUp);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 14F);
            this.button10.Location = new System.Drawing.Point(136, 236);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(84, 49);
            this.button10.TabIndex = 29;
            this.button10.Text = "A-";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button10_MouseDown);
            this.button10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button10_MouseUp);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("宋体", 14F);
            this.button12.Location = new System.Drawing.Point(136, 304);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(84, 49);
            this.button12.TabIndex = 31;
            this.button12.Text = "B-";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button12_MouseDown);
            this.button12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button12_MouseUp);
            // 
            // groupBox_dimention
            // 
            this.groupBox_dimention.Controls.Add(this.button14);
            this.groupBox_dimention.Controls.Add(this.button2);
            this.groupBox_dimention.Controls.Add(this.label46);
            this.groupBox_dimention.Controls.Add(this.value_d3max);
            this.groupBox_dimention.Controls.Add(this.value_d3min);
            this.groupBox_dimention.Controls.Add(this.value_d2max);
            this.groupBox_dimention.Controls.Add(this.value_d2min);
            this.groupBox_dimention.Controls.Add(this.value_d1max);
            this.groupBox_dimention.Controls.Add(this.value_d1min);
            this.groupBox_dimention.Controls.Add(this.label40);
            this.groupBox_dimention.Controls.Add(this.label41);
            this.groupBox_dimention.Controls.Add(this.label42);
            this.groupBox_dimention.Controls.Add(this.label43);
            this.groupBox_dimention.Controls.Add(this.label44);
            this.groupBox_dimention.Controls.Add(this.label45);
            this.groupBox_dimention.Controls.Add(this.value_S32max);
            this.groupBox_dimention.Controls.Add(this.value_S32min);
            this.groupBox_dimention.Controls.Add(this.value_U22max);
            this.groupBox_dimention.Controls.Add(this.value_U22min);
            this.groupBox_dimention.Controls.Add(this.value_U12max);
            this.groupBox_dimention.Controls.Add(this.value_U12min);
            this.groupBox_dimention.Controls.Add(this.label32);
            this.groupBox_dimention.Controls.Add(this.label33);
            this.groupBox_dimention.Controls.Add(this.label34);
            this.groupBox_dimention.Controls.Add(this.label35);
            this.groupBox_dimention.Controls.Add(this.label36);
            this.groupBox_dimention.Controls.Add(this.label37);
            this.groupBox_dimention.Controls.Add(this.value_S3max);
            this.groupBox_dimention.Controls.Add(this.value_S3min);
            this.groupBox_dimention.Controls.Add(this.value_U2max);
            this.groupBox_dimention.Controls.Add(this.value_U2min);
            this.groupBox_dimention.Controls.Add(this.value_U1max);
            this.groupBox_dimention.Controls.Add(this.value_U1min);
            this.groupBox_dimention.Controls.Add(this.label24);
            this.groupBox_dimention.Controls.Add(this.label25);
            this.groupBox_dimention.Controls.Add(this.label26);
            this.groupBox_dimention.Controls.Add(this.label27);
            this.groupBox_dimention.Controls.Add(this.label28);
            this.groupBox_dimention.Controls.Add(this.label29);
            this.groupBox_dimention.Controls.Add(this.value_R3max);
            this.groupBox_dimention.Controls.Add(this.value_R3min);
            this.groupBox_dimention.Controls.Add(this.value_R2max);
            this.groupBox_dimention.Controls.Add(this.value_R2min);
            this.groupBox_dimention.Controls.Add(this.value_R1max);
            this.groupBox_dimention.Controls.Add(this.value_R1min);
            this.groupBox_dimention.Controls.Add(this.label18);
            this.groupBox_dimention.Controls.Add(this.label19);
            this.groupBox_dimention.Controls.Add(this.label14);
            this.groupBox_dimention.Controls.Add(this.label17);
            this.groupBox_dimention.Controls.Add(this.label15);
            this.groupBox_dimention.Controls.Add(this.label47);
            this.groupBox_dimention.Controls.Add(this.label48);
            this.groupBox_dimention.Controls.Add(this.label13);
            this.groupBox_dimention.Controls.Add(this.label12);
            this.groupBox_dimention.Controls.Add(this.label8);
            this.groupBox_dimention.Controls.Add(this.value_b2);
            this.groupBox_dimention.Controls.Add(this.value_b3);
            this.groupBox_dimention.Controls.Add(this.label1);
            this.groupBox_dimention.Controls.Add(this.label7);
            this.groupBox_dimention.Controls.Add(this.label9);
            this.groupBox_dimention.Controls.Add(this.value_b1);
            this.groupBox_dimention.Controls.Add(this.label11);
            this.groupBox_dimention.Controls.Add(this.value_a2);
            this.groupBox_dimention.Controls.Add(this.value_a3);
            this.groupBox_dimention.Controls.Add(this.value_a1);
            this.groupBox_dimention.Controls.Add(this.label16);
            this.groupBox_dimention.Font = new System.Drawing.Font("宋体", 12F);
            this.groupBox_dimention.Location = new System.Drawing.Point(1155, 505);
            this.groupBox_dimention.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_dimention.Name = "groupBox_dimention";
            this.groupBox_dimention.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_dimention.Size = new System.Drawing.Size(1115, 501);
            this.groupBox_dimention.TabIndex = 154;
            this.groupBox_dimention.TabStop = false;
            this.groupBox_dimention.Text = "机床尺度定义";
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(560, 436);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(168, 49);
            this.button14.TabIndex = 213;
            this.button14.Text = "确认修改尺度";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(279, 436);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(179, 49);
            this.button2.TabIndex = 212;
            this.button2.Text = "取消修改";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(855, 122);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(161, 18);
            this.label46.TabIndex = 211;
            this.label46.Text = "主动关节极限位置:";
            // 
            // value_d3max
            // 
            this.value_d3max.Location = new System.Drawing.Point(984, 390);
            this.value_d3max.Margin = new System.Windows.Forms.Padding(4);
            this.value_d3max.Name = "value_d3max";
            this.value_d3max.Size = new System.Drawing.Size(97, 30);
            this.value_d3max.TabIndex = 208;
            this.value_d3max.Text = "320";
            this.value_d3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d3min
            // 
            this.value_d3min.Location = new System.Drawing.Point(984, 344);
            this.value_d3min.Margin = new System.Windows.Forms.Padding(4);
            this.value_d3min.Name = "value_d3min";
            this.value_d3min.Size = new System.Drawing.Size(97, 30);
            this.value_d3min.TabIndex = 207;
            this.value_d3min.Text = "137";
            this.value_d3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d2max
            // 
            this.value_d2max.Location = new System.Drawing.Point(983, 296);
            this.value_d2max.Margin = new System.Windows.Forms.Padding(4);
            this.value_d2max.Name = "value_d2max";
            this.value_d2max.Size = new System.Drawing.Size(97, 30);
            this.value_d2max.TabIndex = 206;
            this.value_d2max.Text = "320";
            this.value_d2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d2min
            // 
            this.value_d2min.Location = new System.Drawing.Point(984, 251);
            this.value_d2min.Margin = new System.Windows.Forms.Padding(4);
            this.value_d2min.Name = "value_d2min";
            this.value_d2min.Size = new System.Drawing.Size(97, 30);
            this.value_d2min.TabIndex = 205;
            this.value_d2min.Text = "137";
            this.value_d2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d1max
            // 
            this.value_d1max.Location = new System.Drawing.Point(984, 204);
            this.value_d1max.Margin = new System.Windows.Forms.Padding(4);
            this.value_d1max.Name = "value_d1max";
            this.value_d1max.Size = new System.Drawing.Size(97, 30);
            this.value_d1max.TabIndex = 204;
            this.value_d1max.Text = "320";
            this.value_d1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_d1min
            // 
            this.value_d1min.Location = new System.Drawing.Point(984, 158);
            this.value_d1min.Margin = new System.Windows.Forms.Padding(4);
            this.value_d1min.Name = "value_d1min";
            this.value_d1min.Size = new System.Drawing.Size(97, 30);
            this.value_d1min.TabIndex = 203;
            this.value_d1min.Text = "137";
            this.value_d1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(855, 391);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(116, 18);
            this.label40.TabIndex = 200;
            this.label40.Text = "d3_max/(mm):";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(855, 345);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(116, 18);
            this.label41.TabIndex = 199;
            this.label41.Text = "d3_min/(mm):";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(855, 298);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(116, 18);
            this.label42.TabIndex = 198;
            this.label42.Text = "d2_max/(mm):";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(855, 251);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(116, 18);
            this.label43.TabIndex = 197;
            this.label43.Text = "d2_min/(mm):";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(855, 204);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(116, 18);
            this.label44.TabIndex = 196;
            this.label44.Text = "d1_max/(mm):";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label45.Location = new System.Drawing.Point(855, 159);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(116, 18);
            this.label45.TabIndex = 195;
            this.label45.Text = "d1_min/(mm):";
            // 
            // value_S32max
            // 
            this.value_S32max.Location = new System.Drawing.Point(672, 389);
            this.value_S32max.Margin = new System.Windows.Forms.Padding(4);
            this.value_S32max.Name = "value_S32max";
            this.value_S32max.Size = new System.Drawing.Size(97, 30);
            this.value_S32max.TabIndex = 192;
            this.value_S32max.Text = "120";
            this.value_S32max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S32min
            // 
            this.value_S32min.Location = new System.Drawing.Point(672, 342);
            this.value_S32min.Margin = new System.Windows.Forms.Padding(4);
            this.value_S32min.Name = "value_S32min";
            this.value_S32min.Size = new System.Drawing.Size(97, 30);
            this.value_S32min.TabIndex = 191;
            this.value_S32min.Text = "60";
            this.value_S32min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U22max
            // 
            this.value_U22max.Location = new System.Drawing.Point(671, 295);
            this.value_U22max.Margin = new System.Windows.Forms.Padding(4);
            this.value_U22max.Name = "value_U22max";
            this.value_U22max.Size = new System.Drawing.Size(97, 30);
            this.value_U22max.TabIndex = 190;
            this.value_U22max.Text = "125";
            this.value_U22max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U22min
            // 
            this.value_U22min.Location = new System.Drawing.Point(672, 250);
            this.value_U22min.Margin = new System.Windows.Forms.Padding(4);
            this.value_U22min.Name = "value_U22min";
            this.value_U22min.Size = new System.Drawing.Size(97, 30);
            this.value_U22min.TabIndex = 189;
            this.value_U22min.Text = "55";
            this.value_U22min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U12max
            // 
            this.value_U12max.Location = new System.Drawing.Point(672, 202);
            this.value_U12max.Margin = new System.Windows.Forms.Padding(4);
            this.value_U12max.Name = "value_U12max";
            this.value_U12max.Size = new System.Drawing.Size(97, 30);
            this.value_U12max.TabIndex = 188;
            this.value_U12max.Text = "125";
            this.value_U12max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U12min
            // 
            this.value_U12min.Location = new System.Drawing.Point(672, 156);
            this.value_U12min.Margin = new System.Windows.Forms.Padding(4);
            this.value_U12min.Name = "value_U12min";
            this.value_U12min.Size = new System.Drawing.Size(97, 30);
            this.value_U12min.TabIndex = 187;
            this.value_U12min.Text = "55";
            this.value_U12min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(543, 390);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(125, 18);
            this.label32.TabIndex = 184;
            this.label32.Text = "S32_max/(°):";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(543, 344);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 18);
            this.label33.TabIndex = 183;
            this.label33.Text = "S32_min/(°):";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(543, 296);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 18);
            this.label34.TabIndex = 182;
            this.label34.Text = "U22_max/(°):";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(543, 250);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(125, 18);
            this.label35.TabIndex = 181;
            this.label35.Text = "U22_min/(°):";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(543, 202);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(125, 18);
            this.label36.TabIndex = 180;
            this.label36.Text = "U12_max/(°):";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(543, 158);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(125, 18);
            this.label37.TabIndex = 179;
            this.label37.Text = "U12_min/(°):";
            // 
            // value_S3max
            // 
            this.value_S3max.Location = new System.Drawing.Point(413, 388);
            this.value_S3max.Margin = new System.Windows.Forms.Padding(4);
            this.value_S3max.Name = "value_S3max";
            this.value_S3max.Size = new System.Drawing.Size(97, 30);
            this.value_S3max.TabIndex = 176;
            this.value_S3max.Text = "125";
            this.value_S3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_S3min
            // 
            this.value_S3min.Location = new System.Drawing.Point(413, 341);
            this.value_S3min.Margin = new System.Windows.Forms.Padding(4);
            this.value_S3min.Name = "value_S3min";
            this.value_S3min.Size = new System.Drawing.Size(97, 30);
            this.value_S3min.TabIndex = 175;
            this.value_S3min.Text = "55";
            this.value_S3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U2max
            // 
            this.value_U2max.Location = new System.Drawing.Point(412, 294);
            this.value_U2max.Margin = new System.Windows.Forms.Padding(4);
            this.value_U2max.Name = "value_U2max";
            this.value_U2max.Size = new System.Drawing.Size(97, 30);
            this.value_U2max.TabIndex = 174;
            this.value_U2max.Text = "125";
            this.value_U2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U2min
            // 
            this.value_U2min.Location = new System.Drawing.Point(413, 249);
            this.value_U2min.Margin = new System.Windows.Forms.Padding(4);
            this.value_U2min.Name = "value_U2min";
            this.value_U2min.Size = new System.Drawing.Size(97, 30);
            this.value_U2min.TabIndex = 173;
            this.value_U2min.Text = "55";
            this.value_U2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U1max
            // 
            this.value_U1max.Location = new System.Drawing.Point(413, 201);
            this.value_U1max.Margin = new System.Windows.Forms.Padding(4);
            this.value_U1max.Name = "value_U1max";
            this.value_U1max.Size = new System.Drawing.Size(97, 30);
            this.value_U1max.TabIndex = 172;
            this.value_U1max.Text = "125";
            this.value_U1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_U1min
            // 
            this.value_U1min.Location = new System.Drawing.Point(413, 155);
            this.value_U1min.Margin = new System.Windows.Forms.Padding(4);
            this.value_U1min.Name = "value_U1min";
            this.value_U1min.Size = new System.Drawing.Size(97, 30);
            this.value_U1min.TabIndex = 171;
            this.value_U1min.Text = "55";
            this.value_U1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(284, 389);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(116, 18);
            this.label24.TabIndex = 168;
            this.label24.Text = "S3_max/(°):";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(284, 342);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(116, 18);
            this.label25.TabIndex = 167;
            this.label25.Text = "S3_min/(°):";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(284, 295);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(116, 18);
            this.label26.TabIndex = 166;
            this.label26.Text = "U2_max/(°):";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(284, 249);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 18);
            this.label27.TabIndex = 165;
            this.label27.Text = "U2_min/(°):";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(284, 201);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(116, 18);
            this.label28.TabIndex = 164;
            this.label28.Text = "U1_max/(°):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.Location = new System.Drawing.Point(284, 156);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(116, 18);
            this.label29.TabIndex = 163;
            this.label29.Text = "U1_min/(°):";
            // 
            // value_R3max
            // 
            this.value_R3max.Location = new System.Drawing.Point(157, 388);
            this.value_R3max.Margin = new System.Windows.Forms.Padding(4);
            this.value_R3max.Name = "value_R3max";
            this.value_R3max.Size = new System.Drawing.Size(97, 30);
            this.value_R3max.TabIndex = 160;
            this.value_R3max.Text = "150";
            this.value_R3max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R3min
            // 
            this.value_R3min.Location = new System.Drawing.Point(157, 341);
            this.value_R3min.Margin = new System.Windows.Forms.Padding(4);
            this.value_R3min.Name = "value_R3min";
            this.value_R3min.Size = new System.Drawing.Size(97, 30);
            this.value_R3min.TabIndex = 159;
            this.value_R3min.Text = "30";
            this.value_R3min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R2max
            // 
            this.value_R2max.Location = new System.Drawing.Point(156, 294);
            this.value_R2max.Margin = new System.Windows.Forms.Padding(4);
            this.value_R2max.Name = "value_R2max";
            this.value_R2max.Size = new System.Drawing.Size(97, 30);
            this.value_R2max.TabIndex = 158;
            this.value_R2max.Text = "150";
            this.value_R2max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R2min
            // 
            this.value_R2min.Location = new System.Drawing.Point(157, 249);
            this.value_R2min.Margin = new System.Windows.Forms.Padding(4);
            this.value_R2min.Name = "value_R2min";
            this.value_R2min.Size = new System.Drawing.Size(97, 30);
            this.value_R2min.TabIndex = 157;
            this.value_R2min.Text = "30";
            this.value_R2min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R1max
            // 
            this.value_R1max.Location = new System.Drawing.Point(157, 201);
            this.value_R1max.Margin = new System.Windows.Forms.Padding(4);
            this.value_R1max.Name = "value_R1max";
            this.value_R1max.Size = new System.Drawing.Size(97, 30);
            this.value_R1max.TabIndex = 156;
            this.value_R1max.Text = "150";
            this.value_R1max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_R1min
            // 
            this.value_R1min.Location = new System.Drawing.Point(157, 155);
            this.value_R1min.Margin = new System.Windows.Forms.Padding(4);
            this.value_R1min.Name = "value_R1min";
            this.value_R1min.Size = new System.Drawing.Size(97, 30);
            this.value_R1min.TabIndex = 155;
            this.value_R1min.Text = "30";
            this.value_R1min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(28, 389);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 18);
            this.label18.TabIndex = 152;
            this.label18.Text = "R3_max/(°):";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(28, 342);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(116, 18);
            this.label19.TabIndex = 151;
            this.label19.Text = "R3_min/(°):";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(28, 295);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 18);
            this.label14.TabIndex = 150;
            this.label14.Text = "R2_max/(°):";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(28, 249);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 18);
            this.label17.TabIndex = 149;
            this.label17.Text = "R2_min/(°):";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(28, 201);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(116, 18);
            this.label15.TabIndex = 148;
            this.label15.Text = "R1_max/(°):";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(28, 156);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(116, 18);
            this.label47.TabIndex = 147;
            this.label47.Text = "R1_min/(°):";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(28, 120);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(143, 18);
            this.label48.TabIndex = 146;
            this.label48.Text = "被动关节极限角:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(440, 38);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 18);
            this.label13.TabIndex = 57;
            this.label13.Text = "a3/(mm)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(296, 39);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 18);
            this.label12.TabIndex = 56;
            this.label12.Text = "a2/(mm)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(155, 40);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 18);
            this.label8.TabIndex = 55;
            this.label8.Text = "a1/(mm)";
            // 
            // value_b2
            // 
            this.value_b2.Location = new System.Drawing.Point(843, 61);
            this.value_b2.Margin = new System.Windows.Forms.Padding(4);
            this.value_b2.Name = "value_b2";
            this.value_b2.Size = new System.Drawing.Size(97, 30);
            this.value_b2.TabIndex = 54;
            this.value_b2.Text = "90";
            this.value_b2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_b3
            // 
            this.value_b3.Location = new System.Drawing.Point(979, 62);
            this.value_b3.Margin = new System.Windows.Forms.Padding(4);
            this.value_b3.Name = "value_b3";
            this.value_b3.Size = new System.Drawing.Size(97, 30);
            this.value_b3.TabIndex = 53;
            this.value_b3.Text = "90";
            this.value_b3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(860, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 18);
            this.label1.TabIndex = 52;
            this.label1.Text = "b2/(mm)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(992, 39);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 18);
            this.label7.TabIndex = 51;
            this.label7.Text = "b3/(mm)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(723, 40);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 18);
            this.label9.TabIndex = 49;
            this.label9.Text = "b1/(mm)";
            // 
            // value_b1
            // 
            this.value_b1.Location = new System.Drawing.Point(708, 61);
            this.value_b1.Margin = new System.Windows.Forms.Padding(4);
            this.value_b1.Name = "value_b1";
            this.value_b1.Size = new System.Drawing.Size(97, 30);
            this.value_b1.TabIndex = 48;
            this.value_b1.Text = "90";
            this.value_b1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(588, 60);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 18);
            this.label11.TabIndex = 47;
            this.label11.Text = "动平台半径:";
            // 
            // value_a2
            // 
            this.value_a2.Location = new System.Drawing.Point(283, 60);
            this.value_a2.Margin = new System.Windows.Forms.Padding(4);
            this.value_a2.Name = "value_a2";
            this.value_a2.Size = new System.Drawing.Size(97, 30);
            this.value_a2.TabIndex = 45;
            this.value_a2.Text = "160";
            this.value_a2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_a3
            // 
            this.value_a3.Location = new System.Drawing.Point(428, 59);
            this.value_a3.Margin = new System.Windows.Forms.Padding(4);
            this.value_a3.Name = "value_a3";
            this.value_a3.Size = new System.Drawing.Size(97, 30);
            this.value_a3.TabIndex = 44;
            this.value_a3.Text = "160";
            this.value_a3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // value_a1
            // 
            this.value_a1.Location = new System.Drawing.Point(143, 61);
            this.value_a1.Margin = new System.Windows.Forms.Padding(4);
            this.value_a1.Name = "value_a1";
            this.value_a1.Size = new System.Drawing.Size(97, 30);
            this.value_a1.TabIndex = 39;
            this.value_a1.Text = "160";
            this.value_a1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(23, 59);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 18);
            this.label16.TabIndex = 38;
            this.label16.Text = "静平台半径:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Enabled = true;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // lab_test
            // 
            this.lab_test.AutoSize = true;
            this.lab_test.Location = new System.Drawing.Point(241, 11);
            this.lab_test.Name = "lab_test";
            this.lab_test.Size = new System.Drawing.Size(15, 15);
            this.lab_test.TabIndex = 176;
            this.lab_test.Text = " ";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1660, 886);
            this.Controls.Add(this.lab_test);
            this.Controls.Add(this.groupBox_tool);
            this.Controls.Add(this.groupBox_zero);
            this.Controls.Add(this.groupBox_running);
            this.Controls.Add(this.groupBox_processing);
            this.Controls.Add(this.groupBox_teach);
            this.Controls.Add(this.groupBox_dimention);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button_dimention);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.Workpiece_system);
            this.Controls.Add(this.processing);
            this.Controls.Add(this.Running_Status);
            this.Controls.Add(this.button_single);
            this.Controls.Add(this.calibration);
            this.Controls.Add(this.link_button);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.main_FormClosed);
            this.Load += new System.EventHandler(this.main_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t_dec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spindle_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t_acc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.run_speed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start_speed)).EndInit();
            this.groupBox_teach.ResumeLayout(false);
            this.groupBox_teach.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox_running.ResumeLayout(false);
            this.groupBox_running.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox_processing.ResumeLayout(false);
            this.groupBox_processing.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processing_speed_change)).EndInit();
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picture_processing)).EndInit();
            this.groupBox_zero.ResumeLayout(false);
            this.groupBox_zero.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox_tool.ResumeLayout(false);
            this.groupBox_tool.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox_dimention.ResumeLayout(false);
            this.groupBox_dimention.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button link_button;
        private System.Windows.Forms.Button open_SF;
        private System.Windows.Forms.Button close_SF;
        private System.Windows.Forms.Button calibration;
        private System.Windows.Forms.Button button_single;
        private System.Windows.Forms.Button Running_Status;
        private System.Windows.Forms.Button processing;
        private System.Windows.Forms.Button Workpiece_system;
        private System.Windows.Forms.Button clear_position_button;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button stop_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_change_speed;
        public System.Windows.Forms.NumericUpDown t_dec;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.NumericUpDown t_acc;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.NumericUpDown stop_speed;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.NumericUpDown run_speed;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.NumericUpDown start_speed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox check_move;
        private System.Windows.Forms.Button button_dimention;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown spindle_speed;
        private System.Windows.Forms.Button button_spindle_stop;
        private System.Windows.Forms.Button button_spindle_run;
        private System.Windows.Forms.Button open_handwheel;
        private System.Windows.Forms.GroupBox groupBox_dimention;
        private System.Windows.Forms.GroupBox groupBox_zero;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox value_d3max;
        private System.Windows.Forms.TextBox value_d3min;
        private System.Windows.Forms.TextBox value_d2max;
        private System.Windows.Forms.TextBox value_d2min;
        private System.Windows.Forms.TextBox value_d1max;
        private System.Windows.Forms.TextBox value_d1min;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox value_S32max;
        private System.Windows.Forms.TextBox value_S32min;
        private System.Windows.Forms.TextBox value_U22max;
        private System.Windows.Forms.TextBox value_U22min;
        private System.Windows.Forms.TextBox value_U12max;
        private System.Windows.Forms.TextBox value_U12min;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox value_S3max;
        private System.Windows.Forms.TextBox value_S3min;
        private System.Windows.Forms.TextBox value_U2max;
        private System.Windows.Forms.TextBox value_U2min;
        private System.Windows.Forms.TextBox value_U1max;
        private System.Windows.Forms.TextBox value_U1min;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox value_R3max;
        private System.Windows.Forms.TextBox value_R3min;
        private System.Windows.Forms.TextBox value_R2max;
        private System.Windows.Forms.TextBox value_R2min;
        private System.Windows.Forms.TextBox value_R1max;
        private System.Windows.Forms.TextBox value_R1min;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox value_b2;
        private System.Windows.Forms.TextBox value_b3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox value_b1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox value_a2;
        private System.Windows.Forms.TextBox value_a3;
        private System.Windows.Forms.TextBox value_a1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button confirm_zero;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button close_handwheel;
        private System.Windows.Forms.GroupBox groupBox_running;
        private System.Windows.Forms.GroupBox groupBox_teach;
        private System.Windows.Forms.Button button_continue;
        private System.Windows.Forms.Button button_stoping0;
        private System.Windows.Forms.Button button_edit;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox GX0_position;
        private System.Windows.Forms.TextBox PKMB0_position;
        private System.Windows.Forms.TextBox GY0_position;
        private System.Windows.Forms.TextBox PKMA0_position;
        private System.Windows.Forms.TextBox GZ0_position;
        private System.Windows.Forms.Button button_stoping;
        private System.Windows.Forms.Button button_running;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox teached_point;
        private System.Windows.Forms.Button moveto;
        private System.Windows.Forms.Button teaching;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.ComboBox teaching_point;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox PKMZ_position;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox GX_position;
        private System.Windows.Forms.TextBox PKMB_position;
        private System.Windows.Forms.TextBox GY_position;
        private System.Windows.Forms.TextBox PKMA_position;
        private System.Windows.Forms.TextBox GZ_position;
        private System.Windows.Forms.TextBox textBox_11;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox_10;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox_9;
        private System.Windows.Forms.TextBox textBox_1;
        private System.Windows.Forms.TextBox textBox_8;
        private System.Windows.Forms.TextBox textBox_2;
        private System.Windows.Forms.TextBox textBox_7;
        private System.Windows.Forms.TextBox textBox_3;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox_vel1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox_4;
        private System.Windows.Forms.TextBox textBox_vel3;
        private System.Windows.Forms.TextBox textBox_pos5;
        private System.Windows.Forms.TextBox textBox_5;
        private System.Windows.Forms.TextBox textBox_pos4;
        private System.Windows.Forms.TextBox textBox_pos3;
        private System.Windows.Forms.TextBox textBox_pos2;
        private System.Windows.Forms.TextBox textBox_vel4;
        private System.Windows.Forms.TextBox textBox_pos1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox_vel2;
        private System.Windows.Forms.TextBox textBox_vel5;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox_tool;
        private System.Windows.Forms.TextBox G0Y;
        private System.Windows.Forms.TextBox G0Z;
        private System.Windows.Forms.TextBox G0X;
        private System.Windows.Forms.Button Zbutton;
        private System.Windows.Forms.Button Ybutton;
        private System.Windows.Forms.Button Xbutton;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        public System.Windows.Forms.TextBox value_rtool;
        private System.Windows.Forms.Label label84;
        public System.Windows.Forms.TextBox value_tool;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.GroupBox groupBox_processing;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox_pointcount;
        private System.Windows.Forms.Button processing_speed;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox_pointnum;
        private System.Windows.Forms.Button button_run;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Button button_stop1;
        private System.Windows.Forms.Button button_stop0;
        private System.Windows.Forms.Button button_datainput;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.PictureBox picture_processing;
        private System.Windows.Forms.Button tool_change;
        private System.Windows.Forms.ProgressBar progressBar_processing;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox programming;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button correct_forward;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Button limbY2;
        private System.Windows.Forms.Button limbX2;
        private System.Windows.Forms.Button limb32;
        private System.Windows.Forms.Button limb22;
        private System.Windows.Forms.Button limb12;
        private System.Windows.Forms.Button limbY1;
        private System.Windows.Forms.Button limbX1;
        private System.Windows.Forms.Button limb31;
        private System.Windows.Forms.Button limb21;
        private System.Windows.Forms.Button limb11;
        private System.Windows.Forms.NumericUpDown processing_speed_change;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label lab_test;
    }
}

