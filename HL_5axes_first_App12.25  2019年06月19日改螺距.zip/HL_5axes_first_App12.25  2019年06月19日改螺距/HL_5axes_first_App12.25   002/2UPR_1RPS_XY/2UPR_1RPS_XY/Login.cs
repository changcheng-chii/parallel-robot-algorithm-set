﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2UPR_1RPS_XY
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void loading_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "2UPR&1RPS" && (textBox2.Text == "fzu" || textBox2.Text == "fhl160220031" || textBox2.Text == " "))
            {
                this.Hide();
                main main = new main();
                main.Show();
            }
            else
            {
                MessageBox.Show("账号密码不正确，请重新输入");
                //this.Hide();
                //main main = new main();
                //main.Show();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.loading_Click(sender, e);//触发button事件  
            }
        }
        //注册
        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("对不起，系统暂未开放！");
        }
        //忘记密码
        private void label5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("输入管理员学号！");
        }

        private void textBox2_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.loading_Click(sender, e);//触发button事件  
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

  

        private void label6_DoubleClick(object sender, EventArgs e)
        {
            this.Hide();
            main main = new main();
            main.Show();
        }
    }
}
