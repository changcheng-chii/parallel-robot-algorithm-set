﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Leadshine.SMC.IDE.Motion;
using System.Threading;
using System.Drawing.Drawing2D;
using MathNet.Numerics.LinearAlgebra;
using System.IO;

namespace _2UPR_1RPS_XY
{
    class forward_instantaneous
    {
        public forward_instantaneous()
        {

        }
        double con;
        double[] a;                   // 静平台半径;
        double[] b;                   // 动平台半径;
        double e_tool;                //刀身长度，动平台原点到刀尖点距离，待确定

        //瞬时姿态记忆
        public double instantaneous_psi, instantaneous_theta, instantaneous_z;        //并联动力头姿态参数
        public double instantaneous_Gx, instantaneous_Gy, instantaneous_Gz;           //刀尖点相对于静坐标系坐标
        public void foward_get_posture(double d1, double d2, double d3)
        {
            //机床尺度确定
            con = Math.PI / 180;
            a = new double[3]; b = new double[3];
            a[0] = main.a1; a[1] = main.a2; a[2] = main.a3;   // 静平台半径;
            b[0] = main.b1; b[1] = main.b2; b[2] = main.b3;   // 动平台半径;
            e_tool = main.e_tool;                     //刀身长度，动平台原点到刀尖点距离，待确定
            foward_calculate(d1, d2, d3);
        }
        public void foward_calculate(double d1, double d2, double d3)
        {
            //DateTime beforDT = System.DateTime.Now;
            double k1, k2, k3, k4, k5, k6, k61, k7, k8, k9, k91, k10, k11, k12, k13, k15;
            double k16, k17, k18, k19, k20, k21;
            double k00, k01, k02, k03, k04, k05, k06, k07, k08;
            double rang1 = Math.Cos(Math.PI / 4); double rang2 = 1;
            k1 = d2 * d2 - d1 * d1; k2 = 4 * b[0];  k3 = 4;
            k4 = d2 * d2 + d1 * d1; k5 = b[0];
            k6 = 2 * (b[0] * b[0] + a[0] * a[0]); k61 = b[2] * b[2] + a[2] * a[2];
            k7 = 4 * a[0]; k8 = 2 * a[2]; k9 = 2 * a[0] * b[0];
            k91 = 2 * a[2] * b[2]; k10 = d3 * d3; k11 = k2 / k3; k12 = k1 / k3;
            k13 = k4 - k6;
            if (d1 == d2)
            {
                instantaneous_psi = 0;//A
                double t01 = k4 + 2 * k9 - k6; double t02 = k4 / 2 + k61 - k6 / 2 + k9 - k10;
                double t03 = Math.Sqrt(t01 / 2);
                double t04 = k8 * t03 ;
                double t05 = k91;
                double theta0 = Math.Atan(t05 / t04);
                instantaneous_theta = Math.Asin( t02 / Math.Sqrt(t04 * t04 + t05 * t05)) - theta0;
                instantaneous_z = t03 * Math.Cos(instantaneous_theta);
            }
            else
            {
                double g0 = 0;
                double g1, g2, g3;
                double n = 0.3333333333333333;
                k00 = k7 * b[0] * b[0] * b[0]; k01 = -k13 * b[0] * b[0]; k02 = 2 * k12 * k12 - k13 * b[0] * b[0];
                k03 = k13 / (k7 * b[0]); k04 = -k02 / k00; k05 = -(k03 * k03) / 3 - 1;
                k06 = -Math.Pow((k03 / 3), 3) + Math.Pow(k03, 3) / 9 + k03 / 3 - k04;
                k15 = Math.Pow(k06 / 2, 2) + Math.Pow(k05 / 3, 3);
                if (k15 > 0)
                {
                    k16 = -k06 / 2 - Math.Pow(k15, 0.5);
                    k17 = -k06 / 2 + Math.Pow(k15, 0.5);
                    g1 = Math.Pow(k16, n) + Math.Pow(k17, n);
                    if (rang1 < g1 - k8 / 3 && g1 - k8 / 3 < rang2)
                    {
                        g0 = g1 - k03 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k151=：" + k15);
                    }
                }
                if (k15 == 0)
                {
                    g1 = -Math.Pow(k06, n) / Math.Pow(2, n + 1);
                    g2 = Math.Pow(k06 / 2, n);
                    if (rang1 < g1 - k8 / 3 && g1 - k8 / 3 < rang2)
                    {
                        g0 = g1 - k8 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else if (rang1 < g2 - k8 / 3 && g2 - k8 / 3 < rang2)
                    {
                        g0 = g2 - k8 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k152=：" + k15);
                    }
                }
                if (k15 < 0)
                {
                    k07 = Math.Pow((-k05) / 3, 1.5);
                    k08 = Math.Acos((-k06) / (2 * k07)) / 3;
                    g1 = 2 * Math.Pow(k07, n) * (Math.Cos(k08));//待修正
                    g2 = 2 * Math.Pow(k07, n) * Math.Cos(k08 + 2 * Math.PI / 3);
                    g3 = 2 * Math.Pow(k07, n) * Math.Cos(k08 + 4 * Math.PI / 3);
                    if (rang1 < g1 - k03 / 3 && g1 - k03 / 3 < rang2)
                    {
                        g0 = g1 - k03 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else if (rang1 < g2 - k03 / 3 && g2 - k03 / 3 < rang2)
                    {
                        g0 = g2 - k03 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else if (rang1 < g3 - k03 / 3 && g3 - k03 / 3 < rang2)
                    {
                        g0 = g3 - k03 / 3;
                        instantaneous_psi = Math.Sign(d2 - d1) * Math.Acos(g0);
                    }
                    else
                    {
                        MessageBox.Show("姿态求解可能出错k153=：" + k15);
                    }
                }
                k18 = k1 / (4 * b[0] * Math.Sin(instantaneous_psi)); k19 = k4 / 2 + k61 - k6/2 + k9 * Math.Cos(instantaneous_psi) - k10;
                k20 = k8 * k18; k21 = k91 ;
                double theta0 = Math.Atan(k21 / k20);
                instantaneous_theta = Math.Asin( k19 / Math.Sqrt(k20 * k20 + k21 * k21)) - theta0;
                instantaneous_z = k18 * Math.Cos(instantaneous_theta);
            }
            var JZ = Matrix<double>.Build;
            var XL = Vector<double>.Build;
            double instantaneous_phi = 0;
            double instantaneous_x = instantaneous_z * Math.Tan(instantaneous_theta);
            double instantaneous_y = 0;                                    //牵连运动

            double[] RotateA = { 1, 0, 0, 0, Math.Cos(instantaneous_psi), -Math.Sin(instantaneous_psi), 0, Math.Sin(instantaneous_psi), Math.Cos(instantaneous_psi) };
            double[] RotateB = { Math.Cos(instantaneous_theta), 0, Math.Sin(instantaneous_theta), 0, 1, 0, -Math.Sin(instantaneous_theta), 0, Math.Cos(instantaneous_theta) };
            double[] RotateC = { Math.Cos(instantaneous_phi), -Math.Sin(instantaneous_phi), 0, Math.Sin(instantaneous_phi), Math.Cos(instantaneous_phi), 0, 0, 0, 1 };

            var RZ = JZ.Dense(3, 3, RotateC).Transpose();
            var RY = JZ.Dense(3, 3, RotateB).Transpose();
            var RX = JZ.Dense(3, 3, RotateA).Transpose();
            var R = RZ * RY * RX;                         //姿态变换矩阵

            var vp = XL.Dense(3); vp[0] = instantaneous_x; vp[1] = instantaneous_y; vp[2] = instantaneous_z;       //动坐标系原点相对于静坐标系原点的位置向量
            var vz0 = XL.Dense(3); vz0[0] = 0; vz0[1] = 0; vz0[2] = 1;   //刀具方向向量
            var vz = R * vz0;
            var vq0 = vp + e_tool * vz;                                 //刀尖点相对于静坐标系坐标
            instantaneous_Gx = vq0[0]; instantaneous_Gy = vq0[1]; instantaneous_Gz = vq0[2];
            DateTime afterDT = System.DateTime.Now;
            //TimeSpan ts = afterDT.Subtract(beforDT);
            instantaneous_psi = instantaneous_psi / con;
            instantaneous_theta = instantaneous_theta / con;             //角度转弧度
            
            //MessageBox.Show("正解花费时间" + ts);
        }

    }
}
