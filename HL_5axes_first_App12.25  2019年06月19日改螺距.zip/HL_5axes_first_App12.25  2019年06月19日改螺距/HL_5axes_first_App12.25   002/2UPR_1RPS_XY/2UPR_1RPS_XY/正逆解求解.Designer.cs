﻿namespace _2UPR_1RPS_XY
{
    partial class 正逆解求解
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.逆解 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.zjd1 = new System.Windows.Forms.TextBox();
            this.zjd2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.zjd3 = new System.Windows.Forms.TextBox();
            this.zjz = new System.Windows.Forms.TextBox();
            this.zjy = new System.Windows.Forms.TextBox();
            this.zjx = new System.Windows.Forms.TextBox();
            this.zjB = new System.Windows.Forms.TextBox();
            this.zjA = new System.Windows.Forms.TextBox();
            this.njb = new System.Windows.Forms.TextBox();
            this.nja = new System.Windows.Forms.TextBox();
            this.njz = new System.Windows.Forms.TextBox();
            this.njy = new System.Windows.Forms.TextBox();
            this.njx = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.njd3 = new System.Windows.Forms.TextBox();
            this.njd2 = new System.Windows.Forms.TextBox();
            this.njd1 = new System.Windows.Forms.TextBox();
            this.zj1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // 逆解
            // 
            this.逆解.Location = new System.Drawing.Point(840, 319);
            this.逆解.Name = "逆解";
            this.逆解.Size = new System.Drawing.Size(157, 84);
            this.逆解.TabIndex = 1;
            this.逆解.Text = "逆解";
            this.逆解.UseVisualStyleBackColor = true;
            this.逆解.Click += new System.EventHandler(this.逆解_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(111, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "d1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "d2";
            // 
            // zjd1
            // 
            this.zjd1.Font = new System.Drawing.Font("宋体", 18F);
            this.zjd1.Location = new System.Drawing.Point(177, 58);
            this.zjd1.Margin = new System.Windows.Forms.Padding(4);
            this.zjd1.Name = "zjd1";
            this.zjd1.Size = new System.Drawing.Size(129, 41);
            this.zjd1.TabIndex = 14;
            this.zjd1.Text = "200";
            // 
            // zjd2
            // 
            this.zjd2.Font = new System.Drawing.Font("宋体", 18F);
            this.zjd2.Location = new System.Drawing.Point(177, 125);
            this.zjd2.Margin = new System.Windows.Forms.Padding(4);
            this.zjd2.Name = "zjd2";
            this.zjd2.Size = new System.Drawing.Size(129, 41);
            this.zjd2.TabIndex = 15;
            this.zjd2.Text = "200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 15);
            this.label3.TabIndex = 26;
            this.label3.Text = "d3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(427, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 15);
            this.label4.TabIndex = 29;
            this.label4.Text = "z";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(427, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 15);
            this.label5.TabIndex = 28;
            this.label5.Text = "y";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(427, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 15);
            this.label6.TabIndex = 27;
            this.label6.Text = "x";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(558, 440);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 15);
            this.label10.TabIndex = 35;
            this.label10.Text = "d3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(558, 378);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 15);
            this.label11.TabIndex = 34;
            this.label11.Text = "d2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(558, 311);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 15);
            this.label12.TabIndex = 33;
            this.label12.Text = "d1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(632, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 42;
            this.label13.Text = "B";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(632, 98);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 15);
            this.label14.TabIndex = 41;
            this.label14.Text = "A";
            // 
            // zjd3
            // 
            this.zjd3.Font = new System.Drawing.Font("宋体", 18F);
            this.zjd3.Location = new System.Drawing.Point(177, 187);
            this.zjd3.Margin = new System.Windows.Forms.Padding(4);
            this.zjd3.Name = "zjd3";
            this.zjd3.Size = new System.Drawing.Size(129, 41);
            this.zjd3.TabIndex = 47;
            this.zjd3.Text = "200";
            // 
            // zjz
            // 
            this.zjz.Font = new System.Drawing.Font("宋体", 18F);
            this.zjz.Location = new System.Drawing.Point(463, 187);
            this.zjz.Margin = new System.Windows.Forms.Padding(4);
            this.zjz.Name = "zjz";
            this.zjz.Size = new System.Drawing.Size(129, 41);
            this.zjz.TabIndex = 50;
            // 
            // zjy
            // 
            this.zjy.Font = new System.Drawing.Font("宋体", 18F);
            this.zjy.Location = new System.Drawing.Point(463, 125);
            this.zjy.Margin = new System.Windows.Forms.Padding(4);
            this.zjy.Name = "zjy";
            this.zjy.Size = new System.Drawing.Size(129, 41);
            this.zjy.TabIndex = 49;
            // 
            // zjx
            // 
            this.zjx.Font = new System.Drawing.Font("宋体", 18F);
            this.zjx.Location = new System.Drawing.Point(463, 58);
            this.zjx.Margin = new System.Windows.Forms.Padding(4);
            this.zjx.Name = "zjx";
            this.zjx.Size = new System.Drawing.Size(129, 41);
            this.zjx.TabIndex = 48;
            // 
            // zjB
            // 
            this.zjB.Font = new System.Drawing.Font("宋体", 18F);
            this.zjB.Location = new System.Drawing.Point(654, 149);
            this.zjB.Margin = new System.Windows.Forms.Padding(4);
            this.zjB.Name = "zjB";
            this.zjB.Size = new System.Drawing.Size(129, 41);
            this.zjB.TabIndex = 52;
            // 
            // zjA
            // 
            this.zjA.Font = new System.Drawing.Font("宋体", 18F);
            this.zjA.Location = new System.Drawing.Point(654, 82);
            this.zjA.Margin = new System.Windows.Forms.Padding(4);
            this.zjA.Name = "zjA";
            this.zjA.Size = new System.Drawing.Size(129, 41);
            this.zjA.TabIndex = 51;
            // 
            // njb
            // 
            this.njb.Font = new System.Drawing.Font("宋体", 18F);
            this.njb.Location = new System.Drawing.Point(321, 386);
            this.njb.Margin = new System.Windows.Forms.Padding(4);
            this.njb.Name = "njb";
            this.njb.Size = new System.Drawing.Size(129, 41);
            this.njb.TabIndex = 62;
            // 
            // nja
            // 
            this.nja.Font = new System.Drawing.Font("宋体", 18F);
            this.nja.Location = new System.Drawing.Point(321, 319);
            this.nja.Margin = new System.Windows.Forms.Padding(4);
            this.nja.Name = "nja";
            this.nja.Size = new System.Drawing.Size(129, 41);
            this.nja.TabIndex = 61;
            // 
            // njz
            // 
            this.njz.Font = new System.Drawing.Font("宋体", 18F);
            this.njz.Location = new System.Drawing.Point(130, 424);
            this.njz.Margin = new System.Windows.Forms.Padding(4);
            this.njz.Name = "njz";
            this.njz.Size = new System.Drawing.Size(129, 41);
            this.njz.TabIndex = 60;
            // 
            // njy
            // 
            this.njy.Font = new System.Drawing.Font("宋体", 18F);
            this.njy.Location = new System.Drawing.Point(130, 362);
            this.njy.Margin = new System.Windows.Forms.Padding(4);
            this.njy.Name = "njy";
            this.njy.Size = new System.Drawing.Size(129, 41);
            this.njy.TabIndex = 59;
            // 
            // njx
            // 
            this.njx.Font = new System.Drawing.Font("宋体", 18F);
            this.njx.Location = new System.Drawing.Point(130, 295);
            this.njx.Margin = new System.Windows.Forms.Padding(4);
            this.njx.Name = "njx";
            this.njx.Size = new System.Drawing.Size(129, 41);
            this.njx.TabIndex = 58;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(299, 397);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 15);
            this.label7.TabIndex = 57;
            this.label7.Text = "B";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(299, 335);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 15);
            this.label8.TabIndex = 56;
            this.label8.Text = "A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(94, 440);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 15);
            this.label9.TabIndex = 55;
            this.label9.Text = "z";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(94, 378);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 15);
            this.label15.TabIndex = 54;
            this.label15.Text = "y";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(94, 311);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 15);
            this.label16.TabIndex = 53;
            this.label16.Text = "x";
            // 
            // njd3
            // 
            this.njd3.Font = new System.Drawing.Font("宋体", 18F);
            this.njd3.Location = new System.Drawing.Point(588, 424);
            this.njd3.Margin = new System.Windows.Forms.Padding(4);
            this.njd3.Name = "njd3";
            this.njd3.Size = new System.Drawing.Size(129, 41);
            this.njd3.TabIndex = 65;
            // 
            // njd2
            // 
            this.njd2.Font = new System.Drawing.Font("宋体", 18F);
            this.njd2.Location = new System.Drawing.Point(588, 362);
            this.njd2.Margin = new System.Windows.Forms.Padding(4);
            this.njd2.Name = "njd2";
            this.njd2.Size = new System.Drawing.Size(129, 41);
            this.njd2.TabIndex = 64;
            // 
            // njd1
            // 
            this.njd1.Font = new System.Drawing.Font("宋体", 18F);
            this.njd1.Location = new System.Drawing.Point(588, 295);
            this.njd1.Margin = new System.Windows.Forms.Padding(4);
            this.njd1.Name = "njd1";
            this.njd1.Size = new System.Drawing.Size(129, 41);
            this.njd1.TabIndex = 63;
            // 
            // zj1
            // 
            this.zj1.Location = new System.Drawing.Point(840, 98);
            this.zj1.Name = "zj1";
            this.zj1.Size = new System.Drawing.Size(136, 79);
            this.zj1.TabIndex = 66;
            this.zj1.Text = "正解";
            this.zj1.UseVisualStyleBackColor = true;
            this.zj1.Click += new System.EventHandler(this.正解_Click);
            // 
            // 正逆解求解
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 535);
            this.Controls.Add(this.zj1);
            this.Controls.Add(this.njd3);
            this.Controls.Add(this.njd2);
            this.Controls.Add(this.njd1);
            this.Controls.Add(this.njb);
            this.Controls.Add(this.nja);
            this.Controls.Add(this.njz);
            this.Controls.Add(this.njy);
            this.Controls.Add(this.njx);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.zjB);
            this.Controls.Add(this.zjA);
            this.Controls.Add(this.zjz);
            this.Controls.Add(this.zjy);
            this.Controls.Add(this.zjx);
            this.Controls.Add(this.zjd3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.zjd2);
            this.Controls.Add(this.zjd1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.逆解);
            this.Name = "正逆解求解";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.正逆解求解_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button zj;
        private System.Windows.Forms.Button 逆解;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox zjd1;
        private System.Windows.Forms.TextBox zjd2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox zjd3;
        private System.Windows.Forms.TextBox zjz;
        private System.Windows.Forms.TextBox zjy;
        private System.Windows.Forms.TextBox zjx;
        private System.Windows.Forms.TextBox zjB;
        private System.Windows.Forms.TextBox zjA;
        private System.Windows.Forms.TextBox njb;
        private System.Windows.Forms.TextBox nja;
        private System.Windows.Forms.TextBox njz;
        private System.Windows.Forms.TextBox njy;
        private System.Windows.Forms.TextBox njx;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox njd3;
        private System.Windows.Forms.TextBox njd2;
        private System.Windows.Forms.TextBox njd1;
        private System.Windows.Forms.Button zj1;
    }
}