﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2UPR_1RPS_XY
{
    public partial class 正逆解求解 : Form
    {
        public 正逆解求解()
        {
            InitializeComponent();
        }

        private void 正逆解求解_Load(object sender, EventArgs e)
        {

        }

        private void 正解_Click(object sender, EventArgs e)
        {
            double d11 = Convert.ToDouble(zjd1.Text);
            double d21 = Convert.ToDouble(zjd2.Text);
            double d31 = Convert.ToDouble(zjd3.Text);

            forward_instantaneous f = new forward_instantaneous();
            f.foward_get_posture(d11,d21,d31);

            double x = f.instantaneous_Gx;
            double y = f.instantaneous_Gy;

            double z = f.instantaneous_Gz;
            double a = f.instantaneous_psi;
            double b = f.instantaneous_theta;

            zjx.Text = Convert.ToDouble(x).ToString("f5");// Convert.ToString( f.instantaneous_Gx).ToString("f5");
            zjy.Text = Convert.ToDouble(y).ToString("f5"); //Convert.ToString(f.instantaneous_Gy);
            zjz.Text = Convert.ToDouble(z).ToString("f5"); //Convert.ToString(f.instantaneous_Gz);
            zjA.Text = Convert.ToDouble(a).ToString("f5");//Convert.ToString(f.instantaneous_psi);
            zjB.Text = Convert.ToDouble(b).ToString("f5"); //Convert.ToString(f.instantaneous_theta);




        }

        private void 逆解_Click(object sender, EventArgs e)
        {
            double  con = Math.PI / 180;

            double z = Convert .ToDouble(njz.Text);
            double a = Convert .ToDouble(nja.Text);
            double b = Convert .ToDouble(njb.Text);
            Inverse i = new Inverse();
            a = a * con; b = b * con;
            i.inverse_position(a,b,z);

            double d1 = Inverse.d1;
            double d2 = Inverse.d2;
            double d3 = Inverse.d3;



            njd1.Text = Convert.ToDouble(d1).ToString("f3");
            njd2.Text = Convert.ToDouble(d2).ToString("f3");
            njd3.Text = Convert.ToDouble(d3).ToString("f3");
        }
    }
}
