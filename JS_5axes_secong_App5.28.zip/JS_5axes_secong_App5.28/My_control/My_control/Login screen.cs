﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace My_control
{    
    public partial class Login_screen : Form
    {
        forward_instantaneous forward_instantaneous = new forward_instantaneous();
        public Login_screen()
        {
            InitializeComponent();
        }

        private void loading_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "FZU002" && (textBox2.Text == "fzujxxy" || textBox2.Text == "fhl160220031" || textBox2.Text == " "))
            {
                this.Hide();
                main main = new main();
                main.Show();
            }
            else
            {
                MessageBox.Show("账号或密码不正确，请重新输入");
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.loading_Click(sender, e);//触发button事件  
            }
        }
        //注册
        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("对不起，系统暂未开放！");
        }
        //忘记密码
        private void label5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("输入管理员学号！");
        }


    }
}
